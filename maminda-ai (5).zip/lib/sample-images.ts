export const farmImages = {
  crops: [
    "/images/maize-field.jpg",
    "/images/tomato-plants.jpg",
    "/images/bean-plants.jpg",
    "/images/potato-field.jpg",
    "/images/wheat-field.jpg",
  ],
  livestock: [
    "/images/cattle.jpg",
    "/images/chickens.jpg",
    "/images/goats.jpg",
  ],
  equipment: [
    "/images/tractor.jpg",
    "/images/irrigation-system.jpg",
    "/images/harvester.jpg",
  ],
  landscapes: [
    "/images/farm-landscape.jpg",
    "/images/sunset-farm.jpg",
    "/images/aerial-farm.jpg",
  ],
}

export const getRandomImage = (category?: keyof typeof farmImages) => {
  if (category) {
    const images = farmImages[category]
    return images[Math.floor(Math.random() * images.length)]
  }

  // Get random category
  const categories = Object.keys(farmImages) as Array<keyof typeof farmImages>
  const randomCategory = categories[Math.floor(Math.random() * categories.length)]
  const images = farmImages[randomCategory]
  return images[Math.floor(Math.random() * images.length)]
}

