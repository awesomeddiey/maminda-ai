import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"
import Link from "next/link"

export default function SignUpSuccess() {
  return (
    <div className="container flex items-center justify-center min-h-[calc(100vh-4rem)] py-8">
      <Card className="w-full max-w-md text-center">
        <CardHeader>
          <div className="flex justify-center mb-4">
            <CheckCircle className="h-16 w-16 text-green-500" />
          </div>
          <CardTitle className="text-2xl font-bold">Registration Successful!</CardTitle>
          <CardDescription>Thank you for signing up with Maminda AI</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            We've sent a verification email to your inbox. Please check your email and follow the instructions to verify
            your account.
          </p>
          <p className="text-sm text-muted-foreground">If you don't see the email, please check your spam folder.</p>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button asChild>
            <Link href="/signin">Continue to Sign In</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

