"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Camera, Loader2, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

// Import the env at the top of the file
import { env } from "@/app/env"

// Add this import at the top of the file
import { ImageBackgroundSection } from "@/components/image-background-section"
import { getRandomImage } from "@/lib/sample-images"

interface SoilData {
  ph: string
  nitrogen: string
  phosphorus: string
  potassium: string
  soilType: string
  organicMatter: string
  texture: string
  notes: string
}

export default function SoilAnalyzer() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("upload")
  const [soilData, setSoilData] = useState<SoilData>({
    ph: "",
    nitrogen: "",
    phosphorus: "",
    potassium: "",
    soilType: "",
    organicMatter: "",
    texture: "",
    notes: "",
  })
  const { toast } = useToast()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      if (!selectedFile.type.startsWith("image/")) {
        toast({
          title: "Invalid file type",
          description: "Please upload an image file.",
          variant: "destructive",
        })
        return
      }

      setFile(selectedFile)
      const reader = new FileReader()
      reader.onload = () => {
        setSelectedImage(reader.result as string)
      }
      reader.readAsDataURL(selectedFile)
      setResult(null)
      setError(null)
    }
  }

  const captureImage = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true })
      const video = document.createElement("video")
      video.srcObject = stream
      video.play()

      setTimeout(() => {
        const canvas = document.createElement("canvas")
        canvas.width = video.videoWidth
        canvas.height = video.videoHeight
        const ctx = canvas.getContext("2d")
        ctx?.drawImage(video, 0, 0)

        // Stop all video streams
        const tracks = stream.getTracks()
        tracks.forEach((track) => track.stop())

        // Convert to file
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], "captured-image.jpg", { type: "image/jpeg" })
            setFile(file)
            setSelectedImage(canvas.toDataURL("image/jpeg"))
            setResult(null)
            setError(null)
          }
        }, "image/jpeg")
      }, 300)
    } catch (error) {
      console.error("Error accessing camera:", error)
      toast({
        title: "Camera Error",
        description: "Unable to access camera. Please check permissions.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setSoilData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setSoilData((prev) => ({ ...prev, [name]: value }))
  }

  const analyzeImage = async () => {
    if (!file && activeTab === "upload") {
      toast({
        title: "No image selected",
        description: "Please upload or capture a soil image first.",
        variant: "destructive",
      })
      return
    }

    if (activeTab === "manual" && (!soilData.ph || !soilData.soilType)) {
      toast({
        title: "Missing information",
        description: "Please fill in at least the pH and soil type fields.",
        variant: "destructive",
      })
      return
    }

    setIsAnalyzing(true)
    setError(null)

    try {
      let prompt = ""

      if (activeTab === "upload") {
        prompt = `
          I have a soil sample image. Based on the visual characteristics, please provide:
          1. Estimated soil type
          2. Potential pH range
          3. Recommendations for improving soil quality
          4. Best crops suited for this soil type
          5. Fertilizer recommendations
        `
      } else {
        prompt = `
          I have the following soil test results:
          - pH: ${soilData.ph || "Not provided"}
          - Nitrogen level: ${soilData.nitrogen || "Not provided"}
          - Phosphorus level: ${soilData.phosphorus || "Not provided"}
          - Potassium level: ${soilData.potassium || "Not provided"}
          - Soil type: ${soilData.soilType || "Not provided"}
          - Organic matter: ${soilData.organicMatter || "Not provided"}
          - Texture: ${soilData.texture || "Not provided"}
          - Additional notes: ${soilData.notes || "None"}
          
          Based on this information, please provide:
          1. Soil quality assessment
          2. Recommendations for improving soil quality
          3. Best crops suited for this soil
          4. Fertilizer recommendations
          5. Any potential issues to watch for
        `
      }

      const { text } = await generateText({
        model: openai("gpt-4o-mini", { apiKey: env.NEXT_PUBLIC_OPENAI_API_KEY }),
        prompt,
      })

      setResult({
        analysis: text,
      })
    } catch (error) {
      console.error("Error analyzing soil:", error)
      setError("Failed to analyze the soil data. Please try again.")
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="container py-8">
      {/* Add this section at the top of the component's return statement */}
      <div className="mb-6">
        <ImageBackgroundSection imageSrc={getRandomImage("landscapes")} className="h-[200px]">
          <div className="h-full flex flex-col justify-end">
            <h1 className="text-3xl font-bold text-white">Soil Analyzer</h1>
            <p className="text-white/90">Analyze your soil composition and get recommendations for optimal farming</p>
          </div>
        </ImageBackgroundSection>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Soil Data Input</CardTitle>
            <CardDescription>Upload a soil image or enter soil test results manually</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="upload" onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="upload">Image Upload</TabsTrigger>
                <TabsTrigger value="manual">Manual Entry</TabsTrigger>
              </TabsList>

              <TabsContent value="upload" className="space-y-4">
                <Tabs defaultValue="file">
                  <TabsList className="grid w-full grid-cols-2 mb-4">
                    <TabsTrigger value="file">File Upload</TabsTrigger>
                    <TabsTrigger value="camera">Camera</TabsTrigger>
                  </TabsList>

                  <TabsContent value="file">
                    <div className="flex items-center justify-center w-full">
                      <label
                        htmlFor="dropzone-file"
                        className="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer bg-muted/50 hover:bg-muted"
                      >
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <Upload className="w-10 h-10 mb-3 text-muted-foreground" />
                          <p className="mb-2 text-sm text-muted-foreground">
                            <span className="font-semibold">Click to upload</span> or drag and drop
                          </p>
                          <p className="text-xs text-muted-foreground">PNG, JPG or JPEG (MAX. 10MB)</p>
                        </div>
                        <input
                          id="dropzone-file"
                          type="file"
                          className="hidden"
                          accept="image/*"
                          onChange={handleFileChange}
                        />
                      </label>
                    </div>
                  </TabsContent>

                  <TabsContent value="camera">
                    <div className="flex flex-col items-center justify-center space-y-4">
                      <div className="w-full h-64 bg-muted/50 rounded-lg flex items-center justify-center">
                        <Button onClick={captureImage} className="flex items-center gap-2">
                          <Camera className="h-5 w-5" />
                          Capture Photo
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>

                {selectedImage && (
                  <div className="mt-4">
                    <div className="relative w-full h-64 rounded-lg overflow-hidden">
                      <img
                        src={selectedImage || "/placeholder.svg"}
                        alt="Soil sample"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="manual" className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="ph">Soil pH</Label>
                    <Input id="ph" name="ph" placeholder="e.g., 6.5" value={soilData.ph} onChange={handleInputChange} />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="soilType">Soil Type</Label>
                    <Select onValueChange={(value) => handleSelectChange("soilType", value)} value={soilData.soilType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select soil type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="clay">Clay</SelectItem>
                        <SelectItem value="sandy">Sandy</SelectItem>
                        <SelectItem value="loam">Loam</SelectItem>
                        <SelectItem value="silt">Silt</SelectItem>
                        <SelectItem value="peat">Peat</SelectItem>
                        <SelectItem value="chalk">Chalk</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nitrogen">Nitrogen (N)</Label>
                    <Input
                      id="nitrogen"
                      name="nitrogen"
                      placeholder="e.g., Low/Medium/High"
                      value={soilData.nitrogen}
                      onChange={handleInputChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phosphorus">Phosphorus (P)</Label>
                    <Input
                      id="phosphorus"
                      name="phosphorus"
                      placeholder="e.g., Low/Medium/High"
                      value={soilData.phosphorus}
                      onChange={handleInputChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="potassium">Potassium (K)</Label>
                    <Input
                      id="potassium"
                      name="potassium"
                      placeholder="e.g., Low/Medium/High"
                      value={soilData.potassium}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="organicMatter">Organic Matter (%)</Label>
                    <Input
                      id="organicMatter"
                      name="organicMatter"
                      placeholder="e.g., 2.5"
                      value={soilData.organicMatter}
                      onChange={handleInputChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="texture">Soil Texture</Label>
                    <Input
                      id="texture"
                      name="texture"
                      placeholder="e.g., Fine/Medium/Coarse"
                      value={soilData.texture}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Additional Notes</Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    placeholder="Any additional observations or information about your soil"
                    value={soilData.notes}
                    onChange={handleInputChange}
                  />
                </div>
              </TabsContent>
            </Tabs>

            <Button onClick={analyzeImage} className="w-full mt-4" disabled={isAnalyzing}>
              {isAnalyzing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                "Analyze Soil"
              )}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Soil Analysis Results</CardTitle>
            <CardDescription>Recommendations based on your soil data</CardDescription>
          </CardHeader>
          <CardContent>
            {isAnalyzing ? (
              <div className="flex flex-col items-center justify-center h-64 space-y-4">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
                <p className="text-muted-foreground">Analyzing your soil data...</p>
              </div>
            ) : error ? (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            ) : result ? (
              <div className="prose prose-sm max-w-none">
                <div className="whitespace-pre-line">{result.analysis}</div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-center">
                <p className="text-muted-foreground">
                  {activeTab === "upload"
                    ? "Upload or capture a photo of your soil sample to get analysis"
                    : "Enter your soil test results to get personalized recommendations"}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

