import { Check, Star, Sparkles, Shield, Zap, Award, Users, BarChart, Leaf } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function PricingPage() {
  return (
    <div className="bg-gradient-to-b from-green-50 to-white min-h-screen">
      {/* Hero Section */}
      <div className="relative overflow-hidden pt-16 pb-24">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-24 right-0 w-96 h-96 bg-green-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
          <div className="absolute -bottom-24 left-0 w-96 h-96 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
          <div className="absolute top-1/2 left-1/3 w-96 h-96 bg-yellow-200 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-4000"></div>
        </div>

        <div className="container mx-auto px-4 relative">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <div className="inline-block mb-4">
              <div className="flex items-center justify-center space-x-2 bg-green-100 px-4 py-2 rounded-full">
                <Sparkles className="h-5 w-5 text-green-600" />
                <span className="text-green-800 font-medium">Affordable plans for every farmer</span>
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-green-600 to-green-800">
              Simple, Transparent Pricing
            </h1>
            <p className="text-xl text-gray-600">Choose the plan that's right for your farming needs</p>
          </div>

          {/* Pricing Toggle */}
          <div className="flex justify-center mb-12">
            <div className="bg-white p-1 rounded-lg shadow-md inline-flex">
              <button className="px-6 py-2 rounded-md bg-green-600 text-white font-medium">Monthly</button>
              <button className="px-6 py-2 rounded-md text-gray-700 font-medium">Annual (Save 20%)</button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {/* Free Tier */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-200 transition-all hover:shadow-lg hover:translate-y-[-5px] duration-300">
              <div className="p-6 border-b border-gray-200 relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Free</h3>
                  <div className="flex items-baseline">
                    <span className="text-4xl font-bold text-gray-900">$0</span>
                    <span className="text-gray-600 ml-1">/month</span>
                  </div>
                  <p className="text-gray-600 mt-4">Get started with basic farming tools</p>
                </div>
                <div className="absolute -right-10 -top-10 w-40 h-40 bg-green-50 rounded-full opacity-50"></div>
              </div>
              <div className="p-6">
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Basic sign-up and sign-in with persistent sessions</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Current weather conditions</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Limited planting guide creation</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Limited FarmBot queries</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Basic plant disease and soil analysis</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Access to agricultural news</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">English, Shona, and Ndebele UI</span>
                  </li>
                </ul>
                <Link href="/signup" className="block mt-8">
                  <Button className="w-full bg-gray-900 hover:bg-gray-800 transition-all duration-300 hover:shadow-lg">
                    Get Started
                  </Button>
                </Link>
              </div>
            </div>

            {/* Basic Tier */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-200 transition-all hover:shadow-lg hover:translate-y-[-5px] duration-300">
              <div className="p-6 border-b border-gray-200 bg-blue-50 relative overflow-hidden">
                <div className="relative z-10">
                  <div className="flex items-center mb-2">
                    <h3 className="text-2xl font-bold text-gray-900">Basic</h3>
                    <Shield className="h-5 w-5 text-blue-500 ml-2" />
                  </div>
                  <div className="flex items-baseline">
                    <span className="text-4xl font-bold text-gray-900">$2.99</span>
                    <span className="text-gray-600 ml-1">/month</span>
                  </div>
                  <p className="text-gray-600 mt-4">Enhanced tools for small farms</p>
                </div>
                <div className="absolute -right-10 -top-10 w-40 h-40 bg-blue-100 rounded-full opacity-50"></div>
              </div>
              <div className="p-6">
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Everything in Free tier</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Unlimited planting guide creation</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Enhanced weather forecasts with modern charts</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">More precise location mapping</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Increased query limits for FarmBot</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Improved plant disease and soil analysis</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Priority access in community forums</span>
                  </li>
                </ul>
                <Link href="/signup?plan=basic" className="block mt-8">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700 transition-all duration-300 hover:shadow-lg">
                    Subscribe
                  </Button>
                </Link>
              </div>
            </div>

            {/* Standard Tier */}
            <div className="bg-white rounded-xl shadow-xl overflow-hidden border-2 border-green-500 transform scale-105 z-10 relative transition-all hover:shadow-2xl hover:translate-y-[-5px] duration-300">
              <div className="absolute top-0 right-0">
                <div className="bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg flex items-center">
                  <Star className="h-3 w-3 mr-1" /> POPULAR
                </div>
              </div>
              <div className="p-6 border-b border-gray-200 bg-green-50 relative overflow-hidden">
                <div className="relative z-10">
                  <div className="flex items-center mb-2">
                    <h3 className="text-2xl font-bold text-gray-900">Standard</h3>
                    <Award className="h-5 w-5 text-green-500 ml-2" />
                  </div>
                  <div className="flex items-baseline">
                    <span className="text-4xl font-bold text-gray-900">$4.99</span>
                    <span className="text-gray-600 ml-1">/month</span>
                  </div>
                  <p className="text-gray-600 mt-4">Advanced features for serious farmers</p>
                </div>
                <div className="absolute -right-10 -top-10 w-40 h-40 bg-green-100 rounded-full opacity-50"></div>
              </div>
              <div className="p-6">
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Everything in Basic tier</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Unlimited AI FarmBot queries</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Detailed plant disease and soil analysis</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Advanced farm performance dashboard</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Historical weather data analysis</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Access to in-depth agricultural articles</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Live chat support</span>
                  </li>
                </ul>
                <Link href="/signup?plan=standard" className="block mt-8">
                  <Button className="w-full bg-green-600 hover:bg-green-700 transition-all duration-300 hover:shadow-lg">
                    Subscribe
                  </Button>
                </Link>
              </div>
            </div>

            {/* Premium Tier */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-200 transition-all hover:shadow-lg hover:translate-y-[-5px] duration-300">
              <div className="p-6 border-b border-gray-200 bg-purple-50 relative overflow-hidden">
                <div className="relative z-10">
                  <div className="flex items-center mb-2">
                    <h3 className="text-2xl font-bold text-gray-900">Premium</h3>
                    <Zap className="h-5 w-5 text-purple-500 ml-2" />
                  </div>
                  <div className="flex items-baseline">
                    <span className="text-4xl font-bold text-gray-900">$9.99</span>
                    <span className="text-gray-600 ml-1">/month</span>
                  </div>
                  <p className="text-gray-600 mt-4">Complete solution for commercial farms</p>
                </div>
                <div className="absolute -right-10 -top-10 w-40 h-40 bg-purple-100 rounded-full opacity-50"></div>
              </div>
              <div className="p-6">
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-purple-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Everything in Standard tier</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-purple-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Priority processing for all AI tools</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-purple-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Collaborative guide sharing</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-purple-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Financial performance tracking</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-purple-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Real-time sensor data integration</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-purple-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Advanced authentication options</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-purple-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Dedicated expert consultation</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-purple-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">Offline access and PWA features</span>
                  </li>
                </ul>
                <Link href="/signup?plan=premium" className="block mt-8">
                  <Button className="w-full bg-purple-600 hover:bg-purple-700 transition-all duration-300 hover:shadow-lg">
                    Subscribe
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          {/* Feature Comparison */}
          <div className="mt-24 max-w-5xl mx-auto">
            <h2 className="text-2xl font-bold mb-8 text-center">Compare Plan Features</h2>
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="py-4 px-6 text-left text-gray-700 font-semibold">Feature</th>
                    <th className="py-4 px-4 text-center text-gray-700 font-semibold">Free</th>
                    <th className="py-4 px-4 text-center text-gray-700 font-semibold">Basic</th>
                    <th className="py-4 px-4 text-center text-gray-700 font-semibold">Standard</th>
                    <th className="py-4 px-4 text-center text-gray-700 font-semibold">Premium</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  <tr>
                    <td className="py-3 px-6 text-gray-700">Weather Forecast</td>
                    <td className="py-3 px-4 text-center">5-day</td>
                    <td className="py-3 px-4 text-center">10-day</td>
                    <td className="py-3 px-4 text-center">14-day</td>
                    <td className="py-3 px-4 text-center">30-day</td>
                  </tr>
                  <tr>
                    <td className="py-3 px-6 text-gray-700">AI Scans per Month</td>
                    <td className="py-3 px-4 text-center">10</td>
                    <td className="py-3 px-4 text-center">50</td>
                    <td className="py-3 px-4 text-center">Unlimited</td>
                    <td className="py-3 px-4 text-center">Unlimited</td>
                  </tr>
                  <tr>
                    <td className="py-3 px-6 text-gray-700">Planting Guides</td>
                    <td className="py-3 px-4 text-center">3</td>
                    <td className="py-3 px-4 text-center">Unlimited</td>
                    <td className="py-3 px-4 text-center">Unlimited</td>
                    <td className="py-3 px-4 text-center">Unlimited</td>
                  </tr>
                  <tr>
                    <td className="py-3 px-6 text-gray-700">FarmBot Queries</td>
                    <td className="py-3 px-4 text-center">20/day</td>
                    <td className="py-3 px-4 text-center">100/day</td>
                    <td className="py-3 px-4 text-center">Unlimited</td>
                    <td className="py-3 px-4 text-center">Priority</td>
                  </tr>
                  <tr>
                    <td className="py-3 px-6 text-gray-700">Analytics Dashboard</td>
                    <td className="py-3 px-4 text-center">Basic</td>
                    <td className="py-3 px-4 text-center">Standard</td>
                    <td className="py-3 px-4 text-center">Advanced</td>
                    <td className="py-3 px-4 text-center">Premium</td>
                  </tr>
                  <tr>
                    <td className="py-3 px-6 text-gray-700">Customer Support</td>
                    <td className="py-3 px-4 text-center">Email</td>
                    <td className="py-3 px-4 text-center">Email</td>
                    <td className="py-3 px-4 text-center">Live Chat</td>
                    <td className="py-3 px-4 text-center">Dedicated</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Feature Icons Section */}
          <div className="mt-24 max-w-5xl mx-auto">
            <h2 className="text-2xl font-bold mb-12 text-center">Why Choose Maminda AI?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-xl shadow-md text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
                  <Leaf className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Sustainable Farming</h3>
                <p className="text-gray-600">
                  Optimize your resources and reduce environmental impact with AI-powered recommendations.
                </p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-md text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 mb-4">
                  <BarChart className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Data-Driven Insights</h3>
                <p className="text-gray-600">
                  Make informed decisions based on real-time analytics and historical patterns.
                </p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-md text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-purple-100 mb-4">
                  <Users className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Community Support</h3>
                <p className="text-gray-600">
                  Connect with other farmers and experts to share knowledge and best practices.
                </p>
              </div>
            </div>
          </div>

          {/* FAQ Section */}
          <div className="mt-24 max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-8 text-center">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300">
                <h3 className="font-bold text-lg mb-2">Can I change plans later?</h3>
                <p className="text-gray-700">
                  Yes, you can upgrade or downgrade your plan at any time. Changes will take effect at the start of your
                  next billing cycle.
                </p>
              </div>
              <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300">
                <h3 className="font-bold text-lg mb-2">Is there a contract or commitment?</h3>
                <p className="text-gray-700">
                  No, all plans are month-to-month with no long-term commitment. You can cancel anytime.
                </p>
              </div>
              <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300">
                <h3 className="font-bold text-lg mb-2">Do you offer discounts for agricultural cooperatives?</h3>
                <p className="text-gray-700">
                  Yes, we offer special pricing for cooperatives and farming groups. Please contact our sales team for
                  more information.
                </p>
              </div>
              <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300">
                <h3 className="font-bold text-lg mb-2">Can I try before I buy?</h3>
                <p className="text-gray-700">
                  Our Free tier gives you access to core features so you can experience the platform before upgrading.
                </p>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-16 text-center">
            <h2 className="text-2xl font-bold mb-4">Need a custom solution?</h2>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              We offer tailored solutions for large agricultural enterprises and cooperatives. Contact us to discuss
              your specific requirements.
            </p>
            <Button variant="outline" size="lg" className="border-green-600 text-green-600 hover:bg-green-50">
              Contact Sales
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

