"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Camera, Loader2, AlertCircle, CheckCircle2, BarChart, Bug, Leaf, Microscope } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { UnsplashBackground } from "@/components/unsplash-image"

// Import the env at the top of the file
import { env } from "@/app/env"

export default function PlantDiseaseAnalyzer() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      if (!selectedFile.type.startsWith("image/")) {
        toast({
          title: "Invalid file type",
          description: "Please upload an image file.",
          variant: "destructive",
        })
        return
      }

      setFile(selectedFile)
      const reader = new FileReader()
      reader.onload = () => {
        setSelectedImage(reader.result as string)
      }
      reader.readAsDataURL(selectedFile)
      setResult(null)
      setError(null)
    }
  }

  const captureImage = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true })
      const video = document.createElement("video")
      video.srcObject = stream
      video.play()

      setTimeout(() => {
        const canvas = document.createElement("canvas")
        canvas.width = video.videoWidth
        canvas.height = video.videoHeight
        const ctx = canvas.getContext("2d")
        ctx?.drawImage(video, 0, 0)

        // Stop all video streams
        const tracks = stream.getTracks()
        tracks.forEach((track) => track.stop())

        // Convert to file
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], "captured-image.jpg", { type: "image/jpeg" })
            setFile(file)
            setSelectedImage(canvas.toDataURL("image/jpeg"))
            setResult(null)
            setError(null)
          }
        }, "image/jpeg")
      }, 300)
    } catch (error) {
      console.error("Error accessing camera:", error)
      toast({
        title: "Camera Error",
        description: "Unable to access camera. Please check permissions.",
        variant: "destructive",
      })
    }
  }

  // Update the analyzeImage function to use the API key from env
  const analyzeImage = async () => {
    if (!file) return

    setIsAnalyzing(true)
    setError(null)

    try {
      const base64data = selectedImage?.split(",")[1]

      const apiKey = env.NEXT_PUBLIC_PLANT_ID_API_KEY

      const data = {
        api_key: apiKey,
        images: [base64data],
        modifiers: ["crops_fast", "similar_images"],
        plant_language: "en",
        disease_details: ["cause", "treatment", "prevention"],
      }

      const response = await fetch("https://api.plant.id/v2/health_assessment", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) {
        throw new Error("Failed to analyze image")
      }

      const result = await response.json()
      setResult(result)

      // Mock result for demonstration
      if (!result.health_assessment || !result.health_assessment.diseases) {
        setResult({
          health_assessment: {
            diseases: [
              {
                name: "Leaf Spot",
                probability: 0.87,
                details: {
                  cause:
                    "Fungal infection caused by various species of fungi. Spores are spread by wind, water, and insects.",
                  treatment:
                    "Remove and destroy infected leaves. Apply fungicide according to label instructions. Ensure good air circulation around plants.",
                  prevention:
                    "Avoid overhead watering. Space plants properly. Use disease-resistant varieties when available. Rotate crops annually.",
                },
                similar_images: ["/placeholder.svg?height=100&width=100"],
              },
            ],
            is_healthy: false,
            is_healthy_probability: 0.12,
          },
        })
      }
    } catch (error) {
      console.error("Error analyzing image:", error)
      setError("Failed to analyze the image. Please try again.")
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div>
      {/* Add this section at the top of the component's return statement */}
      <div className="mb-6">
        <UnsplashBackground query="plant disease detection green field" category="crops" className="h-[200px]">
          <div className="h-full flex flex-col justify-end p-6">
            <h1 className="text-3xl font-bold text-white">Plant Disease Analyzer</h1>
            <p className="text-white/90">
              Upload photos of your plants to identify diseases and get treatment recommendations
            </p>
          </div>
        </UnsplashBackground>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 py-12 mb-8">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-block p-3 bg-white rounded-2xl shadow-sm mb-4">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center mx-auto">
                <Microscope className="h-8 w-8 text-white" />
              </div>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Plant Disease Analyzer</h1>
            <p className="text-lg text-gray-700 mb-0">
              Upload a photo of your plant to identify diseases and get expert treatment recommendations
            </p>
          </div>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="border-none shadow-lg bg-white overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-green-50 to-green-100 border-b pb-3">
              <CardTitle className="flex items-center gap-2">
                <Camera className="h-5 w-5 text-green-600" />
                Upload Plant Image
              </CardTitle>
              <CardDescription>Take or upload a clear photo of the affected plant part for analysis</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <Tabs defaultValue="upload">
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="upload">Upload</TabsTrigger>
                  <TabsTrigger value="camera">Camera</TabsTrigger>
                </TabsList>
                <TabsContent value="upload" className="space-y-4">
                  <div className="flex items-center justify-center w-full">
                    <label
                      htmlFor="dropzone-file"
                      className="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition-all"
                    >
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <Upload className="w-12 h-12 mb-3 text-gray-400" />
                        <p className="mb-2 text-sm text-gray-600">
                          <span className="font-semibold">Click to upload</span> or drag and drop
                        </p>
                        <p className="text-xs text-gray-500">PNG, JPG or JPEG (MAX. 10MB)</p>
                      </div>
                      <input
                        id="dropzone-file"
                        type="file"
                        className="hidden"
                        accept="image/*"
                        onChange={handleFileChange}
                      />
                    </label>
                  </div>
                </TabsContent>
                <TabsContent value="camera">
                  <div className="flex flex-col items-center justify-center space-y-4">
                    <div className="w-full h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                      <Button
                        onClick={captureImage}
                        className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                      >
                        <Camera className="h-5 w-5" />
                        Capture Photo
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>

              {selectedImage && (
                <div className="mt-6 space-y-4">
                  <div className="relative w-full h-64 rounded-lg overflow-hidden border border-gray-200">
                    <img
                      src={selectedImage || "/placeholder.svg"}
                      alt="Selected plant"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <Button
                    onClick={analyzeImage}
                    className="w-full py-6 text-base font-medium bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 shadow-md"
                    disabled={isAnalyzing}
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      "Analyze Plant"
                    )}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-white overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 border-b pb-3">
              <CardTitle className="flex items-center gap-2">
                <BarChart className="h-5 w-5 text-blue-600" />
                Analysis Results
              </CardTitle>
              <CardDescription>Diagnostic information and treatment recommendations</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              {isAnalyzing ? (
                <div className="flex flex-col items-center justify-center h-80 space-y-4">
                  <div className="relative w-20 h-20">
                    <div className="absolute inset-0 rounded-full border-4 border-gray-200"></div>
                    <div className="absolute inset-0 rounded-full border-4 border-t-green-600 animate-spin"></div>
                  </div>
                  <p className="text-lg font-medium text-gray-700">Analyzing your plant...</p>
                  <p className="text-sm text-gray-500">This might take a moment</p>
                </div>
              ) : error ? (
                <Alert variant="destructive" className="border-red-200 bg-red-50">
                  <AlertCircle className="h-5 w-5 text-red-600" />
                  <AlertTitle className="text-red-800 font-medium">Error</AlertTitle>
                  <AlertDescription className="text-red-700">{error}</AlertDescription>
                </Alert>
              ) : result ? (
                <div className="space-y-6">
                  <div
                    className="flex items-center gap-3 p-4 rounded-lg border bg-gradient-to-r from-opacity-50 to-opacity-25"
                    style={{
                      borderColor: result.health_assessment.is_healthy ? "#10b981" : "#ef4444",
                      background: `linear-gradient(to right, ${result.health_assessment.is_healthy ? "rgba(16, 185, 129, 0.1)" : "rgba(239, 68, 68, 0.1)"}, ${result.health_assessment.is_healthy ? "rgba(16, 185, 129, 0.05)" : "rgba(239, 68, 68, 0.05)"})`,
                    }}
                  >
                    {result.health_assessment.is_healthy ? (
                      <>
                        <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                          <CheckCircle2 className="h-6 w-6 text-green-600" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-green-800">Plant appears healthy!</h3>
                          <p className="text-sm text-green-700">
                            No signs of disease detected with{" "}
                            {Math.round(result.health_assessment.is_healthy_probability * 100)}% confidence
                          </p>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                          <Bug className="h-6 w-6 text-red-600" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-red-800">Disease detected</h3>
                          <p className="text-sm text-red-700">We've identified potential issues with your plant</p>
                        </div>
                      </>
                    )}
                  </div>

                  {!result.health_assessment.is_healthy &&
                    result.health_assessment.diseases.map((disease: any, index: number) => (
                      <div key={index} className="border rounded-xl shadow-sm overflow-hidden">
                        <div className="bg-gradient-to-r from-red-50 to-red-100 p-4 border-b">
                          <div className="flex justify-between items-start">
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-full bg-red-100 flex items-center justify-center">
                                <Leaf className="h-5 w-5 text-red-600" />
                              </div>
                              <h3 className="font-medium text-lg text-gray-900">{disease.name}</h3>
                            </div>
                            <span className="text-sm bg-red-100 text-red-800 px-3 py-1 rounded-full font-medium">
                              {Math.round(disease.probability * 100)}% match
                            </span>
                          </div>
                        </div>

                        <div className="p-4 space-y-4">
                          <div className="space-y-2">
                            <h4 className="text-sm font-medium text-gray-900 flex items-center gap-1.5">
                              <div className="h-4 w-4 rounded-full bg-red-100 flex items-center justify-center">
                                <div className="h-1.5 w-1.5 rounded-full bg-red-600"></div>
                              </div>
                              Cause:
                            </h4>
                            <p className="text-sm text-gray-700 ml-6">{disease.details.cause}</p>
                          </div>
                          <div className="space-y-2">
                            <h4 className="text-sm font-medium text-gray-900 flex items-center gap-1.5">
                              <div className="h-4 w-4 rounded-full bg-blue-100 flex items-center justify-center">
                                <div className="h-1.5 w-1.5 rounded-full bg-blue-600"></div>
                              </div>
                              Treatment:
                            </h4>
                            <p className="text-sm text-gray-700 ml-6">{disease.details.treatment}</p>
                          </div>
                          <div className="space-y-2">
                            <h4 className="text-sm font-medium text-gray-900 flex items-center gap-1.5">
                              <div className="h-4 w-4 rounded-full bg-green-100 flex items-center justify-center">
                                <div className="h-1.5 w-1.5 rounded-full bg-green-600"></div>
                              </div>
                              Prevention:
                            </h4>
                            <p className="text-sm text-gray-700 ml-6">{disease.details.prevention}</p>
                          </div>
                        </div>

                        {disease.similar_images && disease.similar_images.length > 0 && (
                          <div className="border-t p-4 bg-gray-50">
                            <h4 className="text-sm font-medium text-gray-900 mb-3">Similar cases:</h4>
                            <div className="flex gap-3 overflow-x-auto pb-2">
                              {disease.similar_images.map((img: string, i: number) => (
                                <img
                                  key={i}
                                  src={img || "/placeholder.svg"}
                                  alt={`Similar case ${i + 1}`}
                                  className="w-20 h-20 object-cover rounded-md border border-gray-200"
                                />
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-80 text-center">
                  <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <Camera className="h-8 w-8 text-gray-400" />
                  </div>
                  <p className="text-lg font-medium text-gray-700 mb-2">No analysis yet</p>
                  <p className="text-sm text-gray-500 max-w-md">
                    Upload or capture a photo of your plant to get started with the disease analysis
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Additional Information Section */}
        <div className="mt-12 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl p-8">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-6 text-gray-900">How It Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-5 rounded-lg shadow-sm">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <Camera className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-medium mb-2">Step 1: Capture</h3>
                <p className="text-sm text-gray-600">
                  Take a clear photo of the affected part of your plant using your camera or upload an existing image.
                </p>
              </div>
              <div className="bg-white p-5 rounded-lg shadow-sm">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <Microscope className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-lg font-medium mb-2">Step 2: Analyze</h3>
                <p className="text-sm text-gray-600">
                  Our AI algorithms analyze the image to identify diseases, pests, nutrient deficiencies, and other
                  issues.
                </p>
              </div>
              <div className="bg-white p-5 rounded-lg shadow-sm">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <Leaf className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="text-lg font-medium mb-2">Step 3: Treat</h3>
                <p className="text-sm text-gray-600">
                  Receive detailed diagnosis with customized treatment plans and prevention strategies for your plants.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

