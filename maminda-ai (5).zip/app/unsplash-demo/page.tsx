"use client"

import type React from "react"

import { useState } from "react"
import { UnsplashImage } from "@/components/unsplash-image"
import { ImageGallery } from "@/components/image-gallery"
import { HeroBanner } from "@/components/hero-banner"
import { ImageCard } from "@/components/image-card"
import { FeaturedFarmImages } from "@/components/featured-farm-images"
import { SectionDivider } from "@/components/section-divider"
import { ImageBackgroundSection } from "@/components/image-background-section"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"

export default function UnsplashDemoPage() {
  const [query, setQuery] = useState("green fields farm")
  const [customQuery, setCustomQuery] = useState("")

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setQuery(customQuery || "green fields farm")
  }

  const farmingCategories = [
    "green fields",
    "meadows",
    "pasture",
    "grassland",
    "crops",
    "vegetables",
    "plantation",
    "landscape",
    "harvest",
    "fertile soil",
  ]

  return (
    <div className="min-h-screen">
      <HeroBanner
        title="Green Fields Gallery"
        subtitle="Explore beautiful green fields and farmlands"
        imageQuery="lush green fields farm"
      >
        <form onSubmit={handleSearch} className="flex gap-2 justify-center">
          <Input
            type="text"
            placeholder="Search for images..."
            value={customQuery}
            onChange={(e) => setCustomQuery(e.target.value)}
            className="max-w-xs bg-white/90"
          />
          <Button type="submit">Search</Button>
        </form>
      </HeroBanner>

      <div className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold mb-8">Green Fields Gallery</h2>

        <div className="mb-12">
          <ImageGallery
            query={query}
            count={6}
            title="Lush Landscapes"
            subtitle="Beautiful green fields and farmlands from around the world"
          />
        </div>

        <SectionDivider imageQuery="green meadow sunrise" />

        <div className="my-12">
          <h2 className="text-3xl font-bold mb-8">Green Farming Categories</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {farmingCategories.map((category) => (
              <ImageCard
                key={category}
                title={category.charAt(0).toUpperCase() + category.slice(1)}
                imageQuery={`${category} farm green`}
                onClick={() => setQuery(`${category} farm green`)}
              />
            ))}
          </div>
        </div>

        <SectionDivider imageQuery="green fields sunset" />

        <div className="my-12">
          <h2 className="text-3xl font-bold mb-8">Featured Green Landscapes</h2>
          <FeaturedFarmImages
            images={[
              {
                title: "Rolling Green Hills",
                description: "Endless rolling hills of vibrant green farmland",
                query: "rolling green hills farm",
              },
              {
                title: "Terraced Fields",
                description: "Beautiful terraced green fields creating natural patterns",
                query: "terraced green fields",
              },
              {
                title: "Lush Meadows",
                description: "Expansive meadows with rich green grass perfect for grazing",
                query: "lush green meadows",
              },
            ]}
          />
        </div>

        <SectionDivider imageQuery="green wheat field" />

        <div className="my-12">
          <h2 className="text-3xl font-bold mb-8">Seasonal Green Fields</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="overflow-hidden">
              <UnsplashImage
                query="spring green fields farm"
                alt="Spring green fields"
                className="w-full h-[300px]"
                width={800}
                height={600}
              />
              <CardContent className="p-4">
                <h3 className="text-xl font-bold">Spring Fields</h3>
                <p className="text-gray-600">Fresh green growth after the winter season</p>
              </CardContent>
            </Card>

            <Card className="overflow-hidden">
              <UnsplashImage
                query="summer green fields farm"
                alt="Summer green fields"
                className="w-full h-[300px]"
                width={800}
                height={600}
              />
              <CardContent className="p-4">
                <h3 className="text-xl font-bold">Summer Fields</h3>
                <p className="text-gray-600">Vibrant green fields at the height of growing season</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <ImageBackgroundSection imageQuery="aerial view green fields farm">
        <div className="text-center text-white">
          <h2 className="text-3xl font-bold mb-4">Green Fields from Above</h2>
          <p className="text-xl mb-6">Aerial views showcase the beautiful patterns of green farmland</p>
          <Button onClick={() => setQuery("aerial green fields farm")}>Explore Aerial Views</Button>
        </div>
      </ImageBackgroundSection>
    </div>
  )
}

