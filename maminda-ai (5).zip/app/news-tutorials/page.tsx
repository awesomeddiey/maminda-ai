"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Video, Calendar, Share2, BookOpen, Filter, Search, ExternalLink } from "lucide-react"
import { LiveChat } from "@/components/live-chat"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export default function NewsTutorials() {
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")

  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold">News & Tutorials</h1>
          <p className="text-muted-foreground">Stay updated with the latest farming news and learn new techniques</p>
        </div>

        <div className="flex gap-2">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[150px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="news">News</SelectItem>
              <SelectItem value="tutorials">Tutorials</SelectItem>
              <SelectItem value="webinars">Webinars</SelectItem>
              <SelectItem value="research">Research</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input
          placeholder="Search for news, tutorials, and more..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <Tabs defaultValue="featured" className="mb-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="featured">Featured</TabsTrigger>
          <TabsTrigger value="news">News</TabsTrigger>
          <TabsTrigger value="tutorials">Tutorials</TabsTrigger>
          <TabsTrigger value="webinars">Webinars</TabsTrigger>
        </TabsList>

        <TabsContent value="featured" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2 overflow-hidden">
              <div className="relative h-64 md:h-80">
                <img
                  src="/placeholder.svg?height=400&width=800"
                  alt="Featured article"
                  className="absolute inset-0 w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6">
                  <Badge className="w-fit mb-2 bg-green-600">Featured</Badge>
                  <h2 className="text-2xl font-bold text-white mb-2">
                    Climate-Smart Agriculture: Adapting to Changing Weather Patterns
                  </h2>
                  <p className="text-white/80 mb-4">
                    Learn how farmers across Africa are adapting their practices to deal with climate change and
                    unpredictable weather.
                  </p>
                  <div className="flex items-center gap-2">
                    <Button variant="default" className="bg-green-600 hover:bg-green-700">
                      Read Article
                    </Button>
                    <Button variant="outline" className="text-white border-white hover:bg-white/20 hover:text-white">
                      <Share2 className="h-4 w-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </div>
              </div>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader className="pb-3">
                  <Badge className="w-fit mb-1 bg-blue-600">News</Badge>
                  <CardTitle className="text-lg">New Drought-Resistant Maize Variety Released</CardTitle>
                  <CardDescription>May 15, 2025</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Researchers have developed a new maize variety that can withstand up to 30 days of drought
                    conditions while maintaining yields.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" size="sm" className="text-green-600">
                    Read More
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <Badge className="w-fit mb-1 bg-purple-600">Tutorial</Badge>
                  <CardTitle className="text-lg">Maximizing Tomato Yields in Small Spaces</CardTitle>
                  <CardDescription>May 10, 2025</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Learn techniques for growing high-yielding tomatoes in limited space using vertical gardening and
                    intensive planting methods.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" size="sm" className="text-green-600">
                    Read More
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            <Card>
              <CardHeader className="pb-3">
                <Badge className="w-fit mb-1 bg-orange-600">Webinar</Badge>
                <CardTitle className="text-lg">Soil Health Management for Sustainable Farming</CardTitle>
                <CardDescription className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  May 20, 2025 • 2:00 PM CAT
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Join soil experts as they discuss practical techniques for improving and maintaining soil health for
                  long-term farm sustainability.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="outline" size="sm">
                  Register Now
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <Badge className="w-fit mb-1 bg-blue-600">News</Badge>
                <CardTitle className="text-lg">Government Announces New Subsidies for Small-Scale Farmers</CardTitle>
                <CardDescription>May 8, 2025</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  The Ministry of Agriculture has announced a new subsidy program aimed at supporting small-scale
                  farmers with inputs and equipment.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" size="sm" className="text-green-600">
                  Read More
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <Badge className="w-fit mb-1 bg-purple-600">Tutorial</Badge>
                <CardTitle className="text-lg">Natural Pest Control Methods for Organic Farming</CardTitle>
                <CardDescription>May 5, 2025</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Discover effective organic pest control strategies that protect your crops without harmful chemicals.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" size="sm" className="text-green-600">
                  Read More
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="news" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <div className="aspect-video relative overflow-hidden">
                  <img
                    src={`/placeholder.svg?height=200&width=400&text=News+${i}`}
                    alt={`News article ${i}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center mb-1">
                    <Badge className="bg-blue-600">News</Badge>
                    <span className="text-xs text-muted-foreground">May {5 + i}, 2025</span>
                  </div>
                  <CardTitle className="text-lg">Agricultural News Headline {i}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua.
                  </p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="ghost" size="sm" className="text-green-600">
                    Read More
                  </Button>
                  <Button variant="ghost" size="sm" className="text-muted-foreground">
                    <Share2 className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="tutorials" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <div className="aspect-video relative overflow-hidden">
                  <img
                    src={`/placeholder.svg?height=200&width=400&text=Tutorial+${i}`}
                    alt={`Tutorial ${i}`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-black/50 rounded-full p-3">
                      <Video className="h-6 w-6 text-white" />
                    </div>
                  </div>
                </div>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center mb-1">
                    <Badge className="bg-purple-600">Tutorial</Badge>
                    <span className="text-xs text-muted-foreground">12:34 mins</span>
                  </div>
                  <CardTitle className="text-lg">Farming Tutorial Title {i}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Learn step-by-step techniques for improving your farming practices and increasing yields.
                  </p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="ghost" size="sm" className="text-green-600">
                    Watch Tutorial
                  </Button>
                  <Button variant="ghost" size="sm" className="text-muted-foreground">
                    <BookOpen className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="webinars" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="flex flex-col md:flex-row overflow-hidden">
                <div className="w-full md:w-1/3 aspect-video md:aspect-auto relative">
                  <img
                    src={`/placeholder.svg?height=200&width=200&text=Webinar+${i}`}
                    alt={`Webinar ${i}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 flex flex-col">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center mb-1">
                      <Badge className="bg-orange-600">Webinar</Badge>
                      <span className="text-xs text-muted-foreground">60 mins</span>
                    </div>
                    <CardTitle className="text-lg">Farming Webinar Title {i}</CardTitle>
                    <CardDescription className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      May {20 + i}, 2025 • 2:00 PM CAT
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <p className="text-sm text-muted-foreground">
                      Join our expert panel as they discuss important farming topics and answer your questions live.
                    </p>
                    <div className="flex items-center gap-2 mt-3">
                      <Avatar className="h-6 w-6">
                        <AvatarFallback>JS</AvatarFallback>
                      </Avatar>
                      <span className="text-xs">Dr. John Smith, Agricultural Scientist</span>
                    </div>
                  </CardContent>
                  <CardFooter className="mt-auto">
                    <Button variant="outline" size="sm" className="mr-2">
                      Register Now
                    </Button>
                    <Button variant="ghost" size="sm" className="text-muted-foreground">
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </CardFooter>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-8">
        <h2 className="text-xl font-bold mb-4">Subscribe to Updates</h2>
        <Card>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div>
                <h3 className="text-lg font-medium mb-2">Stay Updated</h3>
                <p className="text-muted-foreground mb-4">
                  Subscribe to our newsletter to receive the latest farming news, tutorials, and event notifications
                  directly to your inbox.
                </p>
                <div className="flex gap-2">
                  <Input placeholder="Your email address" className="max-w-md" />
                  <Button>Subscribe</Button>
                </div>
              </div>
              <div className="flex justify-center md:justify-end">
                <div className="flex gap-4">
                  <Button variant="outline" size="icon" className="rounded-full">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-facebook"
                    >
                      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                    </svg>
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-twitter"
                    >
                      <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                    </svg>
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-instagram"
                    >
                      <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
                      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"></line>
                    </svg>
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="lucide lucide-youtube"
                    >
                      <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"></path>
                      <path d="m10 15 5-3-5-3z"></path>
                    </svg>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <LiveChat />
    </div>
  )
}

