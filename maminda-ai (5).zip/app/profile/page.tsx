"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/supabase-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, User, Calendar, Settings, Leaf, MapPin, Mail, Phone } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { plantingGuideService } from "@/services/planting-guide-service"
import { ImageBackgroundSection } from "@/components/image-background-section"
import { getRandomImage } from "@/lib/sample-images"
import { CropImageGrid } from "@/components/crop-image-grid"
import { FarmStatsCard } from "@/components/farm-stats-card"

interface PlantingGuide {
  id: string
  title: string
  plant_type: string
  location: string
  planting_date: string
  guide_content?: string
  created_at: string
}

interface UserProfile {
  full_name: string
  email: string
  phone: string
  location: string
  bio: string
  avatar_url: string
}

const sampleCrops = [
  {
    name: "Maize",
    imageSrc: "/placeholder.svg?height=200&width=200",
    season: "Summer",
    difficulty: "Easy" as const,
  },
  {
    name: "Tomatoes",
    imageSrc: "/placeholder.svg?height=200&width=200",
    season: "Spring",
    difficulty: "Medium" as const,
  },
  {
    name: "Potatoes",
    imageSrc: "/placeholder.svg?height=200&width=200",
    season: "Fall",
    difficulty: "Medium" as const,
  },
  {
    name: "Beans",
    imageSrc: "/placeholder.svg?height=200&width=200",
    season: "Summer",
    difficulty: "Easy" as const,
  },
  {
    name: "Cabbage",
    imageSrc: "/placeholder.svg?height=200&width=200",
    season: "Winter",
    difficulty: "Medium" as const,
  },
  {
    name: "Onions",
    imageSrc: "/placeholder.svg?height=200&width=200",
    season: "Year-round",
    difficulty: "Medium" as const,
  },
  {
    name: "Carrots",
    imageSrc: "/placeholder.svg?height=200&width=200",
    season: "Fall",
    difficulty: "Easy" as const,
  },
  {
    name: "Rice",
    imageSrc: "/placeholder.svg?height=200&width=200",
    season: "Summer",
    difficulty: "Hard" as const,
  },
]

export default function ProfilePage() {
  const { user } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("profile")
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [guides, setGuides] = useState<PlantingGuide[]>([])
  const [selectedGuide, setSelectedGuide] = useState<PlantingGuide | null>(null)
  const [profile, setProfile] = useState<UserProfile>({
    full_name: "",
    email: "",
    phone: "",
    location: "",
    bio: "",
    avatar_url: "",
  })

  useEffect(() => {
    if (!user) {
      router.push("/signin")
      return
    }

    // Set default profile data
    setProfile({
      full_name: "John Doe",
      email: user.email || "",
      phone: "+263 77 123 4567",
      location: "Harare, Zimbabwe",
      bio: "I am a passionate farmer with 10 years of experience in sustainable agriculture. I specialize in maize, tomatoes, and beans cultivation.",
      avatar_url: "/placeholder.svg?height=100&width=100",
    })

    // Load planting guides
    loadPlantingGuides()

    // Check if there's a tab parameter in the URL
    const urlParams = new URLSearchParams(window.location.search)
    const tabParam = urlParams.get("tab")
    if (tabParam) {
      setActiveTab(tabParam)
    }
  }, [user, router])

  const loadPlantingGuides = async () => {
    if (!user) return

    setIsLoading(true)
    try {
      const { data, error } = await plantingGuideService.getGuidesByUserId(user.id)

      if (error) {
        throw error
      }

      if (data) {
        setGuides(data)
      }
    } catch (error) {
      console.error("Error loading guides:", error)
      toast({
        title: "Error loading guides",
        description: "Failed to load your planting guides.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      })
    } catch (error) {
      console.error("Error updating profile:", error)
      toast({
        title: "Error updating profile",
        description: "Failed to update your profile. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  if (!user) {
    return null // Don't render anything while redirecting
  }

  return (
    <div className="container py-8">
      {/* Add this section at the top of the component's return statement */}
      <div className="mb-6">
        <ImageBackgroundSection imageSrc={getRandomImage("landscapes")} className="h-[200px]">
          <div className="h-full flex flex-col justify-end">
            <h1 className="text-3xl font-bold text-white">My Profile</h1>
            <p className="text-white/90">Manage your account and view your saved planting guides</p>
          </div>
        </ImageBackgroundSection>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-1">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center mb-6">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src={profile.avatar_url || "/placeholder.svg"} alt={profile.full_name} />
                  <AvatarFallback>{profile.full_name.charAt(0)}</AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-bold">{profile.full_name}</h2>
                <p className="text-sm text-muted-foreground">{profile.email}</p>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="h-4 w-4 text-gray-500" />
                  <span>{profile.location}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="h-4 w-4 text-gray-500" />
                  <span>{profile.email}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="h-4 w-4 text-gray-500" />
                  <span>{profile.phone}</span>
                </div>
              </div>

              <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="profile">
                    <User className="h-4 w-4 mr-2" />
                    <span className="sr-only md:not-sr-only">Profile</span>
                  </TabsTrigger>
                  <TabsTrigger value="guides">
                    <Leaf className="h-4 w-4 mr-2" />
                    <span className="sr-only md:not-sr-only">Guides</span>
                  </TabsTrigger>
                  <TabsTrigger value="settings">
                    <Settings className="h-4 w-4 mr-2" />
                    <span className="sr-only md:not-sr-only">Settings</span>
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-3">
          <TabsContent value="profile" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>Update your personal information</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleProfileUpdate} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input
                        id="fullName"
                        value={profile.full_name}
                        onChange={(e) => setProfile({ ...profile, full_name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={profile.email}
                        onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        value={profile.phone}
                        onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={profile.location}
                        onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      rows={4}
                      value={profile.bio}
                      onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
                    />
                  </div>

                  <Button type="submit" disabled={isSaving}>
                    {isSaving ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      "Save Changes"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            <div className="mt-6">
              <h3 className="text-xl font-bold mb-4">Farm Statistics</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <FarmStatsCard
                  title="Total Crops"
                  value="8"
                  change="2"
                  isPositive={true}
                  imageSrc={getRandomImage("crops")}
                />
                <FarmStatsCard
                  title="Crop Yield"
                  value="12.5 tons"
                  change="15%"
                  isPositive={true}
                  imageSrc={getRandomImage("crops")}
                />
                <FarmStatsCard
                  title="Land Usage"
                  value="85%"
                  change="5%"
                  isPositive={true}
                  imageSrc={getRandomImage("landscapes")}
                />
              </div>
            </div>

            <div className="mt-6">
              <CropImageGrid title="My Crops" crops={sampleCrops} />
            </div>
          </TabsContent>

          <TabsContent value="guides" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>My Planting Guides</CardTitle>
                <CardDescription>View and manage your saved planting guides</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : guides.length > 0 ? (
                  <div className="space-y-4">
                    {guides.map((guide) => (
                      <Card key={guide.id} className="overflow-hidden hover:shadow-md transition-all">
                        <div className="flex flex-col md:flex-row">
                          <div className="md:w-1/4 h-32 md:h-auto">
                            <img
                              src={getRandomImage("crops") || "/placeholder.svg"}
                              alt={guide.plant_type}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="p-4 md:w-3/4">
                            <div className="flex justify-between items-start mb-2">
                              <h3 className="text-lg font-semibold">{guide.title}</h3>
                              <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                                {guide.plant_type}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                              <MapPin className="h-3 w-3" />
                              <span>{guide.location}</span>
                              <span className="mx-1">•</span>
                              <Calendar className="h-3 w-3" />
                              <span>{formatDate(guide.planting_date)}</span>
                            </div>
                            <div className="flex justify-between items-center mt-4">
                              <span className="text-xs text-muted-foreground">
                                Created on {formatDate(guide.created_at)}
                              </span>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="outline" size="sm" onClick={() => setSelectedGuide(guide)}>
                                    View Guide
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
                                  <DialogHeader>
                                    <DialogTitle>{selectedGuide?.title}</DialogTitle>
                                    <DialogDescription>
                                      {selectedGuide?.location} • Planting Date: {selectedGuide?.planting_date}
                                    </DialogDescription>
                                  </DialogHeader>
                                  <div className="mt-4 prose prose-sm max-w-none">
                                    {selectedGuide?.guide_content ? (
                                      <div className="whitespace-pre-line">{selectedGuide.guide_content}</div>
                                    ) : (
                                      <p>No detailed guide content available.</p>
                                    )}
                                  </div>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <div className="inline-block p-3 bg-green-100 rounded-full mb-4">
                      <Leaf className="h-6 w-6 text-green-600" />
                    </div>
                    <h3 className="text-lg font-medium mb-2">No Planting Guides Yet</h3>
                    <p className="text-muted-foreground mb-4">
                      You haven't created any planting guides yet. Create your first guide to get started.
                    </p>
                    <Button onClick={() => router.push("/planting-guide")}>Create Planting Guide</Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
                <CardDescription>Manage your account settings and preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Email Notifications</h3>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="marketingEmails" className="flex items-center gap-2">
                          Marketing emails
                        </Label>
                        <input
                          type="checkbox"
                          id="marketingEmails"
                          className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                          defaultChecked
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="productUpdates" className="flex items-center gap-2">
                          Product updates
                        </Label>
                        <input
                          type="checkbox"
                          id="productUpdates"
                          className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                          defaultChecked
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="weatherAlerts" className="flex items-center gap-2">
                          Weather alerts
                        </Label>
                        <input
                          type="checkbox"
                          id="weatherAlerts"
                          className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                          defaultChecked
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Privacy</h3>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="profileVisibility" className="flex items-center gap-2">
                          Profile visibility
                        </Label>
                        <select
                          id="profileVisibility"
                          className="rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
                          defaultValue="public"
                        >
                          <option value="public">Public</option>
                          <option value="private">Private</option>
                          <option value="friends">Friends only</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Security</h3>
                    <Button variant="outline">Change Password</Button>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2 text-red-600">Danger Zone</h3>
                    <Button variant="destructive">Delete Account</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </div>
    </div>
  )
}

