"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { MessageSquare, ThumbsUp, Share2, Flag, Send, ImageIcon, Smile, PlusCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { ImageBackgroundSection } from "@/components/image-background-section"
import { getRandomImage } from "@/lib/sample-images"
import { FarmImageCarousel } from "@/components/farm-image-carousel"

interface Post {
  id: string
  author: {
    name: string
    avatar: string
  }
  content: string
  images?: string[]
  likes: number
  comments: number
  timestamp: string
  liked: boolean
}

const samplePosts: Post[] = [
  {
    id: "1",
    author: {
      name: "John Doe",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content:
      "Just harvested my maize crop! The yield is better than expected despite the dry season. Anyone else having a good harvest this year?",
    images: ["/placeholder.svg?height=300&width=500", "/placeholder.svg?height=300&width=500"],
    likes: 24,
    comments: 8,
    timestamp: "2 hours ago",
    liked: false,
  },
  {
    id: "2",
    author: {
      name: "Mary Smith",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content:
      "Has anyone tried the new drought-resistant tomato variety? I'm thinking of planting it next season but would like to hear some experiences first.",
    likes: 15,
    comments: 12,
    timestamp: "5 hours ago",
    liked: true,
  },
  {
    id: "3",
    author: {
      name: "Robert Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "Market prices for beans have increased by 15% this week. Good time to sell if you have stock!",
    images: ["/placeholder.svg?height=300&width=500"],
    likes: 32,
    comments: 5,
    timestamp: "1 day ago",
    liked: false,
  },
]

export default function FarmerForum() {
  const [posts, setPosts] = useState<Post[]>(samplePosts)
  const [newPostContent, setNewPostContent] = useState("")
  const { toast } = useToast()

  const handleLike = (postId: string) => {
    setPosts(
      posts.map((post) => {
        if (post.id === postId) {
          return {
            ...post,
            likes: post.liked ? post.likes - 1 : post.likes + 1,
            liked: !post.liked,
          }
        }
        return post
      }),
    )
  }

  const handleSubmitPost = () => {
    if (!newPostContent.trim()) {
      toast({
        title: "Empty post",
        description: "Please enter some content for your post.",
        variant: "destructive",
      })
      return
    }

    const newPost: Post = {
      id: Date.now().toString(),
      author: {
        name: "You",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content: newPostContent,
      likes: 0,
      comments: 0,
      timestamp: "Just now",
      liked: false,
    }

    setPosts([newPost, ...posts])
    setNewPostContent("")

    toast({
      title: "Post created",
      description: "Your post has been published successfully.",
    })
  }

  const formatPostContent = (content: string) => {
    // Convert hashtags to links
    return content.replace(/#(\w+)/g, '<span class="text-blue-600">#$1</span>')
  }

  return (
    <div className="container py-8">
      {/* Add this section at the top of the component's return statement */}
      <div className="mb-6">
        <ImageBackgroundSection imageSrc={getRandomImage("landscapes")} className="h-[200px]">
          <div className="h-full flex flex-col justify-end">
            <h1 className="text-3xl font-bold text-white">Farmer Forum</h1>
            <p className="text-white/90">Connect with other farmers, share experiences, and discuss market prices</p>
          </div>
        </ImageBackgroundSection>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex gap-4">
                <Avatar>
                  <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Your avatar" />
                  <AvatarFallback>YA</AvatarFallback>
                </Avatar>
                <div className="flex-grow space-y-4">
                  <Textarea
                    placeholder="Share your farming experience or ask a question..."
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    className="min-h-[100px]"
                  />
                  <div className="flex justify-between items-center">
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <ImageIcon className="h-4 w-4 mr-2" />
                        Photo
                      </Button>
                      <Button variant="outline" size="sm">
                        <Smile className="h-4 w-4 mr-2" />
                        Feeling
                      </Button>
                    </div>
                    <Button onClick={handleSubmitPost}>
                      <Send className="h-4 w-4 mr-2" />
                      Post
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-4">
            {posts.map((post) => (
              <Card key={post.id} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex gap-3">
                      <Avatar>
                        <AvatarImage src={post.author.avatar} alt={post.author.name} />
                        <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-medium">{post.author.name}</h3>
                        <p className="text-xs text-muted-foreground">{post.timestamp}</p>
                      </div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <p
                      className="whitespace-pre-line"
                      dangerouslySetInnerHTML={{ __html: formatPostContent(post.content) }}
                    ></p>
                  </div>

                  {post.images && post.images.length > 0 && (
                    <div className="mb-4">
                      <FarmImageCarousel
                        images={post.images.map((src, index) => ({
                          src,
                          alt: `Post image ${index + 1}`,
                        }))}
                        className="h-[300px]"
                      />
                    </div>
                  )}

                  <div className="flex justify-between items-center pt-4 border-t">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleLike(post.id)}
                      className={post.liked ? "text-blue-600" : ""}
                    >
                      <ThumbsUp className="h-4 w-4 mr-2" />
                      {post.likes} Likes
                    </Button>
                    <Button variant="ghost" size="sm">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      {post.comments} Comments
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Share2 className="h-4 w-4 mr-2" />
                      Share
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Flag className="h-4 w-4 mr-2" />
                      Report
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="md:col-span-1">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Popular Topics</CardTitle>
              <CardDescription>Trending discussions in the community</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                    <span className="text-green-600 font-bold">#</span>
                  </div>
                  <div>
                    <h4 className="font-medium">#DroughtResistant</h4>
                    <p className="text-xs text-muted-foreground">128 posts</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                    <span className="text-blue-600 font-bold">#</span>
                  </div>
                  <div>
                    <h4 className="font-medium">#MarketPrices</h4>
                    <p className="text-xs text-muted-foreground">95 posts</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                    <span className="text-purple-600 font-bold">#</span>
                  </div>
                  <div>
                    <h4 className="font-medium">#OrganicFarming</h4>
                    <p className="text-xs text-muted-foreground">76 posts</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-orange-100 flex items-center justify-center">
                    <span className="text-orange-600 font-bold">#</span>
                  </div>
                  <div>
                    <h4 className="font-medium">#SeedSelection</h4>
                    <p className="text-xs text-muted-foreground">64 posts</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Upcoming Events</CardTitle>
              <CardDescription>Farming events and workshops</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border rounded-lg p-3 hover:bg-gray-50 transition-colors">
                  <h4 className="font-medium">Sustainable Farming Workshop</h4>
                  <p className="text-xs text-muted-foreground mb-2">June 25, 2023 • Harare</p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Free</span>
                    <Button size="sm" variant="outline">
                      RSVP
                    </Button>
                  </div>
                </div>
                <div className="border rounded-lg p-3 hover:bg-gray-50 transition-colors">
                  <h4 className="font-medium">Agricultural Trade Fair</h4>
                  <p className="text-xs text-muted-foreground mb-2">July 10-12, 2023 • Bulawayo</p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">$5 Entry</span>
                    <Button size="sm" variant="outline">
                      Details
                    </Button>
                  </div>
                </div>
                <div className="border rounded-lg p-3 hover:bg-gray-50 transition-colors">
                  <h4 className="font-medium">Irrigation Systems Seminar</h4>
                  <p className="text-xs text-muted-foreground mb-2">July 18, 2023 • Online</p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded-full">Virtual</span>
                    <Button size="sm" variant="outline">
                      Register
                    </Button>
                  </div>
                </div>
              </div>
              <Button variant="ghost" className="w-full mt-4">
                <PlusCircle className="h-4 w-4 mr-2" />
                View All Events
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Market Prices</CardTitle>
              <CardDescription>Current prices for common crops</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between items-center py-2 border-b">
                  <span>Maize</span>
                  <span className="font-medium">$280/ton</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b">
                  <span>Tomatoes</span>
                  <span className="font-medium">$0.85/kg</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b">
                  <span>Potatoes</span>
                  <span className="font-medium">$0.65/kg</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b">
                  <span>Beans</span>
                  <span className="font-medium">$1.20/kg</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span>Wheat</span>
                  <span className="font-medium">$320/ton</span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-4">Last updated: June 15, 2023</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

