"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/supabase-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, BarChart2, LineChart, PieChart, Thermometer, Droplet, Wind, Leaf } from "lucide-react"
import { LiveChat } from "@/components/live-chat"

export default function Dashboard() {
  const { user } = useSupabase()
  const router = useRouter()

  const [timeRange, setTimeRange] = useState("week")
  const [cropFilter, setCropFilter] = useState("all")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // If user is not signed in, redirect to landing page
    if (!user) {
      router.push("/")
    }
    setIsLoading(false)
  }, [user, router])

  if (isLoading) {
    return null
  }

  if (!user) {
    return null // Don't render anything while redirecting
  }

  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Advanced Farm Analytics</h1>
          <p className="text-muted-foreground">Detailed metrics and insights for your farm</p>
        </div>

        <div className="flex gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day">Last 24 Hours</SelectItem>
              <SelectItem value="week">Last Week</SelectItem>
              <SelectItem value="month">Last Month</SelectItem>
              <SelectItem value="year">Last Year</SelectItem>
            </SelectContent>
          </Select>

          <Select value={cropFilter} onValueChange={setCropFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Crop Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Crops</SelectItem>
              <SelectItem value="maize">Maize</SelectItem>
              <SelectItem value="tomatoes">Tomatoes</SelectItem>
              <SelectItem value="potatoes">Potatoes</SelectItem>
              <SelectItem value="beans">Beans</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-green-600" />
              Planting Calendar
            </CardTitle>
            <CardDescription>Upcoming tasks and events</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Today</p>
                  <p className="text-sm text-muted-foreground">First weeding - Maize</p>
                </div>
                <Button variant="outline" size="sm">
                  Complete
                </Button>
              </div>
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Tomorrow</p>
                  <p className="text-sm text-muted-foreground">Apply fertilizer - Tomatoes</p>
                </div>
                <Button variant="outline" size="sm">
                  Complete
                </Button>
              </div>
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">May 20, 2025</p>
                  <p className="text-sm text-muted-foreground">Harvest - Potatoes</p>
                </div>
                <Button variant="outline" size="sm">
                  Complete
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Thermometer className="h-5 w-5 mr-2 text-green-600" />
              Weather Trends
            </CardTitle>
            <CardDescription>Temperature and rainfall patterns</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[200px] relative">
              <div className="absolute inset-0">
                <svg className="w-full h-full">
                  <rect x="0" y="0" width="100%" height="100%" fill="#f8fafc" />

                  {/* X and Y axes */}
                  <line x1="40" y1="20" x2="40" y2="180" stroke="#94a3b8" strokeWidth="1" />
                  <line x1="40" y1="180" x2="320" y2="180" stroke="#94a3b8" strokeWidth="1" />

                  {/* Temperature line */}
                  <path
                    d="M 60,80 L 100,70 L 140,90 L 180,60 L 220,50 L 260,70 L 300,40"
                    fill="none"
                    stroke="#16a34a"
                    strokeWidth="2"
                  />

                  {/* Rainfall bars */}
                  <rect x="55" y="150" width="10" height="30" fill="rgba(59, 130, 246, 0.5)" />
                  <rect x="95" y="160" width="10" height="20" fill="rgba(59, 130, 246, 0.5)" />
                  <rect x="135" y="140" width="10" height="40" fill="rgba(59, 130, 246, 0.5)" />
                  <rect x="175" y="170" width="10" height="10" fill="rgba(59, 130, 246, 0.5)" />
                  <rect x="215" y="130" width="10" height="50" fill="rgba(59, 130, 246, 0.5)" />
                  <rect x="255" y="155" width="10" height="25" fill="rgba(59, 130, 246, 0.5)" />
                  <rect x="295" y="165" width="10" height="15" fill="rgba(59, 130, 246, 0.5)" />

                  {/* Legend */}
                  <circle cx="50" cy="20" r="4" fill="#16a34a" />
                  <text x="60" y="24" fontSize="10" fill="#64748b">
                    Temperature
                  </text>
                  <rect x="120" y="16" width="8" height="8" fill="rgba(59, 130, 246, 0.5)" />
                  <text x="135" y="24" fontSize="10" fill="#64748b">
                    Rainfall
                  </text>
                </svg>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Leaf className="h-5 w-5 mr-2 text-green-600" />
              Crop Health
            </CardTitle>
            <CardDescription>Current status of your crops</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Maize</span>
                  <span className="text-sm text-green-600">Excellent</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "90%" }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Tomatoes</span>
                  <span className="text-sm text-yellow-600">Good</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "75%" }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Potatoes</span>
                  <span className="text-sm text-orange-600">Fair</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-orange-500 h-2.5 rounded-full" style={{ width: "60%" }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Beans</span>
                  <span className="text-sm text-green-600">Excellent</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "95%" }}></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="performance" className="mb-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="performance">Farm Performance</TabsTrigger>
          <TabsTrigger value="weather">Weather Analysis</TabsTrigger>
          <TabsTrigger value="growth">Growth Tracking</TabsTrigger>
          <TabsTrigger value="soil">Soil Health</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart2 className="h-5 w-5 mr-2 text-green-600" />
                Farm Performance Metrics
              </CardTitle>
              <CardDescription>Yield, efficiency, and resource utilization</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Yield Comparison</h3>
                  <div className="h-[300px] relative">
                    <div className="absolute inset-0">
                      <svg className="w-full h-full">
                        <rect x="0" y="0" width="100%" height="100%" fill="#f8fafc" />

                        {/* X and Y axes */}
                        <line x1="50" y1="30" x2="50" y2="270" stroke="#94a3b8" strokeWidth="1" />
                        <line x1="50" y1="270" x2="350" y2="270" stroke="#94a3b8" strokeWidth="1" />

                        {/* X-axis labels */}
                        <text x="100" y="290" textAnchor="middle" fill="#64748b" fontSize="12">
                          Maize
                        </text>
                        <text x="175" y="290" textAnchor="middle" fill="#64748b" fontSize="12">
                          Tomatoes
                        </text>
                        <text x="250" y="290" textAnchor="middle" fill="#64748b" fontSize="12">
                          Potatoes
                        </text>
                        <text x="325" y="290" textAnchor="middle" fill="#64748b" fontSize="12">
                          Beans
                        </text>

                        {/* Y-axis labels */}
                        <text x="40" y="270" textAnchor="end" fill="#64748b" fontSize="10">
                          0
                        </text>
                        <text x="40" y="210" textAnchor="end" fill="#64748b" fontSize="10">
                          25%
                        </text>
                        <text x="40" y="150" textAnchor="end" fill="#64748b" fontSize="10">
                          50%
                        </text>
                        <text x="40" y="90" textAnchor="end" fill="#64748b" fontSize="10">
                          75%
                        </text>
                        <text x="40" y="30" textAnchor="end" fill="#64748b" fontSize="10">
                          100%
                        </text>

                        {/* Current yield bars */}
                        <rect x="80" y="150" width="20" height="120" fill="rgba(22, 163, 74, 0.7)" />
                        <rect x="155" y="90" width="20" height="180" fill="rgba(22, 163, 74, 0.7)" />
                        <rect x="230" y="180" width="20" height="90" fill="rgba(22, 163, 74, 0.7)" />
                        <rect x="305" y="120" width="20" height="150" fill="rgba(22, 163, 74, 163,74,0.7)" />
                        <rect x="305" y="120" width="20" height="150" fill="rgba(22, 163, 74, 0.7)" />

                        {/* Target yield bars */}
                        <rect x="105" y="90" width="20" height="180" fill="rgba(22, 163, 74, 0.3)" />
                        <rect x="180" y="60" width="20" height="210" fill="rgba(22, 163, 74, 0.3)" />
                        <rect x="255" y="120" width="20" height="150" fill="rgba(22, 163, 74, 0.3)" />
                        <rect x="330" y="90" width="20" height="180" fill="rgba(22, 163, 74, 0.3)" />

                        {/* Legend */}
                        <rect x="100" y="20" width="15" height="15" fill="rgba(22, 163, 74, 0.7)" />
                        <text x="120" y="30" fontSize="10" fill="#64748b">
                          Current Yield
                        </text>
                        <rect x="200" y="20" width="15" height="15" fill="rgba(22, 163, 74, 0.3)" />
                        <text x="220" y="30" fontSize="10" fill="#64748b">
                          Target Yield
                        </text>
                      </svg>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Resource Utilization</h3>
                  <div className="h-[300px] relative">
                    <div className="absolute inset-0">
                      <svg className="w-full h-full">
                        <rect x="0" y="0" width="100%" height="100%" fill="#f8fafc" />

                        {/* Pie chart */}
                        <circle cx="175" cy="150" r="100" fill="transparent" stroke="#e2e8f0" strokeWidth="40" />
                        <circle
                          cx="175"
                          cy="150"
                          r="100"
                          fill="transparent"
                          stroke="#16a34a"
                          strokeWidth="40"
                          strokeDasharray="157 628"
                        />
                        <circle
                          cx="175"
                          cy="150"
                          r="100"
                          fill="transparent"
                          stroke="#3b82f6"
                          strokeWidth="40"
                          strokeDasharray="188 628"
                          strokeDashoffset="-157"
                        />
                        <circle
                          cx="175"
                          cy="150"
                          r="100"
                          fill="transparent"
                          stroke="#eab308"
                          strokeWidth="40"
                          strokeDasharray="94 628"
                          strokeDashoffset="-345"
                        />
                        <circle
                          cx="175"
                          cy="150"
                          r="100"
                          fill="transparent"
                          stroke="#ef4444"
                          strokeWidth="40"
                          strokeDasharray="63 628"
                          strokeDashoffset="-439"
                        />
                        <circle
                          cx="175"
                          cy="150"
                          r="100"
                          fill="transparent"
                          stroke="#8b5cf6"
                          strokeWidth="40"
                          strokeDasharray="126 628"
                          strokeDashoffset="-502"
                        />

                        {/* Legend */}
                        <circle cx="50" cy="230" r="6" fill="#16a34a" />
                        <text x="65" y="234" fontSize="12" fill="#64748b">
                          Water (25%)
                        </text>
                        <circle cx="50" cy="250" r="6" fill="#3b82f6" />
                        <text x="65" y="254" fontSize="12" fill="#64748b">
                          Fertilizer (30%)
                        </text>
                        <circle cx="50" cy="270" r="6" fill="#eab308" />
                        <text x="65" y="274" fontSize="12" fill="#64748b">
                          Labor (15%)
                        </text>
                        <circle cx="200" cy="230" r="6" fill="#ef4444" />
                        <text x="215" y="234" fontSize="12" fill="#64748b">
                          Pesticides (10%)
                        </text>
                        <circle cx="200" cy="250" r="6" fill="#8b5cf6" />
                        <text x="215" y="254" fontSize="12" fill="#64748b">
                          Equipment (20%)
                        </text>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="weather" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <LineChart className="h-5 w-5 mr-2 text-green-600" />
                Weather Pattern Analysis
              </CardTitle>
              <CardDescription>Temperature, rainfall, and humidity trends</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="flex flex-col items-center justify-center p-4 bg-green-50 rounded-lg">
                  <Thermometer className="h-8 w-8 text-green-600 mb-2" />
                  <h3 className="text-lg font-medium">Average Temperature</h3>
                  <p className="text-3xl font-bold">24°C</p>
                  <p className="text-sm text-muted-foreground">2°C above normal</p>
                </div>
                <div className="flex flex-col items-center justify-center p-4 bg-blue-50 rounded-lg">
                  <Droplet className="h-8 w-8 text-blue-600 mb-2" />
                  <h3 className="text-lg font-medium">Total Rainfall</h3>
                  <p className="text-3xl font-bold">78mm</p>
                  <p className="text-sm text-muted-foreground">15mm below normal</p>
                </div>
                <div className="flex flex-col items-center justify-center p-4 bg-purple-50 rounded-lg">
                  <Wind className="h-8 w-8 text-purple-600 mb-2" />
                  <h3 className="text-lg font-medium">Average Humidity</h3>
                  <p className="text-3xl font-bold">65%</p>
                  <p className="text-sm text-muted-foreground">5% above normal</p>
                </div>
              </div>

              <div className="h-[300px] relative">
                <div className="absolute inset-0">
                  <svg className="w-full h-full">
                    <rect x="0" y="0" width="100%" height="100%" fill="#f8fafc" />

                    {/* X and Y axes */}
                    <line x1="50" y1="30" x2="50" y2="270" stroke="#94a3b8" strokeWidth="1" />
                    <line x1="50" y1="270" x2="650" y2="270" stroke="#94a3b8" strokeWidth="1" />

                    {/* X-axis labels */}
                    <text x="100" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      Jan
                    </text>
                    <text x="150" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      Feb
                    </text>
                    <text x="200" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      Mar
                    </text>
                    <text x="250" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      Apr
                    </text>
                    <text x="300" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      May
                    </text>
                    <text x="350" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      Jun
                    </text>
                    <text x="400" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      Jul
                    </text>
                    <text x="450" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      Aug
                    </text>
                    <text x="500" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      Sep
                    </text>
                    <text x="550" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      Oct
                    </text>
                    <text x="600" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      Nov
                    </text>
                    <text x="650" y="290" textAnchor="middle" fill="#64748b" fontSize="10">
                      Dec
                    </text>

                    {/* Temperature line */}
                    <path
                      d="M 100,150 L 150,140 L 200,120 L 250,100 L 300,80 L 350,60 L 400,70 L 450,90 L 500,110 L 550,130 L 600,150 L 650,160"
                      fill="none"
                      stroke="#16a34a"
                      strokeWidth="2"
                    />

                    {/* Rainfall bars */}
                    <rect x="95" y="230" width="10" height="40" fill="rgba(59, 130, 246, 0.5)" />
                    <rect x="145" y="220" width="10" height="50" fill="rgba(59, 130, 246, 0.5)" />
                    <rect x="195" y="200" width="10" height="70" fill="rgba(59, 130, 246, 0.5)" />
                    <rect x="245" y="210" width="10" height="60" fill="rgba(59, 130, 246, 0.5)" />
                    <rect x="295" y="240" width="10" height="30" fill="rgba(59, 130, 246, 0.5)" />
                    <rect x="345" y="250" width="10" height="20" fill="rgba(59, 130, 246, 0.5)" />
                    <rect x="395" y="245" width="10" height="25" fill="rgba(59, 130, 246, 0.5)" />
                    <rect x="445" y="235" width="10" height="35" fill="rgba(59, 130, 246, 0.5)" />
                    <rect x="495" y="225" width="10" height="45" fill="rgba(59, 130, 246, 0.5)" />
                    <rect x="545" y="215" width="10" height="55" fill="rgba(59, 130, 246, 0.5)" />
                    <rect x="595" y="210" width="10" height="60" fill="rgba(59, 130, 246, 0.5)" />
                    <rect x="645" y="220" width="10" height="50" fill="rgba(59, 130, 246, 0.5)" />

                    {/* Legend */}
                    <line x1="50" y1="30" x2="70" y2="30" stroke="#16a34a" strokeWidth="2" />
                    <text x="75" y="34" fontSize="10" fill="#64748b">
                      Temperature
                    </text>
                    <rect x="150" y="26" width="10" height="8" fill="rgba(59, 130, 246, 0.5)" />
                    <text x="165" y="34" fontSize="10" fill="#64748b">
                      Rainfall
                    </text>
                  </svg>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="growth" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Leaf className="h-5 w-5 mr-2 text-green-600" />
                Crop Growth Tracking
              </CardTitle>
              <CardDescription>Monitor growth stages and calendar adherence</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Growth Stage Progress</h3>
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Maize</span>
                        <span className="text-sm text-green-600">Tasseling (65%)</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "65%" }}></div>
                      </div>
                      <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                        <span>Planting</span>
                        <span>Vegetative</span>
                        <span>Tasseling</span>
                        <span>Silking</span>
                        <span>Maturity</span>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Tomatoes</span>
                        <span className="text-sm text-green-600">Fruiting (80%)</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "80%" }}></div>
                      </div>
                      <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                        <span>Seedling</span>
                        <span>Vegetative</span>
                        <span>Flowering</span>
                        <span>Fruiting</span>
                        <span>Harvest</span>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Potatoes</span>
                        <span className="text-sm text-green-600">Tuber Formation (45%)</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "45%" }}></div>
                      </div>
                      <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                        <span>Sprouting</span>
                        <span>Vegetative</span>
                        <span>Tuber Formation</span>
                        <span>Maturation</span>
                        <span>Harvest</span>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Beans</span>
                        <span className="text-sm text-green-600">Flowering (35%)</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "35%" }}></div>
                      </div>
                      <div className="flex justify-between mt-1 text-xs text-muted-foreground">
                        <span>Germination</span>
                        <span>Vegetative</span>
                        <span>Flowering</span>
                        <span>Pod Formation</span>
                        <span>Harvest</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Calendar Adherence</h3>
                  <div className="h-[300px] relative">
                    <div className="absolute inset-0">
                      <svg className="w-full h-full">
                        <rect x="0" y="0" width="100%" height="100%" fill="#f8fafc" />

                        {/* X and Y axes */}
                        <line x1="50" y1="30" x2="50" y2="270" stroke="#94a3b8" strokeWidth="1" />
                        <line x1="50" y1="270" x2="350" y2="270" stroke="#94a3b8" strokeWidth="1" />

                        {/* X-axis labels */}
                        <text x="100" y="290" textAnchor="middle" fill="#64748b" fontSize="12">
                          Maize
                        </text>
                        <text x="175" y="290" textAnchor="middle" fill="#64748b" fontSize="12">
                          Tomatoes
                        </text>
                        <text x="250" y="290" textAnchor="middle" fill="#64748b" fontSize="12">
                          Potatoes
                        </text>
                        <text x="325" y="290" textAnchor="middle" fill="#64748b" fontSize="12">
                          Beans
                        </text>

                        {/* Y-axis labels */}
                        <text x="40" y="270" textAnchor="end" fill="#64748b" fontSize="10">
                          0%
                        </text>
                        <text x="40" y="210" textAnchor="end" fill="#64748b" fontSize="10">
                          25%
                        </text>
                        <text x="40" y="150" textAnchor="end" fill="#64748b" fontSize="10">
                          50%
                        </text>
                        <text x="40" y="90" textAnchor="end" fill="#64748b" fontSize="10">
                          75%
                        </text>
                        <text x="40" y="30" textAnchor="end" fill="#64748b" fontSize="10">
                          100%
                        </text>

                        {/* Planned vs Actual bars */}
                        <rect x="80" y="90" width="15" height="180" fill="rgba(22, 163, 74, 0.7)" />
                        <rect x="100" y="120" width="15" height="150" fill="rgba(239, 68, 68, 0.7)" />

                        <rect x="155" y="60" width="15" height="210" fill="rgba(22, 163, 74, 0.7)" />
                        <rect x="175" y="60" width="15" height="210" fill="rgba(239, 68, 68, 0.7)" />

                        <rect x="230" y="120" width="15" height="150" fill="rgba(22, 163, 74, 0.7)" />
                        <rect x="250" y="150" width="15" height="120" fill="rgba(239, 68, 68, 0.7)" />

                        <rect x="305" y="150" width="15" height="120" fill="rgba(22, 163, 74, 0.7)" />
                        <rect x="325" y="180" width="15" height="90" fill="rgba(239, 68, 68, 0.7)" />

                        {/* Legend */}
                        <rect x="100" y="20" width="15" height="15" fill="rgba(22, 163, 74, 0.7)" />
                        <text x="120" y="30" fontSize="10" fill="#64748b">
                          Planned
                        </text>
                        <rect x="200" y="20" width="15" height="15" fill="rgba(239, 68, 68, 0.7)" />
                        <text x="220" y="30" fontSize="10" fill="#64748b">
                          Actual
                        </text>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="soil" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <PieChart className="h-5 w-5 mr-2 text-green-600" />
                Soil Health Monitoring
              </CardTitle>
              <CardDescription>Nutrient levels, pH, and moisture content</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Nutrient Levels</h3>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Nitrogen (N)</span>
                      <span className="text-sm text-green-600">Good</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "75%" }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Phosphorus (P)</span>
                      <span className="text-sm text-yellow-600">Fair</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "60%" }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Potassium (K)</span>
                      <span className="text-sm text-green-600">Excellent</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "90%" }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Organic Matter</span>
                      <span className="text-sm text-green-600">Good</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-green-600 h-2.5 rounded-full" style={{ width: "70%" }}></div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-center justify-center">
                  <h3 className="text-lg font-medium mb-4">Soil pH</h3>
                  <div className="relative h-[150px] w-[150px]">
                    <div className="absolute inset-0">
                      <svg className="w-full h-full">
                        <circle cx="75" cy="75" r="70" fill="transparent" stroke="#e2e8f0" strokeWidth="10" />
                        <circle
                          cx="75"
                          cy="75"
                          r="70"
                          fill="transparent"
                          stroke="#16a34a"
                          strokeWidth="10"
                          strokeDasharray="220 440"
                        />
                        <text
                          x="75"
                          y="75"
                          textAnchor="middle"
                          dominantBaseline="middle"
                          fontSize="24"
                          fontWeight="bold"
                          fill="#16a34a"
                        >
                          6.5
                        </text>
                        <text x="75" y="95" textAnchor="middle" dominantBaseline="middle" fontSize="12" fill="#64748b">
                          Optimal
                        </text>
                      </svg>
                    </div>
                  </div>
                  <div className="w-full mt-4">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Acidic (0)</span>
                      <span>Neutral (7)</span>
                      <span>Alkaline (14)</span>
                    </div>
                    <div className="h-2 w-full bg-gradient-to-r from-red-500 via-green-500 to-blue-500 rounded-full mt-1"></div>
                  </div>
                </div>

                <div className="flex flex-col items-center justify-center">
                  <h3 className="text-lg font-medium mb-4">Soil Moisture</h3>
                  <div className="relative h-[150px] w-[150px]">
                    <div className="absolute inset-0">
                      <svg className="w-full h-full">
                        <circle cx="75" cy="75" r="70" fill="transparent" stroke="#e2e8f0" strokeWidth="10" />
                        <circle
                          cx="75"
                          cy="75"
                          r="70"
                          fill="transparent"
                          stroke="#3b82f6"
                          strokeWidth="10"
                          strokeDasharray="264 440"
                        />
                        <text
                          x="75"
                          y="75"
                          textAnchor="middle"
                          dominantBaseline="middle"
                          fontSize="24"
                          fontWeight="bold"
                          fill="#3b82f6"
                        >
                          60%
                        </text>
                        <text x="75" y="95" textAnchor="middle" dominantBaseline="middle" fontSize="12" fill="#64748b">
                          Good
                        </text>
                      </svg>
                    </div>
                  </div>
                  <div className="w-full mt-4">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Dry (0%)</span>
                      <span>Optimal (40-70%)</span>
                      <span>Wet (100%)</span>
                    </div>
                    <div className="h-2 w-full bg-gradient-to-r from-yellow-500 via-blue-500 to-blue-700 rounded-full mt-1"></div>
                  </div>
                </div>
              </div>

              <div className="h-[200px] relative">
                <div className="absolute inset-0">
                  <svg className="w-full h-full">
                    <rect x="0" y="0" width="100%" height="100%" fill="#f8fafc" />

                    {/* X and Y axes */}
                    <line x1="50" y1="30" x2="50" y2="170" stroke="#94a3b8" strokeWidth="1" />
                    <line x1="50" y1="170" x2="650" y2="170" stroke="#94a3b8" strokeWidth="1" />

                    {/* X-axis labels */}
                    <text x="100" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      Jan
                    </text>
                    <text x="150" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      Feb
                    </text>
                    <text x="200" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      Mar
                    </text>
                    <text x="250" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      Apr
                    </text>
                    <text x="300" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      May
                    </text>
                    <text x="350" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      Jun
                    </text>
                    <text x="400" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      Jul
                    </text>
                    <text x="450" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      Aug
                    </text>
                    <text x="500" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      Sep
                    </text>
                    <text x="550" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      Oct
                    </text>
                    <text x="600" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      Nov
                    </text>
                    <text x="650" y="190" textAnchor="middle" fill="#64748b" fontSize="10">
                      Dec
                    </text>

                    {/* Moisture line */}
                    <path
                      d="M 100,100 L 150,90 L 200,80 L 250,70 L 300,60 L 350,80 L 400,100 L 450,110 L 500,90 L 550,70 L 600,80 L 650,90"
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="2"
                    />

                    {/* pH line */}
                    <path
                      d="M 100,90 L 150,95 L 200,100 L 250,90 L 300,85 L 350,90 L 400,95 L 450,100 L 500,95 L 550,90 L 600,85 L 650,90"
                      fill="none"
                      stroke="#16a34a"
                      strokeWidth="2"
                      strokeDasharray="5,5"
                    />

                    {/* Legend */}
                    <line x1="50" y1="30" x2="70" y2="30" stroke="#3b82f6" strokeWidth="2" />
                    <text x="75" y="34" fontSize="10" fill="#64748b">
                      Moisture
                    </text>
                    <line x1="150" y1="30" x2="170" y2="30" stroke="#16a34a" strokeWidth="2" strokeDasharray="5,5" />
                    <text x="175" y="34" fontSize="10" fill="#64748b">
                      pH
                    </text>
                  </svg>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-green-600" />
              IoT Sensor Data
            </CardTitle>
            <CardDescription>Real-time data from farm sensors</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col items-center justify-center p-4 bg-blue-50 rounded-lg">
                  <Droplet className="h-6 w-6 text-blue-600 mb-2" />
                  <h3 className="text-sm font-medium">Soil Moisture</h3>
                  <p className="text-2xl font-bold">65%</p>
                  <p className="text-xs text-muted-foreground">Last updated: 15 min ago</p>
                </div>
                <div className="flex flex-col items-center justify-center p-4 bg-green-50 rounded-lg">
                  <Thermometer className="h-6 w-6 text-green-600 mb-2" />
                  <h3 className="text-sm font-medium">Soil Temperature</h3>
                  <p className="text-2xl font-bold">22°C</p>
                  <p className="text-xs text-muted-foreground">Last updated: 10 min ago</p>
                </div>
              </div>

              <div className="h-[200px] relative">
                <div className="absolute inset-0">
                  <svg className="w-full h-full">
                    <rect x="0" y="0" width="100%" height="100%" fill="#f8fafc" />

                    {/* X and Y axes */}
                    <line x1="40" y1="20" x2="40" y2="180" stroke="#94a3b8" strokeWidth="1" />
                    <line x1="40" y1="180" x2="360" y2="180" stroke="#94a3b8" strokeWidth="1" />

                    {/* Sensor data lines */}
                    <path
                      d="M 60,100 L 90,90 L 120,95 L 150,85 L 180,80 L 210,85 L 240,90 L 270,80 L 300,75 L 330,80"
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="2"
                    />
                    <path
                      d="M 60,120 L 90,125 L 120,130 L 150,120 L 180,115 L 210,110 L 240,115 L 270,120 L 300,125 L 330,120"
                      fill="none"
                      stroke="#16a34a"
                      strokeWidth="2"
                    />

                    {/* Data points */}
                    <circle cx="60" cy="100" r="3" fill="#3b82f6" />
                    <circle cx="90" cy="90" r="3" fill="#3b82f6" />
                    <circle cx="120" cy="95" r="3" fill="#3b82f6" />
                    <circle cx="150" cy="85" r="3" fill="#3b82f6" />
                    <circle cx="180" cy="80" r="3" fill="#3b82f6" />
                    <circle cx="210" cy="85" r="3" fill="#3b82f6" />
                    <circle cx="240" cy="90" r="3" fill="#3b82f6" />
                    <circle cx="270" cy="80" r="3" fill="#3b82f6" />
                    <circle cx="300" cy="75" r="3" fill="#3b82f6" />
                    <circle cx="330" cy="80" r="3" fill="#3b82f6" />

                    <circle cx="60" cy="120" r="3" fill="#16a34a" />
                    <circle cx="90" cy="125" r="3" fill="#16a34a" />
                    <circle cx="120" cy="130" r="3" fill="#16a34a" />
                    <circle cx="150" cy="120" r="3" fill="#16a34a" />
                    <circle cx="180" cy="115" r="3" fill="#16a34a" />
                    <circle cx="210" cy="110" r="3" fill="#16a34a" />
                    <circle cx="240" cy="115" r="3" fill="#16a34a" />
                    <circle cx="270" cy="120" r="3" fill="#16a34a" />
                    <circle cx="300" cy="125" r="3" fill="#16a34a" />
                    <circle cx="330" cy="120" r="3" fill="#16a34a" />

                    {/* Legend */}
                    <circle cx="50" cy="20" r="3" fill="#3b82f6" />
                    <text x="60" y="24" fontSize="10" fill="#64748b">
                      Moisture
                    </text>
                    <circle cx="120" cy="20" r="3" fill="#16a34a" />
                    <text x="130" y="24" fontSize="10" fill="#64748b">
                      Temperature
                    </text>
                  </svg>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart2 className="h-5 w-5 mr-2 text-green-600" />
              Recommendations
            </CardTitle>
            <CardDescription>AI-powered insights for your farm</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                <h3 className="font-medium text-green-700 mb-1">Irrigation Recommendation</h3>
                <p className="text-sm text-muted-foreground">
                  Based on soil moisture and weather forecast, increase irrigation for maize by 15% over the next 3
                  days.
                </p>
              </div>
              <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                <h3 className="font-medium text-yellow-700 mb-1">Pest Alert</h3>
                <p className="text-sm text-muted-foreground">
                  Conditions are favorable for fall armyworm in maize. Consider preventative measures within the next 5
                  days.
                </p>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <h3 className="font-medium text-blue-700 mb-1">Fertilizer Optimization</h3>
                <p className="text-sm text-muted-foreground">
                  Soil analysis indicates phosphorus deficiency in tomato plots. Apply 20kg/ha of phosphate fertilizer.
                </p>
              </div>
              <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                <h3 className="font-medium text-purple-700 mb-1">Harvest Planning</h3>
                <p className="text-sm text-muted-foreground">
                  Optimal potato harvest window is approaching (7-10 days). Prepare storage facilities and labor
                  resources.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <LiveChat />
    </div>
  )
}

