import { Skeleton } from "@/components/ui/skeleton"

export default function Loading() {
  return (
    <div className="container py-6">
      <div className="flex flex-col space-y-4">
        <div className="flex justify-between items-center">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-64" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Skeleton className="h-80 md:col-span-1" />
          <Skeleton className="h-80 md:col-span-2" />
          <Skeleton className="h-60 md:col-span-1" />
          <Skeleton className="h-60 md:col-span-2" />
          <Skeleton className="h-60 md:col-span-1" />
        </div>
      </div>
    </div>
  )
}

