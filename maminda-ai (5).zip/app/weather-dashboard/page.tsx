"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Loader2, Search, MapPin, Thermometer, Droplets, Wind, Cloud, CloudRain } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { WeatherImageCard } from "@/components/weather-image-card"
import { ImageBackgroundSection } from "@/components/image-background-section"
import { getRandomImage } from "@/lib/sample-images"

interface WeatherData {
  location: string
  current: {
    temp_c: number
    temp_f: number
    condition: {
      text: string
      icon: string
    }
    wind_kph: number
    wind_dir: string
    humidity: number
    feelslike_c: number
    feelslike_f: number
    uv: number
    precip_mm: number
  }
  forecast?: {
    forecastday: Array<{
      date: string
      day: {
        maxtemp_c: number
        mintemp_c: number
        avgtemp_c: number
        condition: {
          text: string
          icon: string
        }
        daily_chance_of_rain: number
        totalprecip_mm: number
      }
    }>
  }
}

export default function WeatherDashboard() {
  const [location, setLocation] = useState("")
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const fetchWeather = async (searchLocation: string) => {
    if (!searchLocation) {
      toast({
        title: "Location required",
        description: "Please enter a location to check the weather.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      // Mock data for demonstration
      setTimeout(() => {
        const mockWeather: WeatherData = {
          location: searchLocation,
          current: {
            temp_c: 24,
            temp_f: 75.2,
            condition: {
              text: "Partly cloudy",
              icon: "//cdn.weatherapi.com/weather/64x64/day/116.png",
            },
            wind_kph: 15,
            wind_dir: "NE",
            humidity: 65,
            feelslike_c: 26,
            feelslike_f: 78.8,
            uv: 5,
            precip_mm: 0,
          },
          forecast: {
            forecastday: [
              {
                date: "2023-06-15",
                day: {
                  maxtemp_c: 26,
                  mintemp_c: 18,
                  avgtemp_c: 22,
                  condition: {
                    text: "Sunny",
                    icon: "//cdn.weatherapi.com/weather/64x64/day/113.png",
                  },
                  daily_chance_of_rain: 0,
                  totalprecip_mm: 0,
                },
              },
              {
                date: "2023-06-16",
                day: {
                  maxtemp_c: 28,
                  mintemp_c: 19,
                  avgtemp_c: 23.5,
                  condition: {
                    text: "Partly cloudy",
                    icon: "//cdn.weatherapi.com/weather/64x64/day/116.png",
                  },
                  daily_chance_of_rain: 20,
                  totalprecip_mm: 0.5,
                },
              },
              {
                date: "2023-06-17",
                day: {
                  maxtemp_c: 25,
                  mintemp_c: 17,
                  avgtemp_c: 21,
                  condition: {
                    text: "Light rain",
                    icon: "//cdn.weatherapi.com/weather/64x64/day/296.png",
                  },
                  daily_chance_of_rain: 70,
                  totalprecip_mm: 2.5,
                },
              },
            ],
          },
        }
        setWeather(mockWeather)
        setLoading(false)
      }, 1500)
    } catch (error) {
      console.error("Error fetching weather:", error)
      toast({
        title: "Error fetching weather",
        description: "Failed to fetch weather data. Please try again.",
        variant: "destructive",
      })
      setLoading(false)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchWeather(location)
  }

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: "long", month: "short", day: "numeric" }
    return new Date(dateString).toLocaleDateString("en-US", options)
  }

  const getWeatherImage = (condition: string) => {
    const lowerCondition = condition.toLowerCase()

    if (lowerCondition.includes("sun") || lowerCondition.includes("clear")) {
      return "/placeholder.svg?height=200&width=400"
    } else if (lowerCondition.includes("cloud")) {
      return "/placeholder.svg?height=200&width=400"
    } else if (lowerCondition.includes("rain")) {
      return "/placeholder.svg?height=200&width=400"
    } else {
      return "/placeholder.svg?height=200&width=400"
    }
  }

  return (
    <div className="container py-8">
      {/* Add this section at the top of the component's return statement */}
      <div className="mb-6">
        <ImageBackgroundSection imageSrc={getRandomImage("landscapes")} className="h-[200px]">
          <div className="h-full flex flex-col justify-end">
            <h1 className="text-3xl font-bold text-white">Weather Dashboard</h1>
            <p className="text-white/90">Get accurate weather forecasts for your farm location</p>
          </div>
        </ImageBackgroundSection>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Weather Forecast</CardTitle>
            <CardDescription>Check the weather for your location</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="flex gap-2 mb-6">
              <div className="relative flex-grow">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <Input
                  type="text"
                  placeholder="Enter location (e.g., Harare, Zimbabwe)"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button type="submit" disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              </Button>
            </form>

            {loading ? (
              <div className="flex flex-col items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
                <p className="text-muted-foreground">Fetching weather data...</p>
              </div>
            ) : weather ? (
              <div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-xl flex items-center">
                        <MapPin className="h-5 w-5 mr-2 text-blue-600" />
                        {weather.location}
                      </CardTitle>
                      <CardDescription>Current Weather</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-4xl font-bold">{weather.current.temp_c}°C</div>
                          <div className="text-sm text-muted-foreground">
                            Feels like {weather.current.feelslike_c}°C
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-medium">{weather.current.condition.text}</div>
                          <div className="flex items-center justify-end gap-2 text-sm text-muted-foreground">
                            <Droplets className="h-4 w-4 text-blue-500" />
                            {weather.current.humidity}% Humidity
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-2 mt-6">
                        <div className="flex flex-col items-center p-2 bg-white/60 rounded-lg">
                          <Wind className="h-5 w-5 text-blue-600 mb-1" />
                          <div className="text-xs font-medium">Wind</div>
                          <div className="text-sm">{weather.current.wind_kph} km/h</div>
                        </div>
                        <div className="flex flex-col items-center p-2 bg-white/60 rounded-lg">
                          <Thermometer className="h-5 w-5 text-orange-500 mb-1" />
                          <div className="text-xs font-medium">UV Index</div>
                          <div className="text-sm">{weather.current.uv}</div>
                        </div>
                        <div className="flex flex-col items-center p-2 bg-white/60 rounded-lg">
                          <CloudRain className="h-5 w-5 text-blue-500 mb-1" />
                          <div className="text-xs font-medium">Precipitation</div>
                          <div className="text-sm">{weather.current.precip_mm} mm</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="grid grid-cols-1 gap-4">
                    <WeatherImageCard
                      condition={weather.current.condition.text}
                      temperature={`${weather.current.temp_c}°C`}
                      description={`Humidity: ${weather.current.humidity}% | Wind: ${weather.current.wind_kph} km/h ${weather.current.wind_dir}`}
                      imageSrc={getWeatherImage(weather.current.condition.text)}
                    />
                  </div>
                </div>

                {weather.forecast && (
                  <div>
                    <h3 className="text-lg font-semibold mb-4">3-Day Forecast</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {weather.forecast.forecastday.map((day, index) => (
                        <WeatherImageCard
                          key={index}
                          condition={day.day.condition.text}
                          temperature={`${day.day.mintemp_c}° - ${day.day.maxtemp_c}°C`}
                          description={`Rain: ${day.day.daily_chance_of_rain}% | Precip: ${day.day.totalprecip_mm} mm`}
                          imageSrc={getWeatherImage(day.day.condition.text)}
                          date={formatDate(day.date)}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="bg-blue-50 p-4 rounded-full mb-4">
                  <Cloud className="h-10 w-10 text-blue-500" />
                </div>
                <h3 className="text-lg font-medium mb-2">No Weather Data</h3>
                <p className="text-muted-foreground max-w-md">
                  Enter a location above to check the current weather and forecast for your farm.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

