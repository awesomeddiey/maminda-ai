// Client-side environment variables
export const env = {
  NEXT_PUBLIC_SUPABASE_URL: "https://hunouafyfpcouvdcmcmo.supabase.co",
  NEXT_PUBLIC_SUPABASE_ANON_KEY:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bm91YWZ5ZnBjb3V2ZGNtY21vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE5ODQ5MTcsImV4cCI6MjA1NzU2MDkxN30.LUxgbEBB_y_Jd6nBOBBu6QOWwKliyGgcLfB3jLaCCOc",
  NEXT_PUBLIC_OPENWEATHER_API_KEY: "55b260a9a2cb2355aad16edde4f67e99",
  NEXT_PUBLIC_PLANT_ID_API_KEY: "2b10Mb6SwkJxdZBsyg2fjO",
  NEXT_PUBLIC_OPENAI_API_KEY:
    "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",
  // Hard-coded news API key for testing purposes
  // TODO: Move to environment variable for production
  NEXT_PUBLIC_NEWS_API_KEY: "pub_74584b9279b11c5dbe0db533dc3668959cbf6",
  // Hard-coded Unsplash access key for testing purposes
  // TODO: Move to environment variable for production
  UNSPLASH_ACCESS_KEY: "nZdSwCph2DYbuEmmwbjnxVLeisbkcFeEm_yW7dJlguY",
}

