"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { BookOpen, Leaf, CloudRain, FlaskRoundIcon as Flask, Calendar, MessageSquare, Users } from "lucide-react"

export default function DocumentationPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="container py-8 max-w-4xl mx-auto">
      <div className="flex flex-col items-center text-center mb-8">
        <BookOpen className="h-16 w-16 text-green-600 mb-4" />
        <h1 className="text-3xl font-bold">Maminda AI Documentation</h1>
        <p className="text-muted-foreground mt-2">Learn how to use Maminda AI to optimize your farming practices</p>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-2 md:grid-cols-4 mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="features">Features</TabsTrigger>
          <TabsTrigger value="guides">How-to Guides</TabsTrigger>
          <TabsTrigger value="faq">FAQ</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>About Maminda AI</CardTitle>
              <CardDescription>Your AI-powered farming assistant</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold mb-2">What is Maminda AI?</h3>
                <p>
                  Maminda AI is a comprehensive farming assistant powered by artificial intelligence. It helps farmers
                  make data-driven decisions, optimize crop production, monitor soil health, identify plant diseases,
                  and create personalized planting guides.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-2">Our Mission</h3>
                <p>
                  Our mission is to empower farmers with accessible technology that increases productivity, reduces
                  waste, and promotes sustainable farming practices. By combining AI with agricultural expertise, we aim
                  to help farmers overcome challenges and maximize their yields.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-2">Key Benefits</h3>
                <ul className="list-disc pl-5 space-y-2">
                  <li>
                    <span className="font-medium">Personalized Recommendations:</span> Get tailored advice based on your
                    specific farming conditions, crop types, and location.
                  </li>
                  <li>
                    <span className="font-medium">Data-Driven Decisions:</span> Make informed choices using real-time
                    weather data, soil analysis, and plant health monitoring.
                  </li>
                  <li>
                    <span className="font-medium">Time and Resource Savings:</span> Optimize resource usage and reduce
                    waste through precise planning and monitoring.
                  </li>
                  <li>
                    <span className="font-medium">Community Support:</span> Connect with other farmers, share
                    experiences, and learn from collective knowledge.
                  </li>
                  <li>
                    <span className="font-medium">Continuous Learning:</span> The AI system continuously improves its
                    recommendations based on feedback and results.
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-2">Getting Started</h3>
                <p>
                  To get the most out of Maminda AI, we recommend creating an account to save your farm profile,
                  planting guides, and analysis results. Explore the different features through the dashboard and don't
                  hesitate to use the help resources if you have any questions.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="features">
          <Card>
            <CardHeader>
              <CardTitle>Features & Tools</CardTitle>
              <CardDescription>Explore the powerful tools available in Maminda AI</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="border rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Leaf className="h-6 w-6 text-green-600" />
                    <h3 className="text-lg font-semibold">Plant Disease Analyzer</h3>
                  </div>
                  <p className="text-muted-foreground">
                    Upload photos of your plants to identify diseases, pests, and nutrient deficiencies. Get treatment
                    recommendations and preventive measures.
                  </p>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Flask className="h-6 w-6 text-green-600" />
                    <h3 className="text-lg font-semibold">Soil Analyzer</h3>
                  </div>
                  <p className="text-muted-foreground">
                    Analyze your soil composition, pH levels, and nutrient content. Receive fertilizer recommendations
                    and soil improvement strategies.
                  </p>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Calendar className="h-6 w-6 text-green-600" />
                    <h3 className="text-lg font-semibold">Planting Guide</h3>
                  </div>
                  <p className="text-muted-foreground">
                    Create personalized planting calendars based on your location, crop type, and farming conditions.
                    Get optimal planting dates and crop management timelines.
                  </p>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <CloudRain className="h-6 w-6 text-green-600" />
                    <h3 className="text-lg font-semibold">Weather Insights</h3>
                  </div>
                  <p className="text-muted-foreground">
                    Access real-time weather data and forecasts specific to your farm location. Receive alerts for
                    extreme weather conditions that might affect your crops.
                  </p>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <MessageSquare className="h-6 w-6 text-green-600" />
                    <h3 className="text-lg font-semibold">AI Farming Assistant</h3>
                  </div>
                  <p className="text-muted-foreground">
                    Chat with our AI assistant to get answers to your farming questions, troubleshoot issues, and
                    receive personalized advice.
                  </p>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Users className="h-6 w-6 text-green-600" />
                    <h3 className="text-lg font-semibold">Farmer Forum</h3>
                  </div>
                  <p className="text-muted-foreground">
                    Connect with other farmers, share experiences, ask questions, and learn from the community's
                    collective knowledge.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="guides">
          <Card>
            <CardHeader>
              <CardTitle>How-to Guides</CardTitle>
              <CardDescription>Step-by-step instructions for using Maminda AI</CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>How to create a planting guide</AccordionTrigger>
                  <AccordionContent>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Navigate to the Planting Guide section from the dashboard.</li>
                      <li>Select your crop type from the dropdown menu.</li>
                      <li>Enter your land size in acres.</li>
                      <li>Select your geographic location.</li>
                      <li>Choose your soil type.</li>
                      <li>Enter your planned planting date.</li>
                      <li>Optionally, select your irrigation method and previous crop.</li>
                      <li>Click "Generate Planting Calendar" to create your guide.</li>
                      <li>Review the generated calendar and click "Save Guide" to store it in your profile.</li>
                    </ol>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger>How to analyze plant diseases</AccordionTrigger>
                  <AccordionContent>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Go to the Plant Disease Analyzer section.</li>
                      <li>Click "Upload Image" or drag and drop a photo of your plant.</li>
                      <li>Ensure the image clearly shows the affected parts of the plant.</li>
                      <li>Select the plant type from the dropdown menu (if known).</li>
                      <li>Click "Analyze" to process the image.</li>
                      <li>Review the analysis results, including identified diseases and confidence levels.</li>
                      <li>Read the recommended treatments and preventive measures.</li>
                      <li>Save the analysis to your profile for future reference.</li>
                    </ol>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger>How to analyze soil composition</AccordionTrigger>
                  <AccordionContent>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Navigate to the Soil Analyzer section.</li>
                      <li>Enter your soil test results if you have them.</li>
                      <li>Alternatively, upload images of your soil for AI analysis.</li>
                      <li>Provide information about your location and current crops.</li>
                      <li>Click "Analyze Soil" to process the information.</li>
                      <li>Review the soil composition analysis, including pH, nutrient levels, and organic matter.</li>
                      <li>Read the fertilizer recommendations and soil improvement strategies.</li>
                      <li>Save the analysis to your profile for future reference.</li>
                    </ol>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger>How to use the weather insights</AccordionTrigger>
                  <AccordionContent>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Access the Weather Insights section from the dashboard.</li>
                      <li>Allow location access or manually enter your farm location.</li>
                      <li>View the current weather conditions and forecast for your area.</li>
                      <li>Check the precipitation forecast and temperature trends.</li>
                      <li>Review the farming recommendations based on the weather forecast.</li>
                      <li>Set up weather alerts for specific conditions (e.g., frost, heavy rain).</li>
                      <li>Use the historical weather data to plan future farming activities.</li>
                    </ol>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-5">
                  <AccordionTrigger>How to manage your profile</AccordionTrigger>
                  <AccordionContent>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Click on your profile icon in the top right corner.</li>
                      <li>Select "Profile" from the dropdown menu.</li>
                      <li>Update your personal information, including name, contact details, and farm information.</li>
                      <li>Navigate to the "Saved Guides" tab to view and manage your planting guides.</li>
                      <li>Use the "Account" tab to manage your account settings and preferences.</li>
                      <li>Save any changes by clicking the "Save Changes" button.</li>
                    </ol>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="faq">
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
              <CardDescription>Common questions about Maminda AI</CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="faq-1">
                  <AccordionTrigger>Is Maminda AI free to use?</AccordionTrigger>
                  <AccordionContent>
                    <p>
                      Maminda AI offers both free and premium plans. The free plan provides access to basic features,
                      including limited plant disease analysis, weather insights, and planting guides. Premium plans
                      offer additional features, higher usage limits, and priority support.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="faq-2">
                  <AccordionTrigger>How accurate is the plant disease analysis?</AccordionTrigger>
                  <AccordionContent>
                    <p>
                      Our plant disease analyzer uses advanced AI models trained on thousands of plant images. It
                      typically achieves 85-95% accuracy for common diseases. However, accuracy depends on image
                      quality, lighting conditions, and disease visibility. For critical cases, we recommend consulting
                      with a professional agronomist to confirm the diagnosis.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="faq-3">
                  <AccordionTrigger>Can Maminda AI work offline?</AccordionTrigger>
                  <AccordionContent>
                    <p>
                      Currently, Maminda AI requires an internet connection to access its full features, as the AI
                      analysis is performed on our servers. However, some basic information and previously saved guides
                      can be accessed offline. We're working on developing enhanced offline capabilities for areas with
                      limited connectivity.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="faq-4">
                  <AccordionTrigger>How does Maminda AI handle my data?</AccordionTrigger>
                  <AccordionContent>
                    <p>
                      We take data privacy seriously. Your personal information is stored securely and is never sold to
                      third parties. The images and data you upload are used to provide you with analysis and
                      recommendations, and with your permission, may be used to improve our AI models. You can delete
                      your data at any time from your account settings.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="faq-5">
                  <AccordionTrigger>Which crops does Maminda AI support?</AccordionTrigger>
                  <AccordionContent>
                    <p>
                      Maminda AI currently supports over 30 common crops, including maize, tomatoes, potatoes, beans,
                      rice, wheat, cabbage, onions, carrots, and various fruits. We're continuously expanding our
                      database to include more crops and varieties. If you don't see your specific crop, you can request
                      it through the feedback form.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="faq-6">
                  <AccordionTrigger>Can I use Maminda AI for commercial farming?</AccordionTrigger>
                  <AccordionContent>
                    <p>
                      Yes, Maminda AI is designed for both small-scale and commercial farming operations. Our premium
                      plans offer features specifically tailored for commercial farmers, including bulk analysis,
                      advanced reporting, and integration with farm management systems. Contact our sales team for
                      enterprise solutions.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="faq-7">
                  <AccordionTrigger>How do I get help if I have a problem?</AccordionTrigger>
                  <AccordionContent>
                    <p>You can access help in several ways:</p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Use the in-app chat support by clicking the "Help" button in the bottom right corner.</li>
                      <li>Visit our Help Center for detailed guides and troubleshooting tips.</li>
                      <li>Email our support team at support@maminda.ai for personalized assistance.</li>
                      <li>Post your question in the Farmer Forum to get help from the community.</li>
                      <li>Premium users can access priority support with faster response times.</li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-8 text-center">
        <p className="text-muted-foreground">
          Can't find what you're looking for?{" "}
          <a href="/help-support" className="text-green-600 hover:underline">
            Contact our support team
          </a>
        </p>
      </div>
    </div>
  )
}

