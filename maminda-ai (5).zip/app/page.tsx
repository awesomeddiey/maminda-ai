"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/supabase-provider"
import LandingPage from "./landing-page"

export default function Page() {
  const { user } = useSupabase()
  const router = useRouter()

  useEffect(() => {
    // If user is signed in, redirect to home page
    if (user) {
      router.push("/home")
    }
  }, [user, router])

  // Show landing page for non-signed-in users
  return <LandingPage />
}

import { useState, useRef } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Leaf, BarChart2, Cloud, Droplet, Calendar } from "lucide-react"
import { HeroBanner } from "@/components/hero-banner"

function LandingPageContent() {
  const [activeCard, setActiveCard] = useState(0)
  const carouselRef = useRef<HTMLDivElement>(null)

  const featureCards = [
    {
      title: "Crop Analysis",
      description: "AI-powered insights for your farm",
      icon: <Leaf className="h-6 w-6 text-green-600" />,
      progress: [85, 65, 75],
    },
    {
      title: "Weather Forecasting",
      description: "Accurate predictions for better planning",
      icon: <Cloud className="h-6 w-6 text-blue-600" />,
      progress: [90, 70, 60],
    },
    {
      title: "Soil Monitoring",
      description: "Track soil health and nutrients",
      icon: <Droplet className="h-6 w-6 text-cyan-600" />,
      progress: [75, 80, 65],
    },
    {
      title: "Planting Calendar",
      description: "Optimize your planting schedule",
      icon: <Calendar className="h-6 w-6 text-purple-600" />,
      progress: [80, 70, 90],
    },
    {
      title: "Yield Analytics",
      description: "Track and improve your farm output",
      icon: <BarChart2 className="h-6 w-6 text-orange-600" />,
      progress: [65, 85, 75],
    },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveCard((prev) => (prev + 1) % featureCards.length)
    }, 4000)

    return () => clearInterval(interval)
  }, [featureCards.length])

  useEffect(() => {
    if (carouselRef.current) {
      const scrollPosition = activeCard * (carouselRef.current.scrollWidth / featureCards.length)
      carouselRef.current.scrollTo({
        left: scrollPosition,
        behavior: "smooth",
      })
    }
  }, [activeCard, featureCards.length])

  const getIconBackground = (index: number) => {
    const colors = ["bg-green-100", "bg-blue-100", "bg-cyan-100", "bg-purple-100", "bg-orange-100"]
    return colors[index % colors.length]
  }

  const getProgressColor = (index: number) => {
    const colors = ["bg-green-500", "bg-blue-500", "bg-cyan-500", "bg-purple-500", "bg-orange-500"]
    return colors[index % colors.length]
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100">
      <HeroBanner
        title="Smart Farming Solutions for Zimbabwe"
        subtitle="Leverage AI and data-driven insights to optimize your farm's productivity and sustainability"
        ctaText="Get Started"
        ctaLink="/signup"
        backgroundImage="/placeholder.svg?height=500&width=1200"
      />
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="fade-in">
            <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-4">
              <span className="text-green-600">Empowering Farmers</span> with
              <br />
              AI-powered Insights
            </h1>
            <p className="text-lg text-gray-700 mb-8">
              Maminda AI helps farmers in Zimbabwe optimize their crops, prevent diseases, and maximize yields through
              personalized AI assistance.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/signup">
                <Button size="lg" className="bg-green-600 hover:bg-green-700">
                  Get Started
                </Button>
              </Link>
              <Link href="/documentation">
                <Button size="lg" variant="outline" className="border-green-600 text-green-600 hover:bg-green-50">
                  Learn More
                </Button>
              </Link>
              <Link href="/pricing">
                <Button size="lg" variant="outline" className="border-green-600 text-green-600 hover:bg-green-50">
                  Pricing
                </Button>
              </Link>
            </div>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-white/50 backdrop-blur-sm rounded-2xl shadow-lg transform rotate-3"></div>
            <div className="absolute inset-0 bg-white/50 backdrop-blur-sm rounded-2xl shadow-lg transform -rotate-3"></div>
            <div className="relative bg-white rounded-xl shadow-lg p-6 w-full max-w-md mx-auto overflow-hidden">
              <div
                ref={carouselRef}
                className="flex snap-x snap-mandatory overflow-x-hidden scroll-smooth"
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
              >
                {featureCards.map((card, index) => (
                  <div
                    key={index}
                    className={`flex-none w-full snap-center transition-opacity duration-500 ${activeCard === index ? "opacity-100" : "opacity-0"}`}
                  >
                    <div className="flex items-center gap-4 mb-6">
                      <div
                        className={`h-12 w-12 rounded-full ${getIconBackground(index)} flex items-center justify-center`}
                      >
                        {card.icon}
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold">{card.title}</h3>
                        <p className="text-sm text-gray-500">{card.description}</p>
                      </div>
                    </div>
                    <div className="space-y-4">
                      {card.progress.map((progress, i) => (
                        <div key={i} className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${getProgressColor(index)} rounded-full animate-progress`}
                            style={{ width: `${progress}%`, animationDelay: `${i * 0.2}s` }}
                          ></div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-center mt-6 gap-2">
                {featureCards.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveCard(index)}
                    className={`h-2 w-2 rounded-full transition-all duration-300 ${
                      activeCard === index ? "bg-green-600 w-4" : "bg-gray-300"
                    }`}
                    aria-label={`Go to slide ${index + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Powerful Features for Modern Farming</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our AI-powered platform provides everything you need to optimize your farm's productivity and make
              data-driven decisions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl shadow-md hover:shadow-lg transition-all">
              <div className="h-14 w-14 bg-white rounded-full flex items-center justify-center mb-4 shadow-sm">
                <Leaf className="h-7 w-7 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Plant Disease Detection</h3>
              <p className="text-gray-700">
                Upload photos of your plants and get instant AI-powered diagnosis of diseases and pests, along with
                treatment recommendations.
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl shadow-md hover:shadow-lg transition-all">
              <div className="h-14 w-14 bg-white rounded-full flex items-center justify-center mb-4 shadow-sm">
                <Cloud className="h-7 w-7 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Weather Intelligence</h3>
              <p className="text-gray-700">
                Access hyperlocal weather forecasts and receive alerts for conditions that might affect your crops,
                helping you plan ahead.
              </p>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl shadow-md hover:shadow-lg transition-all">
              <div className="h-14 w-14 bg-white rounded-full flex items-center justify-center mb-4 shadow-sm">
                <Calendar className="h-7 w-7 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Smart Planting Guides</h3>
              <p className="text-gray-700">
                Generate personalized planting calendars based on your location, soil type, and crop selection for
                optimal yields.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Testimonials */}
      <div className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Trusted by Farmers Across Zimbabwe</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              See what farmers are saying about how Maminda AI has transformed their farming practices.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-green-600 font-bold">TM</span>
                </div>
                <div>
                  <h4 className="font-bold">Tendai Moyo</h4>
                  <p className="text-sm text-gray-500">Maize Farmer, Harare</p>
                </div>
              </div>
              <p className="text-gray-700">
                "Maminda AI has helped me increase my maize yield by 30% this season. The planting calendar and disease
                detection features have been game-changers for my farm."
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-blue-600 font-bold">CN</span>
                </div>
                <div>
                  <h4 className="font-bold">Chipo Nyathi</h4>
                  <p className="text-sm text-gray-500">Vegetable Grower, Bulawayo</p>
                </div>
              </div>
              <p className="text-gray-700">
                "The soil analysis feature helped me understand what my tomatoes needed. I've seen healthier plants and
                better harvests since I started using Maminda AI."
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-purple-600 font-bold">BM</span>
                </div>
                <div>
                  <h4 className="font-bold">Blessing Mutasa</h4>
                  <p className="text-sm text-gray-500">Cotton Farmer, Mutare</p>
                </div>
              </div>
              <p className="text-gray-700">
                "The weather alerts have saved my crops multiple times. I can now plan my farming activities with
                confidence, knowing I have accurate forecasts at my fingertips."
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 py-16 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Farming?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of farmers who are already using Maminda AI to increase yields, reduce costs, and farm more
            sustainably.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/signup">
              <Button size="lg" className="bg-white text-green-700 hover:bg-gray-100">
                Get Started for Free
              </Button>
            </Link>
            <Link href="/pricing">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-green-700">
                View Pricing
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

