"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, Calendar, Info, Save, CheckCircle, Leaf, BarChart } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useToast } from "@/components/ui/use-toast"

// Add imports for the planting guide service and useSupabase
import { plantingGuideService } from "@/services/planting-guide-service"
import { openAIService } from "@/services/openai-service"
import { useSupabase } from "@/components/supabase-provider"
import { useRouter } from "next/navigation"

// Add this import at the top of the file
import { ImageBackgroundSection } from "@/components/image-background-section"
import { getRandomImage } from "@/lib/sample-images"

interface PlantingGuideForm {
  plantType: string
  landSize: string
  location: string
  soilType: string
  plantingDate: string
  irrigationMethod: string
  previousCrop: string
  expectedYield: string
}

export default function PlantingGuide() {
  const [form, setForm] = useState<PlantingGuideForm>({
    plantType: "",
    landSize: "",
    location: "",
    soilType: "",
    plantingDate: "",
    irrigationMethod: "",
    previousCrop: "",
    expectedYield: "",
  })
  const [isGenerating, setIsGenerating] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [generatedGuide, setGeneratedGuide] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("info")
  const { toast } = useToast()

  // Add router and user to the component
  const router = useRouter()
  const { user } = useSupabase()

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  // Fix the Generate Planting Guide button and functionality

  // Update the generateCalendar function to improve reliability and add better error handling
  const generateCalendar = async () => {
    // Validate form
    if (!form.plantType || !form.landSize || !form.location || !form.soilType || !form.plantingDate) {
      toast({
        title: "Incomplete information",
        description:
          "Please fill in all required fields (Plant Type, Land Size, Location, Soil Type, and Planting Date)",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    try {
      // Generate the planting guide using OpenAI
      const guideContent = await openAIService.generatePlantingGuide(
        form.plantType,
        form.landSize,
        form.location,
        form.soilType,
        form.plantingDate,
        form.irrigationMethod,
        form.previousCrop,
        form.expectedYield,
      )

      if (!guideContent || guideContent.trim() === "") {
        throw new Error("Failed to generate guide content. Please try again.")
      }

      // Store the generated guide
      setGeneratedGuide(guideContent)

      // Switch to the generated guide tab
      setActiveTab("guide")

      toast({
        title: "Guide Generated Successfully",
        description: "Your personalized planting guide has been created",
      })
    } catch (error: any) {
      console.error("Error generating guide:", error)
      toast({
        title: "Error generating guide",
        description: error.message || "An error occurred while generating your guide. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  // Calculate expected yield based on crop type and land size
  const calculateExpectedYield = () => {
    if (!form.plantType || !form.landSize) return ""

    const landSize = Number.parseFloat(form.landSize)
    if (isNaN(landSize)) return ""

    const yieldRates: Record<string, number> = {
      maize: 6.2, // tons per hectare
      tobacco: 3.0, // tons per hectare
      cotton: 2.0, // tons per hectare (lint)
      sorghum: 4.5, // tons per hectare
      millet: 3.0, // tons per hectare
      groundnuts: 2.2, // tons per hectare
      soybeans: 3.7, // tons per hectare
      wheat: 5.0, // tons per hectare
      sugarcane: 85.0, // tons per hectare
      sweetpotatoes: 20.0, // tons per hectare
      tomatoes: 37.0, // tons per hectare
      potatoes: 25.0, // tons per hectare
      beans: 2.0, // tons per hectare
      cowpeas: 1.7, // tons per hectare
      sunflower: 2.2, // tons per hectare
      cabbage: 30.0, // tons per hectare
      onions: 20.0, // tons per hectare
      carrots: 25.0, // tons per hectare
      rice: 5.5, // tons per hectare
    }

    const rate = yieldRates[form.plantType] || 0
    const expectedYield = rate * landSize

    return expectedYield.toFixed(1)
  }

  // Update expected yield when crop type or land size changes
  const updateExpectedYield = () => {
    const yield_value = calculateExpectedYield()
    if (yield_value) {
      setForm((prev) => ({ ...prev, expectedYield: yield_value }))
    }
  }

  // Replace the saveGuide function with this implementation
  const saveGuide = async () => {
    // Validate form
    if (!form.plantType || !form.landSize || !form.location || !form.soilType || !form.plantingDate) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to save your planting guide",
        variant: "destructive",
      })
      router.push("/signin")
      return
    }

    // Check if we have a generated guide
    if (!generatedGuide) {
      toast({
        title: "Generate guide first",
        description: "Please generate a guide before saving",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)

    try {
      const title = plantingGuideService.generateGuideTitle(form.plantType, form.location)

      const guideData = {
        user_id: user.id,
        title,
        plant_type: form.plantType,
        land_size: form.landSize,
        location: form.location,
        soil_type: form.soilType,
        planting_date: form.plantingDate,
        irrigation_method: form.irrigationMethod || "",
        previous_crop: form.previousCrop || "",
        expected_yield: form.expectedYield || "",
        guide_content: generatedGuide, // Save the generated guide content
      }

      const { data, error } = await plantingGuideService.createGuide(guideData)

      if (error) {
        console.error("Error saving guide:", error)
        throw error
      }

      toast({
        title: "Guide Saved",
        description: "Your planting guide has been saved successfully",
      })

      // Optionally redirect to the profile page to see saved guides
      router.push("/profile?tab=guides")
    } catch (error: any) {
      console.error("Error saving guide:", error)
      toast({
        title: "Error saving guide",
        description: error.message || "An error occurred while saving your guide",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div>
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-green-50 via-green-100 to-green-50 py-8 sm:py-12 mb-4 sm:mb-6">
        <div className="container px-4 sm:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-block p-2 sm:p-3 bg-white rounded-2xl shadow-sm mb-3 sm:mb-4">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center mx-auto">
                <Calendar className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-2 sm:mb-4">Planting Guide</h1>
            <p className="text-base sm:text-lg text-gray-700">
              Get optimal planting dates and personalized schedules for your crops
            </p>
          </div>
        </div>
      </div>

      <div className="container max-w-6xl mx-auto px-4 sm:px-6 pb-8 sm:pb-12">
        {/* Add this section at the top of the component's return statement, before the Tabs */}
        <div className="mb-4 sm:mb-6">
          <ImageBackgroundSection imageSrc={getRandomImage("crops")} className="h-[150px] sm:h-[200px]">
            <div className="h-full flex flex-col justify-end p-4">
              <h1 className="text-2xl sm:text-3xl font-bold text-white">Planting Guide</h1>
              <p className="text-sm sm:text-base text-white/90">
                Get personalized planting calendars and guidance for your crops
              </p>
            </div>
          </ImageBackgroundSection>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-8">
          <div className="md:col-span-1">
            <Card className="border-none shadow-lg overflow-hidden bg-white mb-6 sticky top-20">
              <CardContent className="p-3 sm:p-6">
                <h2 className="text-lg sm:text-xl font-bold text-gray-900 flex items-center gap-2 mb-4 sm:mb-6">
                  <div className="h-5 w-5 sm:h-6 sm:w-6 rounded-full bg-green-100 flex items-center justify-center">
                    <div className="h-2 w-2 rounded-full bg-green-600"></div>
                  </div>
                  Farm Details
                </h2>

                <div className="space-y-5">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="plantType" className="text-sm font-medium text-gray-700">
                        Plant Type <span className="text-red-500">*</span>
                      </Label>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="h-4 w-4 text-gray-400" />
                          </TooltipTrigger>
                          <TooltipContent className="bg-white">
                            <p className="w-[200px] text-xs">Select the crop you plan to plant</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <Select
                      onValueChange={(value) => {
                        handleSelectChange("plantType", value)
                        setTimeout(updateExpectedYield, 0)
                      }}
                      value={form.plantType}
                    >
                      <SelectTrigger className="bg-white border-gray-300 rounded-lg h-11">
                        <SelectValue placeholder="Select plant type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="maize">Maize (Corn)</SelectItem>
                        <SelectItem value="tobacco">Tobacco</SelectItem>
                        <SelectItem value="cotton">Cotton</SelectItem>
                        <SelectItem value="sorghum">Sorghum</SelectItem>
                        <SelectItem value="millet">Millet</SelectItem>
                        <SelectItem value="groundnuts">Groundnuts (Peanuts)</SelectItem>
                        <SelectItem value="soybeans">Soybeans</SelectItem>
                        <SelectItem value="wheat">Wheat</SelectItem>
                        <SelectItem value="sugarcane">Sugarcane</SelectItem>
                        <SelectItem value="sweetpotatoes">Sweet Potatoes</SelectItem>
                        <SelectItem value="tomatoes">Tomatoes</SelectItem>
                        <SelectItem value="potatoes">Potatoes</SelectItem>
                        <SelectItem value="beans">Beans</SelectItem>
                        <SelectItem value="cowpeas">Cowpeas</SelectItem>
                        <SelectItem value="sunflower">Sunflower</SelectItem>
                        <SelectItem value="cabbage">Cabbage</SelectItem>
                        <SelectItem value="onions">Onions</SelectItem>
                        <SelectItem value="carrots">Carrots</SelectItem>
                        <SelectItem value="rice">Rice</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="landSize" className="text-sm font-medium text-gray-700">
                        Land Size (hectares) <span className="text-red-500">*</span>
                      </Label>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="h-4 w-4 text-gray-400" />
                          </TooltipTrigger>
                          <TooltipContent className="bg-white">
                            <p className="w-[200px] text-xs">Enter the size of your land in acres</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <Input
                      id="landSize"
                      name="landSize"
                      type="number"
                      placeholder="e.g., 1.0"
                      value={form.landSize}
                      className="bg-white border-gray-300 rounded-lg h-11"
                      onChange={(e) => {
                        handleInputChange(e)
                        setTimeout(updateExpectedYield, 0)
                      }}
                    />
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="location" className="text-sm font-medium text-gray-700">
                      Geographic Location <span className="text-red-500">*</span>
                    </Label>
                    <Select onValueChange={(value) => handleSelectChange("location", value)} value={form.location}>
                      <SelectTrigger className="bg-white border-gray-300 rounded-lg h-11">
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="current">Current Location</SelectItem>
                        <SelectItem value="harare">Harare</SelectItem>
                        <SelectItem value="bulawayo">Bulawayo</SelectItem>
                        <SelectItem value="chitungwiza">Chitungwiza</SelectItem>
                        <SelectItem value="mutare">Mutare</SelectItem>
                        <SelectItem value="gweru">Gweru</SelectItem>
                        <SelectItem value="kwekwe">Kwekwe</SelectItem>
                        <SelectItem value="kadoma">Kadoma</SelectItem>
                        <SelectItem value="masvingo">Masvingo</SelectItem>
                        <SelectItem value="chinhoyi">Chinhoyi</SelectItem>
                        <SelectItem value="victoria_falls">Victoria Falls</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="soilType" className="text-sm font-medium text-gray-700">
                      Soil Type <span className="text-red-500">*</span>
                    </Label>
                    <Select onValueChange={(value) => handleSelectChange("soilType", value)} value={form.soilType}>
                      <SelectTrigger className="bg-white border-gray-300 rounded-lg h-11">
                        <SelectValue placeholder="Select soil type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="clay">Clay Soil</SelectItem>
                        <SelectItem value="sandy">Sandy Soil</SelectItem>
                        <SelectItem value="loam">Loam Soil</SelectItem>
                        <SelectItem value="silt">Silt Soil</SelectItem>
                        <SelectItem value="peat">Peat Soil</SelectItem>
                        <SelectItem value="chalk">Chalk Soil</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="plantingDate" className="text-sm font-medium text-gray-700">
                      Planned Planting Date <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="plantingDate"
                      name="plantingDate"
                      type="date"
                      value={form.plantingDate}
                      className="bg-white border-gray-300 rounded-lg h-11"
                      onChange={handleInputChange}
                    />
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="irrigationMethod" className="text-sm font-medium text-gray-700">
                      Irrigation Method
                    </Label>
                    <Select
                      onValueChange={(value) => handleSelectChange("irrigationMethod", value)}
                      value={form.irrigationMethod}
                    >
                      <SelectTrigger className="bg-white border-gray-300 rounded-lg h-11">
                        <SelectValue placeholder="Select irrigation method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="rainfed">Rainfed (No irrigation)</SelectItem>
                        <SelectItem value="drip">Drip Irrigation</SelectItem>
                        <SelectItem value="sprinkler">Sprinkler System</SelectItem>
                        <SelectItem value="flood">Flood Irrigation</SelectItem>
                        <SelectItem value="manual">Manual Watering</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="previousCrop" className="text-sm font-medium text-gray-700">
                      Previous Crop
                    </Label>
                    <Select
                      onValueChange={(value) => handleSelectChange("previousCrop", value)}
                      value={form.previousCrop}
                    >
                      <SelectTrigger className="bg-white border-gray-300 rounded-lg h-11">
                        <SelectValue placeholder="Select previous crop" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None/Fallow</SelectItem>
                        <SelectItem value="maize">Maize (Corn)</SelectItem>
                        <SelectItem value="beans">Beans</SelectItem>
                        <SelectItem value="potatoes">Potatoes</SelectItem>
                        <SelectItem value="wheat">Wheat</SelectItem>
                        <SelectItem value="vegetables">Vegetables</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="expectedYield" className="text-sm font-medium text-gray-700">
                      Expected Yield (tons)
                    </Label>
                    <Input
                      id="expectedYield"
                      name="expectedYield"
                      type="text"
                      value={form.expectedYield}
                      onChange={handleInputChange}
                      readOnly
                      className="bg-gray-50 border-gray-300 rounded-lg h-11"
                    />
                  </div>
                </div>

                {/* Update the button styling and layout to make it more prominent
                Replace the button section in the form with this improved version: */}

                <div className="mt-6 space-y-3">
                  <Button
                    onClick={generateCalendar}
                    className="w-full py-3 sm:py-6 text-sm sm:text-base font-medium bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 shadow-md transition-all duration-300 ease-in-out transform hover:scale-[1.02] active:scale-[0.98]"
                    disabled={isGenerating}
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 sm:h-5 sm:w-5 animate-spin" />
                        <span className="whitespace-nowrap">Generating Guide...</span>
                      </>
                    ) : (
                      <>
                        <Calendar className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
                        <span className="whitespace-nowrap">Generate Planting Guide</span>
                      </>
                    )}
                  </Button>

                  <Button
                    onClick={saveGuide}
                    className="w-full py-3 sm:py-6 text-sm sm:text-base font-medium border border-green-600 text-green-600 hover:bg-green-50 transition-all duration-300"
                    variant="outline"
                    disabled={isSaving || !generatedGuide}
                  >
                    {isSaving ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 sm:h-5 sm:w-5 animate-spin" />
                        <span className="whitespace-nowrap">Saving...</span>
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4 sm:h-5 sm:w-5" />
                        <span className="whitespace-nowrap">Save Guide</span>
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            <Tabs defaultValue="info" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full grid grid-cols-2 md:grid-cols-4 bg-gray-100 p-1 rounded-xl">
                <TabsTrigger
                  value="info"
                  className="rounded-lg py-2 px-1 text-xs sm:text-sm md:text-base data-[state=active]:bg-white data-[state=active]:shadow-sm"
                >
                  Crop Info
                </TabsTrigger>
                <TabsTrigger
                  value="yield"
                  className="rounded-lg py-2 px-1 text-xs sm:text-sm md:text-base data-[state=active]:bg-white data-[state=active]:shadow-sm"
                >
                  Yield Potential
                </TabsTrigger>
                <TabsTrigger
                  value="tips"
                  className="rounded-lg py-2 px-1 text-xs sm:text-sm md:text-base data-[state=active]:bg-white data-[state=active]:shadow-sm"
                >
                  Planting Tips
                </TabsTrigger>
                <TabsTrigger
                  value="guide"
                  className="rounded-lg py-2 px-1 text-xs sm:text-sm md:text-base data-[state=active]:bg-white data-[state=active]:shadow-sm"
                  disabled={!generatedGuide}
                >
                  Generated Guide
                </TabsTrigger>
              </TabsList>

              <TabsContent value="info" className="mt-6">
                <Card className="border-none shadow-lg bg-white">
                  <CardContent className="p-6">
                    {!form.plantType ? (
                      <div className="flex flex-col items-center justify-center py-16 text-center bg-gray-50 rounded-lg border border-dashed border-gray-300">
                        <Calendar className="h-12 w-12 text-gray-400 mb-4" />
                        <h3 className="text-lg font-medium text-gray-700 mb-2">No Crop Selected</h3>
                        <p className="text-gray-500 max-w-md">
                          Select a crop from the form to see detailed growing information
                        </p>
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-center mb-6">
                          <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center mr-4">
                            <Leaf className="h-6 w-6 text-green-600" />
                          </div>
                          <h3 className="text-2xl font-bold text-gray-900 capitalize">
                            {form.plantType} Growing Guide
                          </h3>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-8">
                          <div className="bg-gray-50 rounded-xl p-5">
                            <h4 className="font-semibold text-green-700 mb-4 flex items-center">
                              <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mr-2">
                                <CheckCircle className="h-3 w-3 text-green-600" />
                              </div>
                              Growing Conditions
                            </h4>
                            <table className="w-full">
                              <tbody>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">Temperature</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "20-30°C (68-86°F)"}
                                    {form.plantType === "tomatoes" && "21-24°C (70-75°F)"}
                                    {form.plantType === "potatoes" && "15-20°C (59-68°F)"}
                                    {form.plantType === "beans" && "18-24°C (65-75°F)"}
                                    {form.plantType === "cabbage" && "15-20°C (59-68°F)"}
                                    {form.plantType === "onions" && "13-24°C (55-75°F)"}
                                    {form.plantType === "carrots" && "16-21°C (60-70°F)"}
                                    {form.plantType === "rice" && "20-35°C (68-95°F)"}
                                    {form.plantType === "tobacco" && "20-30°C (68-86°F)"}
                                    {form.plantType === "cotton" && "21-35°C (70-95°F)"}
                                    {form.plantType === "sorghum" && "25-32°C (77-90°F)"}
                                    {form.plantType === "millet" && "25-35°C (77-95°F)"}
                                    {form.plantType === "groundnuts" && "22-28°C (72-82°F)"}
                                    {form.plantType === "soybeans" && "20-30°C (68-86°F)"}
                                    {form.plantType === "wheat" && "15-24°C (59-75°F)"}
                                    {form.plantType === "sugarcane" && "24-30°C (75-86°F)"}
                                    {form.plantType === "sweetpotatoes" && "20-30°C (68-86°F)"}
                                    {form.plantType === "cowpeas" && "22-30°C (72-86°F)"}
                                    {form.plantType === "sunflower" && "20-25°C (68-77°F)"}
                                  </td>
                                </tr>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">Soil pH</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "5.8-6.8"}
                                    {form.plantType === "tomatoes" && "6.0-6.8"}
                                    {form.plantType === "potatoes" && "5.0-6.5"}
                                    {form.plantType === "beans" && "6.0-7.0"}
                                    {form.plantType === "cabbage" && "6.5-7.5"}
                                    {form.plantType === "onions" && "6.0-7.0"}
                                    {form.plantType === "carrots" && "6.0-6.8"}
                                    {form.plantType === "rice" && "5.5-6.5"}
                                    {form.plantType === "tobacco" && "5.5-6.5"}
                                    {form.plantType === "cotton" && "5.8-6.8"}
                                    {form.plantType === "sorghum" && "5.5-7.5"}
                                    {form.plantType === "millet" && "5.5-7.0"}
                                    {form.plantType === "groundnuts" && "5.8-6.5"}
                                    {form.plantType === "soybeans" && "6.0-7.0"}
                                    {form.plantType === "wheat" && "6.0-7.0"}
                                    {form.plantType === "sugarcane" && "5.5-7.5"}
                                    {form.plantType === "sweetpotatoes" && "5.5-6.5"}
                                    {form.plantType === "cowpeas" && "5.5-6.5"}
                                    {form.plantType === "sunflower" && "6.0-7.5"}
                                  </td>
                                </tr>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">Water Needs</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "Moderate (500-800mm per season)"}
                                    {form.plantType === "tomatoes" && "High (regular watering)"}
                                    {form.plantType === "potatoes" && "Moderate (consistent moisture)"}
                                    {form.plantType === "beans" && "Low to Moderate"}
                                    {form.plantType === "cabbage" && "Moderate (consistent moisture)"}
                                    {form.plantType === "onions" && "Moderate (regular watering)"}
                                    {form.plantType === "carrots" && "Moderate (consistent moisture)"}
                                    {form.plantType === "rice" && "Very High (flooded conditions)"}
                                    {form.plantType === "tobacco" && "Moderate (450-750mm per season)"}
                                    {form.plantType === "cotton" && "Moderate (600-1200mm per season)"}
                                    {form.plantType === "sorghum" && "Low (350-600mm per season)"}
                                    {form.plantType === "millet" && "Low (300-500mm per season)"}
                                    {form.plantType === "groundnuts" && "Moderate (500-700mm per season)"}
                                    {form.plantType === "soybeans" && "Moderate (450-700mm per season)"}
                                    {form.plantType === "wheat" && "Moderate (450-650mm per season)"}
                                    {form.plantType === "sugarcane" && "High (1500-2500mm per season)"}
                                    {form.plantType === "sweetpotatoes" && "Moderate (400-675mm per season)"}
                                    {form.plantType === "cowpeas" && "Low (300-500mm per season)"}
                                    {form.plantType === "sunflower" && "Low to Moderate (350-500mm per season)"}
                                  </td>
                                </tr>
                                <tr>
                                  <td className="py-3 font-medium text-gray-700">Sunlight</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "Full sun (6+ hours)"}
                                    {form.plantType === "tomatoes" && "Full sun (6+ hours)"}
                                    {form.plantType === "potatoes" && "Full sun (6+ hours)"}
                                    {form.plantType === "beans" && "Full sun (6+ hours)"}
                                    {form.plantType === "cabbage" && "Full sun to partial shade"}
                                    {form.plantType === "onions" && "Full sun (6+ hours)"}
                                    {form.plantType === "carrots" && "Full sun to partial shade"}
                                    {form.plantType === "rice" && "Full sun (6+ hours)"}
                                    {form.plantType === "tobacco" && "Full sun (6+ hours)"}
                                    {form.plantType === "cotton" && "Full sun (6+ hours)"}
                                    {form.plantType === "sorghum" && "Full sun (6+ hours)"}
                                    {form.plantType === "millet" && "Full sun (6+ hours)"}
                                    {form.plantType === "groundnuts" && "Full sun (6+ hours)"}
                                    {form.plantType === "soybeans" && "Full sun (6+ hours)"}
                                    {form.plantType === "wheat" && "Full sun (6+ hours)"}
                                    {form.plantType === "sugarcane" && "Full sun (6+ hours)"}
                                    {form.plantType === "sweetpotatoes" && "Full sun (6+ hours)"}
                                    {form.plantType === "cowpeas" && "Full sun (6+ hours)"}
                                    {form.plantType === "sunflower" && "Full sun (6+ hours)"}
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>

                          <div className="mt-8 bg-gray-50 rounded-xl p-5">
                            <h4 className="font-semibold text-blue-700 mb-4 flex items-center">
                              <div className="h-5 w-5 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                                <CheckCircle className="h-3 w-3 text-blue-600" />
                              </div>
                              Planting Information
                            </h4>
                            <table className="w-full">
                              <tbody>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">Planting Depth</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "3-5 cm"}
                                    {form.plantType === "tomatoes" && "0.5-1 cm (seeds), 10-15 cm (transplants)"}
                                    {form.plantType === "potatoes" && "10-15 cm (tubers)"}
                                    {form.plantType === "beans" && "2-4 cm"}
                                    {form.plantType === "cabbage" && "0.5-1 cm (seeds), 5-7 cm (transplants)"}
                                    {form.plantType === "onions" && "1-2 cm (seeds), 2-3 cm (sets)"}
                                    {form.plantType === "carrots" && "0.5-1 cm"}
                                    {form.plantType === "rice" && "1-2 cm (direct seeding)"}
                                    {form.plantType === "tobacco" && "Surface (seeds), 10-15 cm (transplants)"}
                                    {form.plantType === "cotton" && "2-4 cm"}
                                    {form.plantType === "sorghum" && "2-5 cm"}
                                    {form.plantType === "millet" && "1-3 cm"}
                                    {form.plantType === "groundnuts" && "3-5 cm"}
                                    {form.plantType === "soybeans" && "2-4 cm"}
                                    {form.plantType === "wheat" && "2-5 cm"}
                                    {form.plantType === "sugarcane" && "5-10 cm (setts)"}
                                    {form.plantType === "sweetpotatoes" && "10-15 cm (slips)"}
                                    {form.plantType === "cowpeas" && "2-4 cm"}
                                    {form.plantType === "sunflower" && "2-4 cm"}
                                  </td>
                                </tr>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">Row Spacing</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "75-90 cm"}
                                    {form.plantType === "tomatoes" && "90-120 cm"}
                                    {form.plantType === "potatoes" && "60-90 cm"}
                                    {form.plantType === "beans" && "45-60 cm"}
                                    {form.plantType === "cabbage" && "60-75 cm"}
                                    {form.plantType === "onions" && "30-45 cm"}
                                    {form.plantType === "carrots" && "30-45 cm"}
                                    {form.plantType === "rice" && "20-30 cm (transplanting)"}
                                    {form.plantType === "tobacco" && "90-120 cm"}
                                    {form.plantType === "cotton" && "75-100 cm"}
                                    {form.plantType === "sorghum" && "60-75 cm"}
                                    {form.plantType === "millet" && "50-75 cm"}
                                    {form.plantType === "groundnuts" && "45-60 cm"}
                                    {form.plantType === "soybeans" && "45-60 cm"}
                                    {form.plantType === "wheat" && "15-20 cm (drill seeding)"}
                                    {form.plantType === "sugarcane" && "100-150 cm"}
                                    {form.plantType === "sweetpotatoes" && "75-100 cm"}
                                    {form.plantType === "cowpeas" && "60-75 cm"}
                                    {form.plantType === "sunflower" && "60-75 cm"}
                                  </td>
                                </tr>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">Plant Spacing</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "25-30 cm"}
                                    {form.plantType === "tomatoes" && "45-60 cm"}
                                    {form.plantType === "potatoes" && "25-30 cm"}
                                    {form.plantType === "beans" && "10-15 cm"}
                                    {form.plantType === "cabbage" && "45-60 cm"}
                                    {form.plantType === "onions" && "10-15 cm"}
                                    {form.plantType === "carrots" && "5-8 cm (thinned)"}
                                    {form.plantType === "rice" && "15-20 cm (transplanting)"}
                                    {form.plantType === "tobacco" && "45-60 cm"}
                                    {form.plantType === "cotton" && "15-30 cm"}
                                    {form.plantType === "sorghum" && "15-20 cm"}
                                    {form.plantType === "millet" && "10-15 cm"}
                                    {form.plantType === "groundnuts" && "10-15 cm"}
                                    {form.plantType === "soybeans" && "5-10 cm"}
                                    {form.plantType === "wheat" && "Broadcast or drill seeded"}
                                    {form.plantType === "sugarcane" && "30-45 cm (setts)"}
                                    {form.plantType === "sweetpotatoes" && "30-40 cm"}
                                    {form.plantType === "cowpeas" && "15-20 cm"}
                                    {form.plantType === "sunflower" && "25-30 cm"}
                                  </td>
                                </tr>
                                <tr>
                                  <td className="py-3 font-medium text-gray-700">Seed Rate</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "20-25 kg/hectare"}
                                    {form.plantType === "tomatoes" &&
                                      "300-400 g/hectare (direct), 150-200 g/hectare (transplants)"}
                                    {form.plantType === "potatoes" && "2000-2500 kg/hectare (tubers)"}
                                    {form.plantType === "beans" && "60-80 kg/hectare"}
                                    {form.plantType === "cabbage" && "400-500 g/hectare"}
                                    {form.plantType === "onions" && "3-4 kg/hectare (seeds), 500-600 kg/hectare (sets)"}
                                    {form.plantType === "carrots" && "3-4 kg/hectare"}
                                    {form.plantType === "rice" && "60-80 kg/hectare (direct seeding)"}
                                    {form.plantType === "tobacco" && "50-75 g/hectare"}
                                    {form.plantType === "cotton" && "15-20 kg/hectare"}
                                    {form.plantType === "sorghum" && "8-10 kg/hectare"}
                                    {form.plantType === "millet" && "4-6 kg/hectare"}
                                    {form.plantType === "groundnuts" && "80-100 kg/hectare (shelled)"}
                                    {form.plantType === "soybeans" && "60-80 kg/hectare"}
                                    {form.plantType === "wheat" && "100-125 kg/hectare"}
                                    {form.plantType === "sugarcane" && "4000-6000 kg/hectare (setts)"}
                                    {form.plantType === "sweetpotatoes" && "30,000-40,000 slips/hectare"}
                                    {form.plantType === "cowpeas" && "20-30 kg/hectare"}
                                    {form.plantType === "sunflower" && "4-6 kg/hectare"}
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="yield" className="mt-6">
                <Card className="border-none shadow-lg bg-white">
                  <CardContent className="p-6">
                    {!form.plantType ? (
                      <div className="flex flex-col items-center justify-center py-16 text-center bg-gray-50 rounded-lg border border-dashed border-gray-300">
                        <Calendar className="h-12 w-12 text-gray-400 mb-4" />
                        <h3 className="text-lg font-medium text-gray-700 mb-2">No Crop Selected</h3>
                        <p className="text-gray-500 max-w-md">
                          Select a crop from the form to see yield potential information
                        </p>
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-center mb-6">
                          <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center mr-4">
                            <BarChart className="h-6 w-6 text-blue-600" />
                          </div>
                          <h3 className="text-2xl font-bold text-gray-900 capitalize">
                            {form.plantType} Yield Potential
                          </h3>
                        </div>

                        <div className="mb-8">
                          <h4 className="font-semibold text-blue-700 mb-4 flex items-center">
                            <div className="h-5 w-5 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                              <CheckCircle className="h-3 w-3 text-blue-600" />
                            </div>
                            Expected Yield by Soil Type
                          </h4>
                          <div className="bg-white p-2 sm:p-4 rounded-xl border border-gray-200">
                            <div className="h-40 sm:h-60 relative">
                              <div className="absolute inset-x-0 bottom-0 h-10 border-t border-gray-200"></div>
                              <div className="absolute left-0 inset-y-0 w-8 sm:w-10 border-r border-gray-200"></div>

                              {/* Bar Chart */}
                              <div className="absolute left-12 sm:left-20 right-4 sm:right-12 bottom-10 top-4 flex items-end justify-around">
                                <div className="flex flex-col items-center">
                                  <div className="h-[60%] w-6 sm:w-12 bg-gradient-to-t from-green-600 to-green-400 rounded-t-md"></div>
                                  <p className="mt-2 text-[10px] sm:text-xs text-gray-600">Clay</p>
                                </div>
                                <div className="flex flex-col items-center">
                                  <div className="h-[40%] w-6 sm:w-12 bg-gradient-to-t from-green-600 to-green-400 rounded-t-md"></div>
                                  <p className="mt-2 text-[10px] sm:text-xs text-gray-600">Sandy</p>
                                </div>
                                <div className="flex flex-col items-center">
                                  <div className="h-[80%] w-6 sm:w-12 bg-gradient-to-t from-green-600 to-green-400 rounded-t-md"></div>
                                  <p className="mt-2 text-[10px] sm:text-xs text-gray-600">Loam</p>
                                </div>
                                <div className="flex flex-col items-center">
                                  <div className="h-[70%] w-6 sm:w-12 bg-gradient-to-t from-green-600 to-green-400 rounded-t-md"></div>
                                  <p className="mt-2 text-[10px] sm:text-xs text-gray-600">Silt</p>
                                </div>
                                <div className="flex flex-col items-center">
                                  <div className="h-[50%] w-6 sm:w-12 bg-gradient-to-t from-green-600 to-green-400 rounded-t-md"></div>
                                  <p className="mt-2 text-[10px] sm:text-xs text-gray-600">Peat</p>
                                </div>
                              </div>

                              {/* Y-axis labels */}
                              <div className="absolute left-0 inset-y-0 w-8 sm:w-10 flex flex-col justify-between py-4">
                                <span className="text-[8px] sm:text-xs text-gray-500 text-right pr-2">100%</span>
                                <span className="text-[8px] sm:text-xs text-gray-500 text-right pr-2">75%</span>
                                <span className="text-[8px] sm:text-xs text-gray-500 text-right pr-2">50%</span>
                                <span className="text-[8px] sm:text-xs text-gray-500 text-right pr-2">25%</span>
                                <span className="text-[8px] sm:text-xs text-gray-500 text-right pr-2">0%</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-8">
                          <div className="bg-gray-50 rounded-xl p-5">
                            <h4 className="font-semibold text-green-700 mb-4 flex items-center">
                              <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mr-2">
                                <CheckCircle className="h-3 w-3 text-green-600" />
                              </div>
                              Yield Factors
                            </h4>
                            <table className="w-full">
                              <tbody>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">Optimal Soil</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "Loam, Well-drained"}
                                    {form.plantType === "tomatoes" && "Loam, Well-drained"}
                                    {form.plantType === "potatoes" && "Loam, Sandy loam"}
                                    {form.plantType === "beans" && "Loam, Well-drained"}
                                    {form.plantType === "cabbage" && "Loam, Clay loam"}
                                    {form.plantType === "onions" && "Sandy loam, Loam"}
                                    {form.plantType === "carrots" && "Sandy loam, Loam"}
                                    {form.plantType === "rice" && "Clay, Clay loam"}
                                    {form.plantType === "tobacco" && "Loam, Sandy loam"}
                                    {form.plantType === "cotton" && "Loam, Sandy loam"}
                                    {form.plantType === "sorghum" && "Loam, Sandy loam"}
                                    {form.plantType === "millet" && "Loam, Sandy loam"}
                                    {form.plantType === "groundnuts" && "Sandy loam, Loam"}
                                    {form.plantType === "soybeans" && "Loam, Sandy loam"}
                                    {form.plantType === "wheat" && "Loam, Clay loam"}
                                    {form.plantType === "sugarcane" && "Loam, Sandy loam"}
                                    {form.plantType === "sweetpotatoes" && "Sandy loam, Loam"}
                                    {form.plantType === "cowpeas" && "Loam, Sandy loam"}
                                    {form.plantType === "sunflower" && "Loam, Sandy loam"}
                                  </td>
                                </tr>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">Fertilizer Impact</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "High (30-50% yield increase)"}
                                    {form.plantType === "tomatoes" && "High (25-40% yield increase)"}
                                    {form.plantType === "potatoes" && "High (30-45% yield increase)"}
                                    {form.plantType === "beans" && "Medium (15-25% yield increase)"}
                                    {form.plantType === "cabbage" && "High (25-40% yield increase)"}
                                    {form.plantType === "onions" && "Medium (20-30% yield increase)"}
                                    {form.plantType === "carrots" && "Medium (15-25% yield increase)"}
                                    {form.plantType === "rice" && "High (30-50% yield increase)"}
                                    {form.plantType === "tobacco" && "High (30-50% yield increase)"}
                                    {form.plantType === "cotton" && "High (30-50% yield increase)"}
                                    {form.plantType === "sorghum" && "High (30-50% yield increase)"}
                                    {form.plantType === "millet" && "High (30-50% yield increase)"}
                                    {form.plantType === "groundnuts" && "High (30-50% yield increase)"}
                                    {form.plantType === "soybeans" && "High (30-50% yield increase)"}
                                    {form.plantType === "wheat" && "High (30-50% yield increase)"}
                                    {form.plantType === "sugarcane" && "High (30-50% yield increase)"}
                                    {form.plantType === "sweetpotatoes" && "High (30-50% yield increase)"}
                                    {form.plantType === "cowpeas" && "High (30-50% yield increase)"}
                                    {form.plantType === "sunflower" && "High (30-50% yield increase)"}
                                  </td>
                                </tr>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">Water Impact</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "High (drought sensitive)"}
                                    {form.plantType === "tomatoes" && "High (consistent moisture needed)"}
                                    {form.plantType === "potatoes" && "Medium (consistent moisture needed)"}
                                    {form.plantType === "beans" && "Medium (drought tolerant after establishment)"}
                                    {form.plantType === "cabbage" && "High (consistent moisture needed)"}
                                    {form.plantType === "onions" && "Medium (consistent moisture needed)"}
                                    {form.plantType === "carrots" && "Medium (consistent moisture needed)"}
                                    {form.plantType === "rice" && "Very High (flooded conditions required)"}
                                    {form.plantType === "tobacco" && "Medium (drought tolerant after establishment)"}
                                    {form.plantType === "cotton" && "Medium (drought tolerant after establishment)"}
                                    {form.plantType === "sorghum" && "Medium (drought tolerant after establishment)"}
                                    {form.plantType === "millet" && "Medium (drought tolerant after establishment)"}
                                    {form.plantType === "groundnuts" && "Medium (drought tolerant after establishment)"}
                                    {form.plantType === "soybeans" && "Medium (drought tolerant after establishment)"}
                                    {form.plantType === "wheat" && "Medium (drought tolerant after establishment)"}
                                    {form.plantType === "sugarcane" && "High (consistent moisture needed)"}
                                    {form.plantType === "sweetpotatoes" &&
                                      "Medium (drought tolerant after establishment)"}
                                    {form.plantType === "cowpeas" && "Medium (drought tolerant after establishment)"}
                                    {form.plantType === "sunflower" && "Medium (drought tolerant after establishment)"}
                                  </td>
                                </tr>
                                <tr>
                                  <td className="py-3 font-medium text-gray-700">Pest Impact</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "tomatoes" && "High (can reduce yield by 30-50%)"}
                                    {form.plantType === "potatoes" && "High (can reduce yield by 30-60%)"}
                                    {form.plantType === "beans" && "Medium (can reduce yield by 15-30%)"}
                                    {form.plantType === "cabbage" && "High (can reduce yield by 25-45%)"}
                                    {form.plantType === "onions" && "Medium (can reduce yield by 15-35%)"}
                                    {form.plantType === "carrots" && "Medium (can reduce yield by 15-30%)"}
                                    {form.plantType === "rice" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "tobacco" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "cotton" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "sorghum" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "millet" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "groundnuts" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "soybeans" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "wheat" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "sugarcane" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "sweetpotatoes" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "cowpeas" && "High (can reduce yield by 20-40%)"}
                                    {form.plantType === "sunflower" && "High (can reduce yield by 20-40%)"}
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>

                          <div className="bg-gray-50 rounded-xl p-5">
                            <h4 className="font-semibold text-green-700 mb-4 flex items-center">
                              <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mr-2">
                                <CheckCircle className="h-3 w-3 text-green-600" />
                              </div>
                              Average Yields
                            </h4>
                            <table className="w-full">
                              <tbody>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">Low Input</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "2.5-3.7 tons/hectare"}
                                    {form.plantType === "tomatoes" && "20-25 tons/hectare"}
                                    {form.plantType === "potatoes" && "12-17 tons/hectare"}
                                    {form.plantType === "beans" && "1.0-1.5 tons/hectare"}
                                    {form.plantType === "cabbage" && "20-25 tons/hectare"}
                                    {form.plantType === "onions" && "12-15 tons/hectare"}
                                    {form.plantType === "carrots" && "15-20 tons/hectare"}
                                    {form.plantType === "rice" && "2.5-3.7 tons/hectare"}
                                    {form.plantType === "tobacco" && "1.5-2.0 tons/hectare"}
                                    {form.plantType === "cotton" && "0.8-1.2 tons/hectare"}
                                    {form.plantType === "sorghum" && "1.5-2.5 tons/hectare"}
                                    {form.plantType === "millet" && "0.8-1.5 tons/hectare"}
                                    {form.plantType === "groundnuts" && "0.8-1.2 tons/hectare"}
                                    {form.plantType === "soybeans" && "1.5-2.0 tons/hectare"}
                                    {form.plantType === "wheat" && "2.5-3.5 tons/hectare"}
                                    {form.plantType === "sugarcane" && "60-70 tons/hectare"}
                                    {form.plantType === "sweetpotatoes" && "10-15 tons/hectare"}
                                    {form.plantType === "cowpeas" && "0.7-1.0 tons/hectare"}
                                    {form.plantType === "sunflower" && "0.8-1.2 tons/hectare"}
                                  </td>
                                </tr>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">Medium Input</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "4.0-6.0 tons/hectare"}
                                    {form.plantType === "tomatoes" && "30-37 tons/hectare"}
                                    {form.plantType === "potatoes" && "20-25 tons/hectare"}
                                    {form.plantType === "beans" && "1.7-2.2 tons/hectare"}
                                    {form.plantType === "cabbage" && "30-37 tons/hectare"}
                                    {form.plantType === "onions" && "17-22 tons/hectare"}
                                    {form.plantType === "carrots" && "22-30 tons/hectare"}
                                    {form.plantType === "rice" && "4.5-5.5 tons/hectare"}
                                    {form.plantType === "tobacco" && "2.2-2.7 tons/hectare"}
                                    {form.plantType === "cotton" && "1.3-1.8 tons/hectare"}
                                    {form.plantType === "sorghum" && "2.7-3.7 tons/hectare"}
                                    {form.plantType === "millet" && "1.7-2.5 tons/hectare"}
                                    {form.plantType === "groundnuts" && "1.3-1.8 tons/hectare"}
                                    {form.plantType === "soybeans" && "2.2-3.0 tons/hectare"}
                                    {form.plantType === "wheat" && "3.7-4.5 tons/hectare"}
                                    {form.plantType === "sugarcane" && "75-85 tons/hectare"}
                                    {form.plantType === "sweetpotatoes" && "17-22 tons/hectare"}
                                    {form.plantType === "cowpeas" && "1.2-1.5 tons/hectare"}
                                    {form.plantType === "sunflower" && "1.3-1.8 tons/hectare"}
                                  </td>
                                </tr>
                                <tr className="border-b border-gray-200">
                                  <td className="py-3 font-medium text-gray-700">High Input</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "7.0-10.0 tons/hectare"}
                                    {form.plantType === "tomatoes" && "45-62 tons/hectare"}
                                    {form.plantType === "potatoes" && "30-45 tons/hectare"}
                                    {form.plantType === "beans" && "2.5-3.0 tons/hectare"}
                                    {form.plantType === "cabbage" && "45-62 tons/hectare"}
                                    {form.plantType === "onions" && "25-37 tons/hectare"}
                                    {form.plantType === "carrots" && "37-50 tons/hectare"}
                                    {form.plantType === "rice" && "6.0-8.5 tons/hectare"}
                                    {form.plantType === "tobacco" && "3.0-3.5 tons/hectare"}
                                    {form.plantType === "cotton" && "2.0-2.5 tons/hectare"}
                                    {form.plantType === "sorghum" && "4.0-5.5 tons/hectare"}
                                    {form.plantType === "millet" && "2.7-3.5 tons/hectare"}
                                    {form.plantType === "groundnuts" && "2.0-2.7 tons/hectare"}
                                    {form.plantType === "soybeans" && "3.2-4.0 tons/hectare"}
                                    {form.plantType === "wheat" && "5.0-6.5 tons/hectare"}
                                    {form.plantType === "sugarcane" && "90-120 tons/hectare"}
                                    {form.plantType === "sweetpotatoes" && "25-35 tons/hectare"}
                                    {form.plantType === "cowpeas" && "1.7-2.2 tons/hectare"}
                                    {form.plantType === "sunflower" && "2.0-2.7 tons/hectare"}
                                  </td>
                                </tr>
                                <tr>
                                  <td className="py-3 font-medium text-gray-700">Record Yield</td>
                                  <td className="py-3 text-gray-900">
                                    {form.plantType === "maize" && "15.0+ tons/hectare"}
                                    {form.plantType === "tomatoes" && "100+ tons/hectare"}
                                    {form.plantType === "potatoes" && "60+ tons/hectare"}
                                    {form.plantType === "beans" && "4.5+ tons/hectare"}
                                    {form.plantType === "cabbage" && "85+ tons/hectare"}
                                    {form.plantType === "onions" && "50+ tons/hectare"}
                                    {form.plantType === "carrots" && "75+ tons/hectare"}
                                    {form.plantType === "rice" && "12.0+ tons/hectare"}
                                    {form.plantType === "tobacco" && "4.5+ tons/hectare"}
                                    {form.plantType === "cotton" && "3.0+ tons/hectare"}
                                    {form.plantType === "sorghum" && "7.0+ tons/hectare"}
                                    {form.plantType === "millet" && "4.5+ tons/hectare"}
                                    {form.plantType === "groundnuts" && "3.5+ tons/hectare"}
                                    {form.plantType === "soybeans" && "5.0+ tons/hectare"}
                                    {form.plantType === "wheat" && "8.0+ tons/hectare"}
                                    {form.plantType === "sugarcane" && "150+ tons/hectare"}
                                    {form.plantType === "sweetpotatoes" && "45+ tons/hectare"}
                                    {form.plantType === "cowpeas" && "3.0+ tons/hectare"}
                                    {form.plantType === "sunflower" && "3.5+ tons/hectare"}
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="tips" className="mt-6">
                <Card className="border-none shadow-lg bg-white">
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center justify-center py-16 text-center bg-gray-50 rounded-lg border border-dashed border-gray-300">
                      <Calendar className="h-12 w-12 text-gray-400 mb-4" />
                      <h3 className="text-lg font-medium text-gray-700 mb-2">Generate Your Guide</h3>
                      <p className="text-gray-500 max-w-md">
                        Fill in the form and click "Generate Planting Guide" to get personalized planting tips
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="guide" className="mt-6">
                <Card className="border-none shadow-lg bg-white">
                  <CardContent className="p-6">
                    {!generatedGuide ? (
                      <div className="flex flex-col items-center justify-center py-16 text-center bg-gray-50 rounded-lg border border-dashed border-gray-300">
                        <Calendar className="h-12 w-12 text-gray-400 mb-4" />
                        <h3 className="text-lg font-medium text-gray-700 mb-2">No Guide Generated Yet</h3>
                        <p className="text-gray-500 max-w-md">
                          Fill in the form and click "Generate Planting Guide" to create your personalized guide
                        </p>
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-center mb-6">
                          <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center mr-4">
                            <Leaf className="h-6 w-6 text-green-600" />
                          </div>
                          <h3 className="text-2xl font-bold text-gray-900 capitalize">
                            {form.plantType} Planting Guide
                          </h3>
                        </div>

                        <div className="prose prose-green max-w-none">
                          {/* Display the generated guide content with proper formatting */}
                          {generatedGuide.split("\n\n").map((paragraph, index) => {
                            // Check if this is a heading (starts with #)
                            if (paragraph.startsWith("# ")) {
                              return (
                                <h2 key={index} className="text-xl font-bold mt-6 mb-3 text-green-800">
                                  {paragraph.replace("# ", "")}
                                </h2>
                              )
                            } else if (paragraph.startsWith("## ")) {
                              return (
                                <h3 key={index} className="text-lg font-bold mt-5 mb-2 text-green-700">
                                  {paragraph.replace("## ", "")}
                                </h3>
                              )
                            } else if (paragraph.startsWith("### ")) {
                              return (
                                <h4 key={index} className="text-base font-bold mt-4 mb-2 text-green-600">
                                  {paragraph.replace("### ", "")}
                                </h4>
                              )
                            } else if (paragraph.startsWith("- ")) {
                              // This is a list
                              return (
                                <ul key={index} className="list-disc pl-5 my-3">
                                  {paragraph.split("\n").map((item, i) => (
                                    <li key={i} className="text-gray-800 my-1">
                                      {item.replace("- ", "")}
                                    </li>
                                  ))}
                                </ul>
                              )
                            } else {
                              // Regular paragraph
                              return (
                                <p key={index} className="my-3 text-gray-800">
                                  {paragraph}
                                </p>
                              )
                            }
                          })}
                        </div>

                        <div className="mt-8 flex justify-end">
                          <Button
                            onClick={saveGuide}
                            className="py-3 sm:py-6 px-4 sm:px-8 text-sm sm:text-base font-medium bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 shadow-md"
                            disabled={isSaving}
                          >
                            {isSaving ? (
                              <>
                                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-5 w-5" />
                                Save This Guide
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}

