"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Save, Share2, Trash2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/components/supabase-provider"

interface GuideActionsProps {
  guideData?: any
  isNew?: boolean
}

export function GuideActions({ guideData, isNew = false }: GuideActionsProps) {
  const [showSaveDialog, setShowSaveDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [guideName, setGuideName] = useState(guideData?.name || "")
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const { toast } = useToast()
  const { user } = useSupabase()

  const handleSave = async () => {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to save planting guides",
        variant: "destructive",
      })
      return
    }

    if (!guideName.trim()) {
      toast({
        title: "Name required",
        description: "Please enter a name for your planting guide",
        variant: "destructive",
      })
      return
    }

    setSaving(true)
    try {
      // In a real app, we would save to Supabase here
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Guide saved",
        description: `"${guideName}" has been saved to your profile`,
      })
      setShowSaveDialog(false)
    } catch (error) {
      toast({
        title: "Error saving guide",
        description: "An error occurred while saving your guide",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async () => {
    setDeleting(true)
    try {
      // In a real app, we would delete from Supabase here
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Guide deleted",
        description: "The planting guide has been deleted",
      })
      setShowDeleteDialog(false)
    } catch (error) {
      toast({
        title: "Error deleting guide",
        description: "An error occurred while deleting your guide",
        variant: "destructive",
      })
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="flex gap-2">
      {isNew ? (
        <Button variant="outline" className="flex items-center gap-2" onClick={() => setShowSaveDialog(true)}>
          <Save className="h-4 w-4" />
          Save Guide
        </Button>
      ) : (
        <>
          <Button variant="outline" className="flex items-center gap-2" onClick={() => setShowDeleteDialog(true)}>
            <Trash2 className="h-4 w-4" />
            Delete
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Share2 className="h-4 w-4" />
            Share
          </Button>
        </>
      )}

      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Planting Guide</DialogTitle>
            <DialogDescription>Save this planting guide to your profile for future reference.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="guide-name">Guide Name</Label>
              <Input
                id="guide-name"
                value={guideName}
                onChange={(e) => setGuideName(e.target.value)}
                placeholder="e.g., Maize Planting Guide 2025"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={saving}>
              {saving ? "Saving..." : "Save Guide"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Planting Guide</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this planting guide? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
              {deleting ? "Deleting..." : "Delete Guide"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

