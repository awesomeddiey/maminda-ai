"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, ChevronLeft, Leaf, Loader2 } from "lucide-react"
import { plantingGuideService, type PlantingGuide } from "@/services/planting-guide-service"
import { useToast } from "@/components/ui/use-toast"

export default function PlantingCalendarPage() {
  const [guide, setGuide] = useState<PlantingGuide | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const guideId = searchParams.get("id")

  useEffect(() => {
    const fetchGuide = async () => {
      if (!guideId) {
        setIsLoading(false)
        return
      }

      try {
        const { data, error } = await plantingGuideService.getGuideById(guideId)
        if (error) throw error
        setGuide(data)
      } catch (error) {
        console.error("Error fetching guide:", error)
        toast({
          title: "Error",
          description: "Failed to load planting guide",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchGuide()
  }, [guideId, toast])

  if (isLoading) {
    return (
      <div className="container py-8 flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <div className="flex flex-col items-center">
          <Loader2 className="h-12 w-12 text-green-600 animate-spin" />
          <p className="mt-4 text-gray-600">Loading planting calendar...</p>
        </div>
      </div>
    )
  }

  if (!guide) {
    return (
      <div className="container py-8">
        <Card className="border-none shadow-lg bg-white">
          <CardContent className="p-6">
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="h-16 w-16 rounded-full bg-amber-100 flex items-center justify-center mb-4">
                <Calendar className="h-8 w-8 text-amber-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">No Guide Selected</h2>
              <p className="text-gray-600 max-w-md mb-6">
                Please create or select a planting guide to view the calendar
              </p>
              <Button
                onClick={() => (window.location.href = "/planting-guide")}
                className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
              >
                <Leaf className="mr-2 h-4 w-4" />
                Create New Guide
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Format the planting date
  const plantingDate = new Date(guide.planting_date)
  const formattedPlantingDate = plantingDate.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  // Calculate harvest date based on crop type (simplified)
  const getHarvestDate = (plantType: string, plantingDate: Date) => {
    const date = new Date(plantingDate)
    const growingPeriods: Record<string, number> = {
      maize: 120,
      tomatoes: 85,
      potatoes: 110,
      beans: 70,
      cabbage: 90,
      onions: 150,
      carrots: 75,
      rice: 130,
    }

    const days = growingPeriods[plantType] || 90
    date.setDate(date.getDate() + days)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const harvestDate = getHarvestDate(guide.plant_type, plantingDate)

  return (
    <div className="container py-8">
      <div className="flex items-center mb-6">
        <Button variant="ghost" size="sm" className="mr-4" onClick={() => window.history.back()}>
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <h1 className="text-2xl font-bold text-gray-900">{guide.title}</h1>
      </div>

      <Tabs defaultValue="calendar" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6 p-1 bg-gray-100 rounded-xl">
          <TabsTrigger
            value="calendar"
            className="rounded-lg py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
          >
            Planting Calendar
          </TabsTrigger>
          <TabsTrigger
            value="guide"
            className="rounded-lg py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
          >
            Full Guide
          </TabsTrigger>
        </TabsList>

        <TabsContent value="calendar">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-1">
              <Card className="border-none shadow-lg bg-white mb-6">
                <CardHeader className="bg-gradient-to-r from-green-50 to-green-100 border-b">
                  <CardTitle className="flex items-center gap-2">
                    <Leaf className="h-5 w-5 text-green-600" />
                    Guide Details
                  </CardTitle>
                  <CardDescription>Information about your planting guide</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium text-gray-500">Crop</h3>
                      <p className="text-lg font-medium text-gray-900 capitalize">{guide.plant_type}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-500">Land Size</h3>
                      <p className="text-lg font-medium text-gray-900">{guide.land_size} acres</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-500">Location</h3>
                      <p className="text-lg font-medium text-gray-900 capitalize">{guide.location}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-500">Soil Type</h3>
                      <p className="text-lg font-medium text-gray-900 capitalize">{guide.soil_type}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-500">Irrigation Method</h3>
                      <p className="text-lg font-medium text-gray-900 capitalize">
                        {guide.irrigation_method || "Not specified"}
                      </p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-500">Previous Crop</h3>
                      <p className="text-lg font-medium text-gray-900 capitalize">
                        {guide.previous_crop || "Not specified"}
                      </p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-500">Expected Yield</h3>
                      <p className="text-lg font-medium text-gray-900">
                        {guide.expected_yield ? `${guide.expected_yield} tons` : "Not specified"}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="md:col-span-2">
              <Card className="border-none shadow-lg bg-white">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-blue-100 border-b">
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-blue-600" />
                    Planting Calendar
                  </CardTitle>
                  <CardDescription>Key dates for your {guide.plant_type} crop</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-6">
                    <div className="relative">
                      <div className="absolute left-4 inset-y-0 w-0.5 bg-gray-200"></div>

                      <div className="relative flex items-start mb-8">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-green-100 text-green-600 ring-8 ring-white mr-4 flex-shrink-0">
                          <Calendar className="h-4 w-4" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">Planting Date</h3>
                          <p className="text-gray-700">{formattedPlantingDate}</p>
                          <div className="mt-2 bg-green-50 text-green-700 px-3 py-2 rounded-md text-sm">
                            Begin planting your {guide.plant_type} crop on this date for optimal results.
                          </div>
                        </div>
                      </div>

                      <div className="relative flex items-start mb-8">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-amber-100 text-amber-600 ring-8 ring-white mr-4 flex-shrink-0">
                          <Calendar className="h-4 w-4" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">Germination Period</h3>
                          <p className="text-gray-700">
                            {new Date(plantingDate.getTime() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString("en-US", {
                              month: "long",
                              day: "numeric",
                            })}{" "}
                            -{" "}
                            {new Date(plantingDate.getTime() + 21 * 24 * 60 * 60 * 1000).toLocaleDateString("en-US", {
                              month: "long",
                              day: "numeric",
                              year: "numeric",
                            })}
                          </p>
                          <div className="mt-2 bg-amber-50 text-amber-700 px-3 py-2 rounded-md text-sm">
                            Ensure adequate moisture during this critical period. Seedlings should emerge within 7-21
                            days depending on conditions.
                          </div>
                        </div>
                      </div>

                      <div className="relative flex items-start mb-8">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-blue-100 text-blue-600 ring-8 ring-white mr-4 flex-shrink-0">
                          <Calendar className="h-4 w-4" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">Growth Period</h3>
                          <p className="text-gray-700">
                            {new Date(plantingDate.getTime() + 21 * 24 * 60 * 60 * 1000).toLocaleDateString("en-US", {
                              month: "long",
                              day: "numeric",
                            })}{" "}
                            -{" "}
                            {new Date(plantingDate.getTime() + 90 * 24 * 60 * 60 * 1000).toLocaleDateString("en-US", {
                              month: "long",
                              day: "numeric",
                              year: "numeric",
                            })}
                          </p>
                          <div className="mt-2 bg-blue-50 text-blue-700 px-3 py-2 rounded-md text-sm">
                            Monitor for pests and diseases. Apply fertilizer as needed. Ensure adequate water supply
                            throughout this period.
                          </div>
                        </div>
                      </div>

                      <div className="relative flex items-start">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-purple-100 text-purple-600 ring-8 ring-white mr-4 flex-shrink-0">
                          <Calendar className="h-4 w-4" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">Expected Harvest Date</h3>
                          <p className="text-gray-700">{harvestDate}</p>
                          <div className="mt-2 bg-purple-50 text-purple-700 px-3 py-2 rounded-md text-sm">
                            Prepare for harvest around this date. Actual harvest time may vary based on local conditions
                            and crop development.
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="guide">
          <Card className="border-none shadow-lg bg-white">
            <CardHeader className="bg-gradient-to-r from-green-50 to-green-100 border-b">
              <CardTitle className="flex items-center gap-2">
                <Leaf className="h-5 w-5 text-green-600" />
                Complete Planting Guide
              </CardTitle>
              <CardDescription>Detailed instructions for your {guide.plant_type} crop</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              {guide.guide_content ? (
                <div className="prose prose-green max-w-none">
                  {guide.guide_content.split("\n\n").map((paragraph, index) => {
                    // Check if this is a heading (starts with #)
                    if (paragraph.startsWith("# ")) {
                      return (
                        <h2 key={index} className="text-xl font-bold mt-6 mb-3 text-green-800">
                          {paragraph.replace("# ", "")}
                        </h2>
                      )
                    } else if (paragraph.startsWith("## ")) {
                      return (
                        <h3 key={index} className="text-lg font-bold mt-5 mb-2 text-green-700">
                          {paragraph.replace("## ", "")}
                        </h3>
                      )
                    } else if (paragraph.startsWith("### ")) {
                      return (
                        <h4 key={index} className="text-base font-bold mt-4 mb-2 text-green-600">
                          {paragraph.replace("### ", "")}
                        </h4>
                      )
                    } else if (paragraph.startsWith("- ")) {
                      // This is a list
                      return (
                        <ul key={index} className="list-disc pl-5 my-3">
                          {paragraph.split("\n").map((item, i) => (
                            <li key={i} className="text-gray-800 my-1">
                              {item.replace("- ", "")}
                            </li>
                          ))}
                        </ul>
                      )
                    } else {
                      // Regular paragraph
                      return (
                        <p key={index} className="my-3 text-gray-800">
                          {paragraph}
                        </p>
                      )
                    }
                  })}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-16 text-center bg-gray-50 rounded-lg border border-dashed border-gray-300">
                  <Calendar className="h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-700 mb-2">No Guide Content Available</h3>
                  <p className="text-gray-500 max-w-md">
                    This guide was created before the AI-generated content feature was available. Create a new guide to
                    get detailed planting instructions.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

