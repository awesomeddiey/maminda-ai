"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/supabase-provider"
import { Card, CardContent } from "@/components/ui/card"
import WeatherWidget from "@/components/weather-widget"
import { NewsSection } from "@/components/news-section"
import { Button } from "@/components/ui/button"
import {
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  Github,
  BarChart3,
  Cloud,
  Thermometer,
  Droplets,
  Wind,
  Sun,
  ArrowRight,
} from "lucide-react"
import Link from "next/link"
import { UnsplashImage, UnsplashBackground } from "@/components/unsplash-image"

export default function HomePage() {
  const { user } = useSupabase()
  const router = useRouter()

  useEffect(() => {
    // If user is not signed in, redirect to landing page
    if (!user) {
      router.push("/")
    }
  }, [user, router])

  if (!user) {
    return null // Don't render anything while redirecting
  }

  return (
    <div className="container py-6">
      {/* Top Section: Three image cards */}
      <section className="mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Link href="/plant-disease-analyzer" className="block">
            <Card className="overflow-hidden h-full transition-all hover:shadow-lg">
              <div className="relative h-48">
                <UnsplashImage
                  query="plant disease green field"
                  category="crops"
                  alt="Plant Disease Detection"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                <div className="absolute bottom-0 p-4 text-white">
                  <h3 className="text-xl font-bold">Plant Disease Detection</h3>
                  <p className="text-sm text-white/80">Identify diseases and get treatment recommendations</p>
                </div>
              </div>
            </Card>
          </Link>

          <Link href="/soil-analyzer" className="block">
            <Card className="overflow-hidden h-full transition-all hover:shadow-lg">
              <div className="relative h-48">
                <UnsplashImage
                  query="soil testing green field"
                  category="soil"
                  alt="Soil Analysis"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                <div className="absolute bottom-0 p-4 text-white">
                  <h3 className="text-xl font-bold">Soil Analysis</h3>
                  <p className="text-sm text-white/80">Analyze soil composition for optimal farming</p>
                </div>
              </div>
            </Card>
          </Link>

          <Link href="/planting-guide" className="block">
            <Card className="overflow-hidden h-full transition-all hover:shadow-lg">
              <div className="relative h-48">
                <UnsplashImage
                  query="planting calendar green field"
                  category="crops"
                  alt="Planting Guide"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                <div className="absolute bottom-0 p-4 text-white">
                  <h3 className="text-xl font-bold">Planting Guide</h3>
                  <p className="text-sm text-white/80">Get personalized planting calendars and guidance</p>
                </div>
              </div>
            </Card>
          </Link>
        </div>
      </section>

      {/* Weather Widget */}
      <section className="mb-6">
        <WeatherWidget />
      </section>

      {/* AI Insights Section */}
      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4 text-gray-900">
          <span className="inline-block pb-2 border-b-2 border-green-500">AI Insights</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="overflow-hidden border-0 shadow-lg">
            <div className="h-2 bg-blue-500"></div>
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <BarChart3 className="h-5 w-5 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold">Crop Performance Analysis</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Based on your recent data, your maize crops are showing excellent growth patterns. Soil moisture levels
                are optimal, and the current weather conditions are favorable for continued growth.
              </p>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="font-medium text-blue-800">Recommendation:</p>
                <p className="text-blue-700">
                  Continue with your current irrigation schedule. Consider applying nitrogen-rich fertilizer within the
                  next 7 days to maximize yield potential.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden border-0 shadow-lg">
            <div className="h-2 bg-green-500"></div>
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                  <Cloud className="h-5 w-5 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold">Weather Pattern Insights</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Our AI has detected a pattern of increased rainfall expected in the coming weeks, which may affect your
                tomato crops that are sensitive to excess moisture.
              </p>
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="font-medium text-green-800">Recommendation:</p>
                <p className="text-green-700">
                  Consider improving drainage in your tomato fields and implementing preventative fungicide treatment to
                  avoid potential disease issues from increased humidity.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-6 text-center">
          <Link href="/dashboard">
            <Button
              size="lg"
              className="bg-green-600 hover:bg-green-700 text-white px-8 py-6 text-lg rounded-lg shadow-lg transition-all hover:shadow-xl"
            >
              View Farm Dashboard
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Best Crops Section */}
      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4 text-gray-900">
          <span className="inline-block pb-2 border-b-2 border-green-500">
            Best Crops According to Weather and Climate Patterns
          </span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="overflow-hidden border-0 shadow-md hover:shadow-xl transition-shadow">
            <div className="h-40 relative">
              <UnsplashImage
                query="maize corn green field"
                category="crops"
                alt="Maize"
                className="w-full h-full object-cover"
              />
            </div>
            <CardContent className="p-5">
              <div className="flex items-center gap-2 mb-2">
                <Thermometer className="h-5 w-5 text-orange-500" />
                <h3 className="text-lg font-semibold">Maize</h3>
              </div>
              <p className="text-gray-600 mb-3">
                Current temperature patterns are ideal for maize growth. The predicted rainfall over the next month
                aligns perfectly with maize water requirements.
              </p>
              <div className="flex flex-wrap gap-2 mb-3">
                <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">High Yield Potential</span>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">Water Efficient</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center">
                  <Sun className="h-4 w-4 text-yellow-500 mr-1" />
                  <span>Full Sun</span>
                </div>
                <div className="flex items-center">
                  <Droplets className="h-4 w-4 text-blue-500 mr-1" />
                  <span>Moderate Water</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden border-0 shadow-md hover:shadow-xl transition-shadow">
            <div className="h-40 relative">
              <UnsplashImage
                query="sweet potato green field"
                category="vegetables"
                alt="Sweet Potatoes"
                className="w-full h-full object-cover"
              />
            </div>
            <CardContent className="p-5">
              <div className="flex items-center gap-2 mb-2">
                <Droplets className="h-5 w-5 text-blue-500" />
                <h3 className="text-lg font-semibold">Sweet Potatoes</h3>
              </div>
              <p className="text-gray-600 mb-3">
                Sweet potatoes thrive in your region's current climate conditions. They're drought-resistant and
                well-suited to the predicted dry spell in the coming months.
              </p>
              <div className="flex flex-wrap gap-2 mb-3">
                <span className="px-2 py-1 bg-orange-100 text-orange-800 text-xs rounded-full">Drought Resistant</span>
                <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full">Nutritious</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center">
                  <Sun className="h-4 w-4 text-yellow-500 mr-1" />
                  <span>Partial Sun</span>
                </div>
                <div className="flex items-center">
                  <Droplets className="h-4 w-4 text-blue-500 mr-1" />
                  <span>Low Water</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden border-0 shadow-md hover:shadow-xl transition-shadow">
            <div className="h-40 relative">
              <UnsplashImage
                query="bean plants green field"
                category="vegetables"
                alt="Beans"
                className="w-full h-full object-cover"
              />
            </div>
            <CardContent className="p-5">
              <div className="flex items-center gap-2 mb-2">
                <Wind className="h-5 w-5 text-cyan-500" />
                <h3 className="text-lg font-semibold">Beans</h3>
              </div>
              <p className="text-gray-600 mb-3">
                Beans are well-suited to your current soil conditions and climate patterns. They also help fix nitrogen
                in the soil, benefiting future crop rotations.
              </p>
              <div className="flex flex-wrap gap-2 mb-3">
                <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">Soil Enriching</span>
                <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">Quick Harvest</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center">
                  <Sun className="h-4 w-4 text-yellow-500 mr-1" />
                  <span>Full Sun</span>
                </div>
                <div className="flex items-center">
                  <Droplets className="h-4 w-4 text-blue-500 mr-1" />
                  <span>Moderate Water</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Planting News */}
      <section className="mb-6">
        <h2 className="text-2xl font-bold mb-4 text-gray-900">
          <span className="inline-block pb-2 border-b-2 border-green-500">Latest Farming News</span>
        </h2>
        <NewsSection />
      </section>

      {/* Footer with image background and socials */}
      <UnsplashBackground
        query="green fields sunset"
        category="landscape"
        className="mt-12 py-8 rounded-lg overflow-hidden"
      >
        <div className="relative z-10 container mx-auto px-4">
          <div className="flex flex-col items-center">
            <h3 className="text-2xl font-bold mb-4">Maminda AI</h3>
            <div className="flex space-x-6 mb-6">
              <Link href="#" className="hover:text-green-400 transition-colors">
                <Facebook size={24} />
              </Link>
              <Link href="#" className="hover:text-green-400 transition-colors">
                <Twitter size={24} />
              </Link>
              <Link href="#" className="hover:text-green-400 transition-colors">
                <Instagram size={24} />
              </Link>
              <Link href="#" className="hover:text-green-400 transition-colors">
                <Linkedin size={24} />
              </Link>
              <Link href="#" className="hover:text-green-400 transition-colors">
                <Github size={24} />
              </Link>
            </div>
            <p className="text-center text-sm">Maminda AI ©2025</p>
          </div>
        </div>
      </UnsplashBackground>
    </div>
  )
}

