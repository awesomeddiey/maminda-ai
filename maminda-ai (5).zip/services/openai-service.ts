import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export class OpenAIService {
  async generatePlantingGuide(
    plantType: string,
    landSize: string,
    location: string,
    soilType: string,
    plantingDate: string,
    irrigationMethod: string,
    previousCrop: string,
    expectedYield: string,
  ): Promise<string> {
    try {
      const prompt = `
        Generate a comprehensive planting guide for the following crop:
        
        Plant Type: ${plantType}
        Land Size: ${landSize} acres
        Location: ${location}
        Soil Type: ${soilType}
        Planting Date: ${plantingDate}
        Irrigation Method: ${irrigationMethod || "Not specified"}
        Previous Crop: ${previousCrop || "Not specified"}
        Expected Yield: ${expectedYield || "Not specified"}
        
        The guide should include:
        1. Detailed planting instructions
        2. Optimal growing conditions
        3. Watering schedule
        4. Fertilization recommendations
        5. Pest and disease management
        6. Harvesting guidelines
        7. Storage recommendations
        8. Specific considerations for the given location and soil type
        
        Format the guide in a structured way with clear sections and practical advice for farmers.
      `

      const { text } = await generateText({
        model: openai("gpt-4o"),
        prompt: prompt,
        system:
          "You are an expert agricultural advisor with deep knowledge of farming practices, crop management, and regional growing conditions. Provide detailed, practical, and scientifically accurate guidance for farmers.",
      })

      return text
    } catch (error) {
      console.error("Error generating planting guide:", error)
      throw new Error("Failed to generate planting guide. Please try again later.")
    }
  }
}

export const openAIService = new OpenAIService()

