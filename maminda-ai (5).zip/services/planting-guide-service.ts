import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

export interface PlantingGuide {
  id?: string
  user_id: string
  title: string
  plant_type: string
  land_size: string
  location: string
  soil_type: string
  planting_date: string
  irrigation_method: string
  previous_crop: string
  expected_yield: string
  created_at?: string
  guide_content?: string // Add this field to store the generated guide content
}

export class PlantingGuideService {
  private supabase = createClientComponentClient({
    supabaseUrl: "https://hunouafyfpcouvdcmcmo.supabase.co",
    supabaseKey:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bm91YWZ5ZnBjb3V2ZGNtY21vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE5ODQ5MTcsImV4cCI6MjA1NzU2MDkxN30.LUxgbEBB_y_Jd6nBOBBu6QOWwKliyGgcLfB3jLaCCOc",
  })

  async createGuide(guide: PlantingGuide): Promise<{ data: PlantingGuide | null; error: any }> {
    // Add created_at field with current timestamp
    const guideWithTimestamp = {
      ...guide,
      created_at: new Date().toISOString(),
    }

    const { data, error } = await this.supabase.from("planting_guides").insert([guideWithTimestamp]).select().single()

    return { data, error }
  }

  async getUserGuides(userId: string): Promise<{ data: PlantingGuide[] | null; error: any }> {
    const { data, error } = await this.supabase
      .from("planting_guides")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    return { data, error }
  }

  async getGuideById(guideId: string): Promise<{ data: PlantingGuide | null; error: any }> {
    const { data, error } = await this.supabase.from("planting_guides").select("*").eq("id", guideId).single()

    return { data, error }
  }

  async updateGuide(
    guideId: string,
    updates: Partial<PlantingGuide>,
  ): Promise<{ data: PlantingGuide | null; error: any }> {
    const { data, error } = await this.supabase
      .from("planting_guides")
      .update(updates)
      .eq("id", guideId)
      .select()
      .single()

    return { data, error }
  }

  async deleteGuide(guideId: string): Promise<{ error: any }> {
    const { error } = await this.supabase.from("planting_guides").delete().eq("id", guideId)

    return { error }
  }

  generateGuideTitle(plantType: string, location: string): string {
    const date = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long" })
    return `${plantType.charAt(0).toUpperCase() + plantType.slice(1)} Planting Guide - ${location} (${date})`
  }
}

export const plantingGuideService = new PlantingGuideService()

