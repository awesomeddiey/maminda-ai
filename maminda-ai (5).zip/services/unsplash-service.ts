import { env } from "@/app/env"

// Define the Unsplash image response type
export interface UnsplashImage {
  id: string
  urls: {
    raw: string
    full: string
    regular: string
    small: string
    thumb: string
  }
  alt_description: string
  user: {
    name: string
    username: string
  }
}

// Cache for storing fetched images to reduce API calls
const imageCache: Record<string, UnsplashImage[]> = {}

/**
 * Fetch images from Unsplash API based on query
 */
export async function getUnsplashImages(
  query: string,
  count = 1,
  orientation: "landscape" | "portrait" | "squarish" = "landscape",
): Promise<UnsplashImage[]> {
  // Create a cache key based on the query parameters
  const cacheKey = `${query}-${count}-${orientation}`

  // Check if we have cached results
  if (imageCache[cacheKey]) {
    return imageCache[cacheKey]
  }

  try {
    const accessKey = env.UNSPLASH_ACCESS_KEY

    if (!accessKey) {
      console.error("Unsplash access key is missing")
      return getFallbackImages(query, count)
    }

    const url = `https://api.unsplash.com/search/photos?query=${encodeURIComponent(query)}&per_page=${count}&orientation=${orientation}`

    const response = await fetch(url, {
      headers: {
        Authorization: `Client-ID ${accessKey}`,
      },
    })

    if (!response.ok) {
      throw new Error(`Unsplash API error: ${response.status}`)
    }

    const data = await response.json()
    const images = data.results as UnsplashImage[]

    // Cache the results
    imageCache[cacheKey] = images

    return images
  } catch (error) {
    console.error("Error fetching Unsplash images:", error)
    return getFallbackImages(query, count)
  }
}

/**
 * Get a single Unsplash image
 */
export async function getUnsplashImage(
  query: string,
  orientation: "landscape" | "portrait" | "squarish" = "landscape",
): Promise<UnsplashImage> {
  const images = await getUnsplashImages(query, 1, orientation)
  return images[0]
}

/**
 * Get a random image URL from Unsplash based on query
 */
export async function getUnsplashImageUrl(
  query: string,
  size: "regular" | "small" | "thumb" | "full" = "regular",
  orientation: "landscape" | "portrait" | "squarish" = "landscape",
): Promise<string> {
  try {
    const image = await getUnsplashImage(query, orientation)
    return image?.urls[size] || getFallbackImageUrl(query)
  } catch (error) {
    return getFallbackImageUrl(query)
  }
}

/**
 * Provide fallback images when Unsplash API fails
 */
function getFallbackImages(query: string, count: number): UnsplashImage[] {
  const fallbacks: UnsplashImage[] = []

  for (let i = 0; i < count; i++) {
    fallbacks.push({
      id: `fallback-${i}`,
      urls: {
        raw: getFallbackImageUrl(query),
        full: getFallbackImageUrl(query),
        regular: getFallbackImageUrl(query),
        small: getFallbackImageUrl(query),
        thumb: getFallbackImageUrl(query),
      },
      alt_description: `Fallback image for ${query}`,
      user: {
        name: "Placeholder",
        username: "placeholder",
      },
    })
  }

  return fallbacks
}

/**
 * Generate a fallback image URL using placeholder service
 */
function getFallbackImageUrl(query: string): string {
  // Use a placeholder service with the query as text
  return `/placeholder.svg?height=400&width=600&text=${encodeURIComponent(query)}`
}

/**
 * Get farming-related images for different categories
 */
export async function getFarmingImages(category: string, count = 1): Promise<UnsplashImage[]> {
  const queryMap: Record<string, string> = {
    crops: "green fields crops agriculture",
    vegetables: "green vegetable farm garden",
    fruits: "green orchard farm fields",
    livestock: "farm animals green pasture",
    equipment: "farm equipment tractor green field",
    landscape: "green farm landscape rural fields",
    soil: "fertile soil farm agriculture",
    weather: "farm weather green fields",
    farmers: "farmer agriculture green field",
    harvest: "harvest green farm crops",
    fields: "lush green fields farm",
    meadows: "green meadows farmland",
    pasture: "green pasture grassland",
    grassland: "green grassland agriculture",
    plantation: "green plantation rows",
  }

  const query = queryMap[category] || "farming agriculture"
  return getUnsplashImages(query, count)
}

/**
 * Get a farming-related image URL
 */
export async function getFarmingImageUrl(
  category: string,
  size: "regular" | "small" | "thumb" | "full" = "regular",
): Promise<string> {
  try {
    const images = await getFarmingImages(category, 1)
    return images[0]?.urls[size] || getFallbackImageUrl(category)
  } catch (error) {
    return getFallbackImageUrl(category)
  }
}

