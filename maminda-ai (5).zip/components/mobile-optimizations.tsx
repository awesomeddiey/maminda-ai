"use client"

import { useEffect } from "react"

export function MobileOptimizations() {
  useEffect(() => {
    // Add viewport meta tag for better mobile rendering
    const meta = document.createElement("meta")
    meta.name = "viewport"
    meta.content = "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"
    document.head.appendChild(meta)

    // Add touch action improvements
    const style = document.createElement("style")
    style.textContent = `
      * {
        -webkit-tap-highlight-color: transparent;
      }
      
      input, button, a {
        touch-action: manipulation;
      }
      
      @media (max-width: 640px) {
        .container {
          padding-left: 1rem;
          padding-right: 1rem;
        }
      }
    `
    document.head.appendChild(style)

    return () => {
      document.head.removeChild(meta)
      document.head.removeChild(style)
    }
  }, [])

  return null
}

