"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, X } from "lucide-react"

interface FarmImage {
  src: string
  alt: string
  caption?: string
}

interface FarmImageGalleryProps {
  images: FarmImage[]
  title?: string
}

export function FarmImageGallery({ images, title }: FarmImageGalleryProps) {
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null)

  const openImage = (index: number) => {
    setSelectedImageIndex(index)
  }

  const closeImage = () => {
    setSelectedImageIndex(null)
  }

  const nextImage = () => {
    if (selectedImageIndex === null) return
    setSelectedImageIndex((selectedImageIndex + 1) % images.length)
  }

  const prevImage = () => {
    if (selectedImageIndex === null) return
    setSelectedImageIndex((selectedImageIndex - 1 + images.length) % images.length)
  }

  return (
    <div className="space-y-4">
      {title && (
        <h2 className="text-2xl font-bold mb-4 text-gray-900">
          <span className="inline-block pb-2 border-b-2 border-green-500">{title}</span>
        </h2>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
        {images.map((image, index) => (
          <Card
            key={index}
            className="overflow-hidden cursor-pointer hover:shadow-md transition-all duration-300 transform hover:scale-[1.02]"
            onClick={() => openImage(index)}
          >
            <div className="aspect-square relative">
              <img src={image.src || "/placeholder.svg"} alt={image.alt} className="object-cover w-full h-full" />
              {image.caption && (
                <div className="absolute inset-x-0 bottom-0 bg-black/60 p-2">
                  <p className="text-xs text-white">{image.caption}</p>
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>

      <Dialog open={selectedImageIndex !== null} onOpenChange={(open) => !open && closeImage()}>
        <DialogContent className="max-w-4xl p-0 bg-black/90 border-none">
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 text-white hover:bg-white/20 z-10"
              onClick={closeImage}
            >
              <X className="h-6 w-6" />
            </Button>

            {selectedImageIndex !== null && (
              <>
                <div className="flex items-center justify-center h-[80vh]">
                  <img
                    src={images[selectedImageIndex].src || "/placeholder.svg"}
                    alt={images[selectedImageIndex].alt}
                    className="max-h-full max-w-full object-contain"
                  />
                </div>

                {images[selectedImageIndex].caption && (
                  <div className="absolute inset-x-0 bottom-0 bg-black/60 p-4">
                    <p className="text-white text-center">{images[selectedImageIndex].caption}</p>
                  </div>
                )}

                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-1/2 left-2 transform -translate-y-1/2 text-white hover:bg-white/20"
                  onClick={prevImage}
                >
                  <ChevronLeft className="h-8 w-8" />
                </Button>

                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-1/2 right-2 transform -translate-y-1/2 text-white hover:bg-white/20"
                  onClick={nextImage}
                >
                  <ChevronRight className="h-8 w-8" />
                </Button>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

