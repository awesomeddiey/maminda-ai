import type React from "react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

interface FeatureCardProps {
  title: string
  description: string
  icon: React.ReactNode
  href: string
  color?: "green" | "blue" | "purple" | "orange"
  className?: string
}

export function FeatureCard({ title, description, icon, href, color = "green", className }: FeatureCardProps) {
  const getGradientColors = () => {
    switch (color) {
      case "blue":
        return "from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 border-blue-200"
      case "purple":
        return "from-purple-50 to-purple-100 hover:from-purple-100 hover:to-purple-200 border-purple-200"
      case "orange":
        return "from-orange-50 to-orange-100 hover:from-orange-100 hover:to-orange-200 border-orange-200"
      case "green":
      default:
        return "from-green-50 to-green-100 hover:from-green-100 hover:to-green-200 border-green-200"
    }
  }

  const getIconBackground = () => {
    switch (color) {
      case "blue":
        return "bg-blue-100 text-blue-600"
      case "purple":
        return "bg-purple-100 text-purple-600"
      case "orange":
        return "bg-orange-100 text-orange-600"
      case "green":
      default:
        return "bg-green-100 text-green-600"
    }
  }

  return (
    <Link href={href} className="group">
      <Card
        className={`h-full border bg-gradient-to-br ${getGradientColors()} transition-all duration-300 transform hover:scale-[1.02] hover:shadow-lg ${className}`}
      >
        <CardContent className="p-6">
          <div className="flex flex-col items-center text-center">
            <div
              className={`w-16 h-16 ${getIconBackground()} rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}
            >
              {icon}
            </div>
            <h3 className="text-xl font-semibold mb-2 text-gray-900">{title}</h3>
            <p className="text-sm text-gray-600">{description}</p>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

