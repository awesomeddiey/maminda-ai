"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import type { SupabaseClient, User } from "@supabase/auth-helpers-nextjs"

type SupabaseContext = {
  supabase: SupabaseClient
  user: User | null
  loading: boolean
}

const Context = createContext<SupabaseContext | undefined>(undefined)

export function SupabaseProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  // Explicitly pass the Supabase URL and anon key
  const supabase = createClientComponentClient({
    supabaseUrl: "https://hunouafyfpcouvdcmcmo.supabase.co",
    supabaseKey:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bm91YWZ5ZnBjb3V2ZGNtY21vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE5ODQ5MTcsImV4cCI6MjA1NzU2MDkxN30.LUxgbEBB_y_Jd6nBOBBu6QOWwKliyGgcLfB3jLaCCOc",
  })

  useEffect(() => {
    const getUser = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()
      setUser(session?.user ?? null)
      setLoading(false)

      const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
        setUser(session?.user ?? null)

        // Store session in localStorage to persist authentication
        if (session) {
          localStorage.setItem("maminda_session", JSON.stringify(session))
        } else if (event === "SIGNED_OUT") {
          localStorage.removeItem("maminda_session")
        }
      })

      return () => {
        authListener.subscription.unsubscribe()
      }
    }

    // Check for existing session in localStorage on initialization
    const storedSession = localStorage.getItem("maminda_session")
    if (storedSession) {
      try {
        const parsedSession = JSON.parse(storedSession)
        // Refresh the session if it exists
        supabase.auth.setSession({
          access_token: parsedSession.access_token,
          refresh_token: parsedSession.refresh_token,
        })
      } catch (error) {
        console.error("Error restoring session:", error)
        localStorage.removeItem("maminda_session")
      }
    }

    getUser()
  }, [supabase.auth])

  return <Context.Provider value={{ supabase, user, loading }}>{children}</Context.Provider>
}

export const useSupabase = () => {
  const context = useContext(Context)
  if (context === undefined) {
    throw new Error("useSupabase must be used inside SupabaseProvider")
  }
  return context
}

