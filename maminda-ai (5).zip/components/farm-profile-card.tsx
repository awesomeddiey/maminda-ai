import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface FarmProfileCardProps {
  farmName: string
  location: string
  size: string
  mainCrops: string[]
  imageSrc: string
}

export function FarmProfileCard({ farmName, location, size, mainCrops, imageSrc }: FarmProfileCardProps) {
  return (
    <Card className="overflow-hidden border-2 border-green-100">
      <div className="h-48 overflow-hidden">
        <img src={imageSrc || "/placeholder.svg"} alt={farmName} className="w-full h-full object-cover" />
      </div>
      <CardHeader className="pb-2">
        <CardTitle>{farmName}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm font-medium text-gray-500">Location:</span>
            <span className="text-sm text-gray-900">{location}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm font-medium text-gray-500">Farm Size:</span>
            <span className="text-sm text-gray-900">{size}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm font-medium text-gray-500">Main Crops:</span>
            <span className="text-sm text-gray-900">{mainCrops.join(", ")}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

