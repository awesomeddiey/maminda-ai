"use client"

import type React from "react"

import { UnsplashBackground } from "./unsplash-image"

interface ImageBackgroundSectionProps {
  children: React.ReactNode
  imageQuery?: string
  className?: string
  overlayOpacity?: number
  height?: string
}

export function ImageBackgroundSection({
  children,
  imageQuery = "lush green fields farm",
  className = "",
  overlayOpacity = 60,
  height = "min-h-[400px]",
}: ImageBackgroundSectionProps) {
  return (
    <UnsplashBackground query={imageQuery} className={`${height} w-full flex items-center justify-center ${className}`}>
      <div className={`w-full h-full flex items-center justify-center bg-black/[${overlayOpacity / 100}]`}>
        <div className="container mx-auto px-4 py-12">{children}</div>
      </div>
    </UnsplashBackground>
  )
}

