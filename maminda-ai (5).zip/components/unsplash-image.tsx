"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Image from "next/image"
import { getUnsplashImageUrl } from "@/services/unsplash-service"

interface UnsplashImageProps {
  query: string
  alt: string
  className?: string
  width?: number
  height?: number
  size?: "regular" | "small" | "thumb" | "full"
  priority?: boolean
  orientation?: "landscape" | "portrait" | "squarish"
}

export function UnsplashImage({
  query,
  alt,
  className = "",
  width = 800,
  height = 600,
  size = "regular",
  priority = false,
  orientation = "landscape",
}: UnsplashImageProps) {
  const [imageUrl, setImageUrl] = useState<string>(
    `/placeholder.svg?height=${height}&width=${width}&text=${encodeURIComponent(query)}`,
  )
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  useEffect(() => {
    const fetchImage = async () => {
      try {
        setLoading(true)
        const url = await getUnsplashImageUrl(query, size, orientation)
        setImageUrl(url)
        setError(false)
      } catch (err) {
        console.error("Error loading Unsplash image:", err)
        setError(true)
      } finally {
        setLoading(false)
      }
    }

    fetchImage()
  }, [query, size, orientation])

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
          <div className="animate-pulse text-gray-400">Loading...</div>
        </div>
      )}

      <Image
        src={imageUrl || "/placeholder.svg"}
        alt={alt}
        width={width}
        height={height}
        className={`object-cover transition-opacity duration-300 ${loading ? "opacity-0" : "opacity-100"}`}
        priority={priority}
        onError={() => setError(true)}
      />

      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
          <div className="text-gray-500">Image unavailable</div>
        </div>
      )}

      <div className="absolute bottom-0 right-0 bg-black bg-opacity-50 text-white text-xs px-2 py-1">
        Photo via Unsplash
      </div>
    </div>
  )
}

export function UnsplashBackground({
  query,
  children,
  className = "",
  orientation = "landscape",
}: {
  query: string
  children: React.ReactNode
  className?: string
  orientation?: "landscape" | "portrait" | "squarish"
}) {
  const [imageUrl, setImageUrl] = useState<string>("/placeholder.svg?height=1080&width=1920")

  useEffect(() => {
    const fetchImage = async () => {
      try {
        const url = await getUnsplashImageUrl(query, "regular", orientation)
        setImageUrl(url)
      } catch (err) {
        console.error("Error loading Unsplash background:", err)
      }
    }

    fetchImage()
  }, [query, orientation])

  return (
    <div className={`relative bg-cover bg-center ${className}`} style={{ backgroundImage: `url(${imageUrl})` }}>
      {children}
    </div>
  )
}

