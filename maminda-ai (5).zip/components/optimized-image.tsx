import type React from "react"
import Image from "next/image"

interface OptimizedImageProps extends React.ComponentProps<typeof Image> {
  priority?: boolean
  className?: string
}

export function OptimizedImage({ src, alt, width, height, priority, className, ...props }: OptimizedImageProps) {
  return (
    <Image
      src={src || "/placeholder.svg"}
      alt={alt}
      width={width}
      height={height}
      className={className}
      {...props}
      priority={priority}
    />
  )
}

