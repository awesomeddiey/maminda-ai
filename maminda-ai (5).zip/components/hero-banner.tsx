"use client"

import type React from "react"
import { UnsplashBackground } from "./unsplash-image"

interface HeroBannerProps {
  title: string
  subtitle?: string
  children?: React.ReactNode
  className?: string
  imageQuery?: string
  overlay?: boolean
  height?: string
}

export function HeroBanner({
  title,
  subtitle,
  children,
  className = "",
  imageQuery = "green fields farm landscape",
  overlay = true,
  height = "h-[500px]",
}: HeroBannerProps) {
  return (
    <UnsplashBackground query={imageQuery} className={`${height} w-full flex items-center justify-center ${className}`}>
      <div className={`w-full h-full flex items-center justify-center ${overlay ? "bg-black/40" : ""}`}>
        <div className="text-center px-4 max-w-4xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4">{title}</h1>
          {subtitle && <p className="text-xl md:text-2xl text-white/90 mb-8">{subtitle}</p>}
          {children}
        </div>
      </div>
    </UnsplashBackground>
  )
}

