"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { MessageSquare, Send, X, User, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { useSupabase } from "./supabase-provider"
import { useToast } from "@/hooks/use-toast"

interface Message {
  id: string
  sender: string
  content: string
  timestamp: Date
  isSupport?: boolean
}

export function LiveChat() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      sender: "Support",
      content: "Hello! How can I help you today with Maminda AI?",
      timestamp: new Date(),
      isSupport: true,
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { user } = useSupabase()
  const { toast } = useToast()

  useEffect(() => {
    scrollToBottom()
  }, [messages, isOpen])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to use the chat feature",
        variant: "destructive",
      })
      return
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      sender: user.user_metadata.full_name || user.email || "User",
      content: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    // Simulate response delay
    setTimeout(() => {
      const supportMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: "Support",
        content: getAutoResponse(input.trim()),
        timestamp: new Date(),
        isSupport: true,
      }
      setMessages((prev) => [...prev, supportMessage])
      setIsLoading(false)
    }, 1500)
  }

  const getAutoResponse = (message: string): string => {
    const lowerMessage = message.toLowerCase()

    if (lowerMessage.includes("hello") || lowerMessage.includes("hi")) {
      return "Hello! How can I assist you with Maminda AI today?"
    } else if (lowerMessage.includes("planting") || lowerMessage.includes("crop")) {
      return "For planting advice, I recommend checking our Planting Guide section. Is there a specific crop you're interested in?"
    } else if (lowerMessage.includes("weather")) {
      return "Our weather data is updated regularly. You can find detailed forecasts on the home page or in the Dashboard section."
    } else if (lowerMessage.includes("disease") || lowerMessage.includes("pest")) {
      return "For plant diseases and pests, try our Disease Scanner feature. You can upload photos of affected plants for analysis."
    } else if (lowerMessage.includes("account") || lowerMessage.includes("profile")) {
      return "You can manage your account settings in the Profile section. Need help with something specific?"
    } else {
      return "Thank you for your message. Our team will get back to you soon. In the meantime, feel free to explore our Help & Support section for more information."
    }
  }

  return (
    <>
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-24 right-6 h-14 w-14 rounded-full shadow-lg bg-green-600 hover:bg-green-700 text-white"
        aria-label="Live Chat"
      >
        <MessageSquare className="h-6 w-6" />
      </Button>

      {isOpen && (
        <Card className="fixed bottom-24 right-6 w-[90vw] max-w-[400px] shadow-lg border-green-600 z-50">
          <CardHeader className="pb-2 border-b">
            <CardTitle className="text-lg flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-green-600" />
              Live Chat
              <Button variant="ghost" size="sm" className="ml-auto h-8 w-8 p-0" onClick={() => setIsOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[350px] overflow-y-auto p-4">
              {messages.map((message) => (
                <div key={message.id} className={`mb-4 flex ${message.isSupport ? "justify-start" : "justify-end"}`}>
                  {message.isSupport && (
                    <Avatar className="h-8 w-8 mr-2">
                      <AvatarImage src="/placeholder.svg?height=32&width=32" />
                      <AvatarFallback className="bg-green-100 text-green-600">S</AvatarFallback>
                    </Avatar>
                  )}
                  <div
                    className={`rounded-lg px-3 py-2 max-w-[80%] ${
                      message.isSupport ? "bg-muted" : "bg-green-600 text-white"
                    }`}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-xs font-medium">{message.sender}</span>
                      <span className="text-xs opacity-70 ml-2">
                        {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                    {message.content}
                  </div>
                  {!message.isSupport && (
                    <Avatar className="h-8 w-8 ml-2">
                      <AvatarFallback className="bg-green-100 text-green-600">
                        <User className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
              {isLoading && (
                <div className="mb-4 flex justify-start">
                  <Avatar className="h-8 w-8 mr-2">
                    <AvatarFallback className="bg-green-100 text-green-600">S</AvatarFallback>
                  </Avatar>
                  <div className="rounded-lg px-3 py-2 bg-muted flex items-center">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="ml-2">Typing...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
            <form onSubmit={handleSubmit} className="border-t p-4 flex gap-2">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message..."
                className="min-h-[40px] resize-none"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault()
                    handleSubmit(e)
                  }
                }}
              />
              <Button
                type="submit"
                size="icon"
                disabled={isLoading || !input.trim()}
                className="bg-green-600 hover:bg-green-700"
              >
                <Send className="h-4 w-4" />
                <span className="sr-only">Send</span>
              </Button>
            </form>
          </CardContent>
        </Card>
      )}
    </>
  )
}

