import { Card, CardContent } from "@/components/ui/card"

interface FarmStatProps {
  title: string
  value: string
  change?: string
  isPositive?: boolean
  imageSrc: string
}

export function FarmStatsCard({ title, value, change, isPositive = true, imageSrc }: FarmStatProps) {
  return (
    <Card className="overflow-hidden">
      <div className="h-32 relative">
        <img
          src={imageSrc || "/placeholder.svg?height=150&width=300"}
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
        <div className="absolute bottom-0 left-0 p-4">
          <h3 className="text-white font-medium">{title}</h3>
        </div>
      </div>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold">{value}</span>
          {change && (
            <span className={`text-sm font-medium ${isPositive ? "text-green-600" : "text-red-600"}`}>
              {isPositive ? "↑" : "↓"} {change}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

