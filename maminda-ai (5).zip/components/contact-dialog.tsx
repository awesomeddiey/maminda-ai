"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Mail, Phone, MessageSquare, Facebook, Twitter, Instagram, ExternalLink } from "lucide-react"
import { useState } from "react"

interface ContactDialogProps {
  trigger?: React.ReactNode
}

export function ContactDialog({ trigger }: ContactDialogProps) {
  const [open, setOpen] = useState(false)

  const contactInfo = {
    email: "support@mamindaai.co.zw",
    phone: "+263 77 210 9787",
    whatsapp: "+263 77 210 9787",
    socialMedia: "maminda ai",
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger || <Button variant="ghost">Contact Us</Button>}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">Contact Us</DialogTitle>
          <DialogDescription className="text-center">
            Get in touch with our team for support or inquiries
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-6 py-4">
          <div className="grid gap-4">
            <div className="flex items-center gap-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100">
                <Mail className="h-5 w-5 text-green-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium">Email</h3>
                <a
                  href={`mailto:${contactInfo.email}`}
                  className="text-sm text-muted-foreground hover:text-green-600 flex items-center gap-1"
                >
                  {contactInfo.email}
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100">
                <Phone className="h-5 w-5 text-green-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium">Phone</h3>
                <a
                  href={`tel:${contactInfo.phone.replace(/\s+/g, "")}`}
                  className="text-sm text-muted-foreground hover:text-green-600 flex items-center gap-1"
                >
                  {contactInfo.phone}
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100">
                <MessageSquare className="h-5 w-5 text-green-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium">WhatsApp</h3>
                <a
                  href={`https://wa.me/${contactInfo.whatsapp.replace(/\+|\s+/g, "")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-muted-foreground hover:text-green-600 flex items-center gap-1"
                >
                  {contactInfo.whatsapp}
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>
          </div>

          <div className="border-t pt-4">
            <h3 className="font-medium mb-3 text-center">Follow Us</h3>
            <div className="flex justify-center gap-4">
              <a
                href="https://facebook.com/mamindaai"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-green-100 hover:bg-green-200 transition-colors"
              >
                <Facebook className="h-5 w-5 text-green-600" />
              </a>
              <a
                href="https://twitter.com/mamindaai"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-green-100 hover:bg-green-200 transition-colors"
              >
                <Twitter className="h-5 w-5 text-green-600" />
              </a>
              <a
                href="https://instagram.com/mamindaai"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-green-100 hover:bg-green-200 transition-colors"
              >
                <Instagram className="h-5 w-5 text-green-600" />
              </a>
            </div>
            <p className="text-xs text-center text-muted-foreground mt-3">
              Find us on social media: {contactInfo.socialMedia}
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

