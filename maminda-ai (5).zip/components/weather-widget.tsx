"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Cloud, CloudRain, Sun, Wind, MapPin, Thermometer, Droplet } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { env } from "@/app/env"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface WeatherData {
  main: {
    temp: number
    humidity: number
    feels_like: number
  }
  weather: {
    main: string
    description: string
    icon: string
  }[]
  wind: {
    speed: number
  }
  name: string
  sys: {
    country: string
  }
}

interface ForecastData {
  dt: number
  main: {
    temp: number
    humidity: number
  }
  weather: [
    {
      main: string
      description: string
      icon: string
    },
  ]
  wind: {
    speed: number
  }
  dt_txt: string
}

interface SoilData {
  moisture: number
  temperature: number
  ph: number
  nitrogen: number
  phosphorus: number
  potassium: number
}

interface PlantingSuitability {
  crop: string
  score: number
  recommendation: string
}

export default function WeatherWidget() {
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [forecast, setForecast] = useState<ForecastData[]>([])
  const [soilData, setSoilData] = useState<SoilData | null>(null)
  const [plantingSuitability, setPlantingSuitability] = useState<PlantingSuitability[]>([])
  const [loading, setLoading] = useState(true)
  const [location, setLocation] = useState<{ lat: number; lon: number } | null>(null)
  const { toast } = useToast()
  const [filteredForecast, setFilteredForecast] = useState<ForecastData[]>([])
  const [locations, setLocations] = useState([
    { id: 1, name: "Harare, Zimbabwe", lat: -17.8292, lon: 31.0522 },
    { id: 2, name: "Bulawayo, Zimbabwe", lat: -20.1325, lon: 28.6266 },
    { id: 3, name: "Mutare, Zimbabwe", lat: -18.9707, lon: 32.6709 },
    { id: 4, name: "Gweru, Zimbabwe", lat: -19.517, lon: 29.8149 },
    { id: 5, name: "Kadoma, Zimbabwe", lat: -18.3333, lon: 29.9167 },
    { id: 6, name: "Masvingo, Zimbabwe", lat: -20.0637, lon: 30.8277 },
    { id: 7, name: "Chinhoyi, Zimbabwe", lat: -17.3667, lon: 30.2 },
    { id: 8, name: "Kwekwe, Zimbabwe", lat: -18.9281, lon: 29.8149 },
    { id: 9, name: "Lusaka, Zambia", lat: -15.3875, lon: 28.3228 },
    { id: 10, name: "Gaborone, Botswana", lat: -24.6282, lon: 25.9231 },
    { id: 11, name: "Maputo, Mozambique", lat: -25.9653, lon: 32.5892 },
    { id: 12, name: "Johannesburg, South Africa", lat: -26.2041, lon: 28.0473 },
  ])
  const [selectedLocation, setSelectedLocation] = useState(locations[0])

  useEffect(() => {
    setLocation({ lat: -17.8292, lon: 31.0522 }) // Default to Harare

    if (navigator.geolocation) {
      try {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setLocation({
              lat: position.coords.latitude,
              lon: position.coords.longitude,
            })
          },
          (error) => {
            console.error("Error getting location:", error)
            if (error.code !== error.PERMISSION_DENIED) {
              toast({
                title: "Location Error",
                description: "Unable to get your location. Using default location.",
                variant: "destructive",
              })
            }
          },
          { timeout: 5000, maximumAge: 60000 },
        )
      } catch (error) {
        console.error("Geolocation error:", error)
      }
    }
  }, [toast])

  useEffect(() => {
    const fetchUserDefaultLocation = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 500))
        const userDefaultLocation = {
          id: 1,
          name: "Harare, Zimbabwe",
          lat: -17.8292,
          lon: 31.0522,
        }
        setSelectedLocation(userDefaultLocation)
        setLocation({ lat: userDefaultLocation.lat, lon: userDefaultLocation.lon })
      } catch (error) {
        console.error("Error fetching user's default location:", error)
      }
    }
    fetchUserDefaultLocation()
  }, [])

  useEffect(() => {
    if (location) {
      fetchWeather(location.lat, location.lon)
      fetchForecast(location.lat, location.lon)
      fetchSoilData(location.lat, location.lon)
    }
  }, [location])

  const fetchWeather = async (lat: number, lon: number) => {
    try {
      const apiKey = env.NEXT_PUBLIC_OPENWEATHER_API_KEY
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`,
      )

      if (!response.ok) {
        throw new Error("Weather data not available")
      }

      const data = await response.json()
      setWeather(data)
    } catch (error) {
      console.error("Error fetching weather:", error)
      toast({
        title: "Weather Data Error",
        description: "Unable to fetch weather data. Please try again later.",
        variant: "destructive",
      })
    }
  }

  const fetchForecast = async (lat: number, lon: number) => {
    try {
      const apiKey = env.NEXT_PUBLIC_OPENWEATHER_API_KEY
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`,
      )

      if (!response.ok) {
        throw new Error("Forecast data not available")
      }

      const data = await response.json()
      setForecast(data.list)
      const filteredForecast = data.list.filter((item: ForecastData) => item.dt_txt.includes("12:00:00")).slice(0, 5)
      setFilteredForecast(filteredForecast)
    } catch (error) {
      console.error("Error fetching forecast:", error)
    }
  }

  const fetchSoilData = async (lat: number, lon: number) => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      const mockSoilData: SoilData = {
        moisture: 65,
        temperature: 22,
        ph: 6.5,
        nitrogen: 40,
        phosphorus: 60,
        potassium: 55,
      }

      setSoilData(mockSoilData)
      const mockPlantingSuitability: PlantingSuitability[] = [
        {
          crop: "Maize",
          score: 85,
          recommendation: "Excellent conditions for planting maize",
        },
        {
          crop: "Beans",
          score: 75,
          recommendation: "Good conditions for planting beans",
        },
        {
          crop: "Tomatoes",
          score: 60,
          recommendation: "Moderate conditions for planting tomatoes",
        },
        {
          crop: "Potatoes",
          score: 50,
          recommendation: "Fair conditions for planting potatoes",
        },
        {
          crop: "Rice",
          score: 30,
          recommendation: "Poor conditions for planting rice",
        },
      ]

      setPlantingSuitability(mockPlantingSuitability)
      setLoading(false)
    } catch (error) {
      console.error("Error fetching soil data:", error)
      setLoading(false)
    }
  }

  const getWeatherIcon = (weatherMain: string) => {
    switch (weatherMain.toLowerCase()) {
      case "clear":
        return <Sun className="h-10 w-10 text-yellow-500" />
      case "clouds":
        return <Cloud className="h-10 w-10 text-gray-500" />
      case "rain":
      case "drizzle":
        return <CloudRain className="h-10 w-10 text-blue-500" />
      default:
        return <Cloud className="h-10 w-10 text-gray-500" />
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })
  }

  const getSuitabilityColor = (score: number) => {
    if (score >= 80) return "bg-green-500"
    if (score >= 60) return "bg-green-400"
    if (score >= 40) return "bg-yellow-400"
    if (score >= 20) return "bg-orange-400"
    return "bg-red-400"
  }

  const handleLocationChange = (value: string) => {
    const locationId = Number.parseInt(value)
    const newLocation = locations.find((loc) => loc.id === locationId)
    if (newLocation) {
      setSelectedLocation(newLocation)
      setLocation({ lat: newLocation.lat, lon: newLocation.lon })
      setLoading(true)
    }
  }

  return (
    <Card className="w-full bg-white shadow-md rounded-lg overflow-hidden">
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-800">Weather Forecast</h3>
          <Select value={selectedLocation.id.toString()} onValueChange={handleLocationChange}>
            <SelectTrigger className="w-[180px] h-8 text-sm bg-gray-50 border-gray-200">
              <SelectValue placeholder="Select location" />
            </SelectTrigger>
            <SelectContent>
              {locations.map((loc) => (
                <SelectItem key={loc.id} value={loc.id.toString()}>
                  {loc.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="current" className="w-full">
          <TabsList className="w-full grid grid-cols-3 mb-4">
            <TabsTrigger value="current">Current</TabsTrigger>
            <TabsTrigger value="forecast">5-Day Forecast</TabsTrigger>
            <TabsTrigger value="soil">Soil & Planting</TabsTrigger>
          </TabsList>

          <TabsContent value="current">
            {loading ? (
              <div className="space-y-4 p-2">
                <Skeleton className="h-24 w-full rounded-lg" />
                <div className="grid grid-cols-3 gap-3">
                  <Skeleton className="h-16 rounded-lg" />
                  <Skeleton className="h-16 rounded-lg" />
                  <Skeleton className="h-16 rounded-lg" />
                </div>
              </div>
            ) : weather ? (
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      {getWeatherIcon(weather.weather[0].main)}
                      <div>
                        <h2 className="text-3xl font-bold text-gray-800">{Math.round(weather.main.temp)}°C</h2>
                        <p className="text-gray-600 capitalize">{weather.weather[0].description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center justify-end text-gray-700">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span className="font-medium">{weather.name}</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date().toLocaleDateString([], { weekday: "long", month: "short", day: "numeric" })}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-blue-50 rounded-lg p-3 text-center">
                    <Thermometer className="h-5 w-5 mx-auto mb-1 text-blue-500" />
                    <p className="text-xs text-gray-600">Feels Like</p>
                    <p className="text-lg font-semibold text-gray-800">{Math.round(weather.main.feels_like)}°C</p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-3 text-center">
                    <Wind className="h-5 w-5 mx-auto mb-1 text-green-500" />
                    <p className="text-xs text-gray-600">Wind</p>
                    <p className="text-lg font-semibold text-gray-800">{weather.wind.speed} m/s</p>
                  </div>
                  <div className="bg-purple-50 rounded-lg p-3 text-center">
                    <Droplet className="h-5 w-5 mx-auto mb-1 text-purple-500" />
                    <p className="text-xs text-gray-600">Humidity</p>
                    <p className="text-lg font-semibold text-gray-800">{weather.main.humidity}%</p>
                  </div>
                </div>

                {forecast.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Today's Forecast</h4>
                    <div className="flex overflow-x-auto pb-2 gap-3">
                      {forecast.slice(0, 6).map((item, index) => (
                        <div key={index} className="flex-shrink-0 text-center bg-gray-50 rounded-lg p-2 w-16">
                          <p className="text-xs text-gray-600">{new Date(item.dt_txt).getHours()}:00</p>
                          <div className="my-1">{getWeatherIcon(item.weather[0].main)}</div>
                          <p className="text-sm font-medium">{Math.round(item.main.temp)}°</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex justify-center items-center h-40">
                <p className="text-gray-500">Weather data unavailable. Please try again later.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="forecast">
            {loading ? (
              <div className="space-y-3 p-2">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Skeleton key={i} className="h-16 w-full rounded-lg" />
                ))}
              </div>
            ) : filteredForecast.length > 0 ? (
              <div className="space-y-3">
                {filteredForecast.map((day, index) => (
                  <div key={index} className="bg-gray-50 rounded-lg p-3 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div className="w-10">{getWeatherIcon(day.weather[0].main)}</div>
                      <div>
                        <p className="font-medium text-gray-800">{formatDate(day.dt_txt)}</p>
                        <p className="text-sm text-gray-600 capitalize">{day.weather[0].description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold text-gray-800">{Math.round(day.main.temp)}°C</p>
                      <div className="flex items-center justify-end text-sm text-gray-600">
                        <Droplet className="h-3 w-3 mr-1 text-blue-500" />
                        <span>{day.main.humidity}%</span>
                        <Wind className="h-3 w-3 ml-2 mr-1 text-green-500" />
                        <span>{day.wind.speed} m/s</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex justify-center items-center h-40">
                <p className="text-gray-500">Forecast data unavailable. Please try again later.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="soil">
            {loading ? (
              <div className="space-y-3 p-2">
                <Skeleton className="h-20 w-full rounded-lg" />
                <Skeleton className="h-40 w-full rounded-lg" />
              </div>
            ) : soilData ? (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-blue-50 rounded-lg p-3 text-center">
                    <Droplet className="h-5 w-5 mx-auto mb-1 text-blue-500" />
                    <p className="text-xs text-gray-600">Soil Moisture</p>
                    <p className="text-lg font-semibold text-gray-800">{soilData.moisture}%</p>
                  </div>
                  <div className="bg-red-50 rounded-lg p-3 text-center">
                    <Thermometer className="h-5 w-5 mx-auto mb-1 text-red-500" />
                    <p className="text-xs text-gray-600">Soil Temp</p>
                    <p className="text-lg font-semibold text-gray-800">{soilData.temperature}°C</p>
                  </div>
                  <div className="bg-purple-50 rounded-lg p-3 text-center">
                    <div className="flex justify-center">
                      <span className="text-purple-500 font-bold text-lg">pH</span>
                    </div>
                    <p className="text-xs text-gray-600">Soil pH</p>
                    <p className="text-lg font-semibold text-gray-800">{soilData.ph}</p>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Planting Suitability</h4>
                  <div className="space-y-2">
                    {plantingSuitability.map((crop, index) => (
                      <div key={index} className="bg-gray-50 rounded-lg p-3">
                        <div className="flex justify-between items-center mb-1">
                          <div className="flex items-center">
                            <div className={`w-3 h-3 rounded-full ${getSuitabilityColor(crop.score)} mr-2`}></div>
                            <span className="font-medium text-gray-800">{crop.crop}</span>
                          </div>
                          <span className="text-sm font-medium">{crop.score}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div
                            className={`${getSuitabilityColor(crop.score)} h-1.5 rounded-full`}
                            style={{ width: `${crop.score}%` }}
                          ></div>
                        </div>
                        <p className="text-xs text-gray-600 mt-1">{crop.recommendation}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex justify-center items-center h-40">
                <p className="text-gray-500">Soil data unavailable. Please try again later.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Card>
  )
}

