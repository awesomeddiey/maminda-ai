"use client"

import { useState, useEffect } from "react"
import { UnsplashImage } from "./unsplash-image"
import { getUnsplashImages, type UnsplashImage as UnsplashImageType } from "@/services/unsplash-service"

interface ImageGalleryProps {
  query: string
  count?: number
  className?: string
  imageClassName?: string
  title?: string
  subtitle?: string
}

export function ImageGallery({
  query,
  count = 6,
  className = "",
  imageClassName = "",
  title,
  subtitle,
}: ImageGalleryProps) {
  const [images, setImages] = useState<UnsplashImageType[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchImages = async () => {
      try {
        setLoading(true)
        const fetchedImages = await getUnsplashImages(query, count)
        setImages(fetchedImages)
      } catch (error) {
        console.error("Error fetching images:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchImages()
  }, [query, count])

  return (
    <div className={className}>
      {title && <h2 className="text-2xl font-bold mb-2">{title}</h2>}
      {subtitle && <p className="text-gray-600 mb-6">{subtitle}</p>}

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {Array.from({ length: count }).map((_, i) => (
            <div key={i} className="bg-gray-200 animate-pulse h-48 rounded-lg"></div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {images.map((image, index) => (
            <div key={image.id || index} className="overflow-hidden rounded-lg">
              <UnsplashImage
                query={query}
                alt={image.alt_description || `Farm image ${index + 1}`}
                className={`h-48 w-full object-cover transition-transform duration-300 hover:scale-105 ${imageClassName}`}
                width={400}
                height={300}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

