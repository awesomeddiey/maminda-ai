// Update the CircularGauge component to prevent text overlap and improve appearance

interface CircularGaugeProps {
  value: number
  maxValue: number
  minValue?: number
  title: string
  unit?: string
  color?: string
  size?: number
}

export function CircularGauge({
  value,
  maxValue,
  minValue = 0,
  title,
  unit = "",
  color = "#16a34a",
  size = 120,
}: CircularGaugeProps) {
  const normalizedValue = Math.min(Math.max(value, minValue), maxValue)
  const percentage = ((normalizedValue - minValue) / (maxValue - minValue)) * 100

  // Calculate dimensions based on size
  const radius = size * 0.4
  const circumference = 2 * Math.PI * radius
  const strokeWidth = size * 0.08
  const fontSize = size * 0.14
  const unitFontSize = size * 0.1

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="relative" style={{ width: `${size}px`, height: `${size}px` }}>
        <svg width="100%" height="100%" viewBox={`0 0 ${size} ${size}`} className="transform -rotate-90">
          {/* Background circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="transparent"
            stroke="#e2e8f0"
            strokeWidth={strokeWidth}
            className="opacity-30"
          />

          {/* Progress circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="transparent"
            stroke={color}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={circumference - (percentage / 100) * circumference}
            className="transition-all duration-1000 ease-in-out"
          />
        </svg>

        {/* Center text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-bold" style={{ fontSize: `${fontSize}px`, color }}>
            {typeof value === "number" && value % 1 === 0 ? value : value.toFixed(1)}
          </span>
          {unit && (
            <span className="text-gray-500" style={{ fontSize: `${unitFontSize}px` }}>
              {unit}
            </span>
          )}
        </div>
      </div>

      <span className="mt-2 text-sm font-medium text-center text-gray-700">{title}</span>
    </div>
  )
}

