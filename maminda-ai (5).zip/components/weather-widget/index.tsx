import WeatherWidgetComponent from "../weather-widget"

export const WeatherWidget = WeatherWidgetComponent
export default WeatherWidgetComponent

// Add a function to convert location names to coordinates
const getLocationCoordinates = (locationName: string) => {
  const locations: Record<string, { lat: number; lon: number }> = {
    harare: { lat: -17.8292, lon: 31.0539 },
    bulawayo: { lat: -20.156, lon: 28.5885 },
    chitungwiza: { lat: -18.0127, lon: 31.0756 },
    mutare: { lat: -18.9755, lon: 32.6504 },
    gweru: { lat: -19.5157, lon: 29.8187 },
    kwekwe: { lat: -18.9271, lon: 29.8149 },
    kadoma: { lat: -18.333, lon: 29.9153 },
    masvingo: { lat: -20.0637, lon: 30.8277 },
    chinhoyi: { lat: -17.3667, lon: 30.2 },
    victoria_falls: { lat: -17.9317, lon: 25.8307 },
    current: null, // This will be handled separately
  }

  // Return the coordinates for the given location name, or null if not found
  return locations[locationName]
}

