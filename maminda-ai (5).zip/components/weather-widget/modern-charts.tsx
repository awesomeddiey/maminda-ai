"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import { Thermometer } from "lucide-react"

interface TemperatureChartProps {
  data: number[]
  labels: string[]
  height?: number
}

export function TemperatureChart({ data, labels, height = 150 }: TemperatureChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height)

    // Set dimensions
    const width = canvasRef.current.width
    const chartHeight = height
    const padding = { top: 20, right: 20, bottom: 30, left: 40 }
    const chartWidth = width - padding.left - padding.right

    // Find min and max values
    const minTemp = Math.min(...data) - 2
    const maxTemp = Math.max(...data) + 2
    const tempRange = maxTemp - minTemp

    // Draw axes
    ctx.beginPath()
    ctx.strokeStyle = "#e2e8f0"
    ctx.moveTo(padding.left, padding.top)
    ctx.lineTo(padding.left, chartHeight - padding.bottom)
    ctx.lineTo(width - padding.right, chartHeight - padding.bottom)
    ctx.stroke()

    // Draw temperature line
    ctx.beginPath()
    ctx.strokeStyle = "#16a34a"
    ctx.lineWidth = 3
    ctx.lineJoin = "round"

    // Calculate points
    const points = data.map((temp, i) => {
      const x = padding.left + i * (chartWidth / (data.length - 1))
      const y = padding.top + ((maxTemp - temp) / tempRange) * (chartHeight - padding.top - padding.bottom)
      return { x, y }
    })

    // Draw curve
    ctx.moveTo(points[0].x, points[0].y)
    for (let i = 1; i < points.length; i++) {
      const xc = (points[i].x + points[i - 1].x) / 2
      const yc = (points[i].y + points[i - 1].y) / 2
      ctx.quadraticCurveTo(points[i - 1].x, points[i - 1].y, xc, yc)
    }
    ctx.stroke()

    // Draw points
    data.forEach((temp, i) => {
      const x = padding.left + i * (chartWidth / (data.length - 1))
      const y = padding.top + ((maxTemp - temp) / tempRange) * (chartHeight - padding.top - padding.bottom)

      ctx.beginPath()
      ctx.arc(x, y, 4, 0, Math.PI * 2)
      ctx.fillStyle = "#16a34a"
      ctx.fill()

      // Draw temperature labels
      ctx.font = "10px sans-serif"
      ctx.fillStyle = "#16a34a"
      ctx.textAlign = "center"
      ctx.fillText(`${temp}°`, x, y - 10)
    })

    // Draw x-axis labels
    ctx.font = "10px sans-serif"
    ctx.fillStyle = "#64748b"
    ctx.textAlign = "center"
    labels.forEach((label, i) => {
      const x = padding.left + i * (chartWidth / (data.length - 1))
      ctx.fillText(label, x, chartHeight - 10)
    })

    // Draw y-axis labels
    ctx.font = "10px sans-serif"
    ctx.fillStyle = "#64748b"
    ctx.textAlign = "right"
    const yLabelCount = 3
    for (let i = 0; i <= yLabelCount; i++) {
      const temp = minTemp + i * (tempRange / yLabelCount)
      const y = chartHeight - padding.bottom - i * ((chartHeight - padding.top - padding.bottom) / yLabelCount)
      ctx.fillText(`${Math.round(temp)}°`, padding.left - 5, y + 3)
    }
  }, [data, labels, height])

  return (
    <div className="relative w-full">
      <div className="flex items-center gap-2 mb-2">
        <Thermometer className="h-4 w-4 text-green-600" />
        <span className="text-sm font-medium">Temperature</span>
      </div>
      <canvas ref={canvasRef} width={500} height={height} className="w-full h-auto" />
    </div>
  )
}

interface CircularProgressProps {
  value: number
  max: number
  size?: number
  strokeWidth?: number
  color?: string
  label: string
  icon: React.ReactNode
  unit?: string
}

export function CircularProgress({
  value,
  max,
  size = 120,
  strokeWidth = 10,
  color = "#16a34a",
  label,
  icon,
  unit = "%",
}: CircularProgressProps) {
  const radius = (size - strokeWidth) / 2
  const circumference = radius * 2 * Math.PI
  const progress = value / max
  const strokeDashoffset = circumference - progress * circumference

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          {/* Background circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="transparent"
            stroke="#e2e8f0"
            strokeWidth={strokeWidth}
          />

          {/* Progress circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="transparent"
            stroke={color}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            transform={`rotate(-90 ${size / 2} ${size / 2})`}
          />
        </svg>

        {/* Center content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="text-xl font-bold">
            {value}
            {unit}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-1 mt-2">
        {icon}
        <span className="text-sm">{label}</span>
      </div>
    </div>
  )
}

interface SoilNutrientChartProps {
  nutrients: {
    name: string
    value: number
    color: string
  }[]
  size?: number
}

export function SoilNutrientChart({ nutrients, size = 200 }: SoilNutrientChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height)

    const centerX = size / 2
    const centerY = size / 2
    const radius = size * 0.4

    // Draw nutrient circles
    nutrients.forEach((nutrient, index) => {
      const angle = (index / nutrients.length) * Math.PI * 2
      const x = centerX + Math.cos(angle) * radius * 0.7
      const y = centerY + Math.sin(angle) * radius * 0.7

      // Draw circle
      ctx.beginPath()
      const circleRadius = (nutrient.value / 100) * (radius * 0.3) + radius * 0.1
      ctx.arc(x, y, circleRadius, 0, Math.PI * 2)
      ctx.fillStyle = nutrient.color
      ctx.fill()

      // Draw label
      ctx.font = "bold 12px sans-serif"
      ctx.fillStyle = "#1f2937"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(nutrient.name, x, y)

      // Draw value
      ctx.font = "10px sans-serif"
      ctx.fillStyle = "#64748b"
      ctx.fillText(`${nutrient.value}%`, x, y + 15)
    })

    // Draw center circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius * 0.2, 0, Math.PI * 2)
    ctx.fillStyle = "#f3f4f6"
    ctx.fill()
    ctx.strokeStyle = "#d1d5db"
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw "Soil" text
    ctx.font = "bold 14px sans-serif"
    ctx.fillStyle = "#1f2937"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Soil", centerX, centerY)
  }, [nutrients, size])

  return (
    <div className="relative w-full flex justify-center">
      <canvas ref={canvasRef} width={size} height={size} className="w-full max-w-[300px] h-auto" />
    </div>
  )
}

