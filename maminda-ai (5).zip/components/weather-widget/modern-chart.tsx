// Add support for humidity and wind chart types
export interface ModernChartProps {
  data: number[]
  labels: string[]
  type: "temperature" | "rainfall" | "humidity" | "wind"
  height: number
  title?: string
}

export function ModernChart({ data, labels, type, height, title }: ModernChartProps) {
  const getGradient = () => {
    switch (type) {
      case "temperature":
        return "from-blue-500 to-transparent"
      case "rainfall":
        return "from-blue-400 to-transparent"
      case "humidity":
        return "from-teal-500 to-transparent"
      case "wind":
        return "from-purple-500 to-transparent"
      default:
        return "from-blue-500 to-transparent"
    }
  }

  const getLineColor = () => {
    switch (type) {
      case "temperature":
        return "#3b82f6" // blue-500
      case "rainfall":
        return "#60a5fa" // blue-400
      case "humidity":
        return "#14b8a6" // teal-500
      case "wind":
        return "#8b5cf6" // purple-500
      default:
        return "#3b82f6" // blue-500
    }
  }

  // Calculate min and max for better visualization
  const minValue = Math.min(...data) - 2
  const maxValue = Math.max(...data) + 2

  // Calculate points for the SVG path
  const chartWidth = 100
  const chartHeight = 100
  const xStep = chartWidth / (data.length - 1)

  const points = data
    .map((value, index) => {
      const x = index * xStep
      // Normalize the y value between 0 and chartHeight
      const normalizedY = ((value - minValue) / (maxValue - minValue)) * chartHeight
      // Invert Y axis (SVG has 0,0 at top left)
      const y = chartHeight - normalizedY
      return `${x},${y}`
    })
    .join(" L ")

  const path = `M ${points}`

  return (
    <div style={{ height: `${height}px` }} className="w-full relative">
      {title && <div className="absolute top-2 left-2 text-xs text-gray-500">{title}</div>}

      <svg className="w-full h-full" viewBox={`0 0 100 100`} preserveAspectRatio="none">
        {/* Grid lines */}
        <line x1="0" y1="25" x2="100" y2="25" stroke="#e5e7eb" strokeWidth="0.5" />
        <line x1="0" y1="50" x2="100" y2="50" stroke="#e5e7eb" strokeWidth="0.5" />
        <line x1="0" y1="75" x2="100" y2="75" stroke="#e5e7eb" strokeWidth="0.5" />

        {/* Area under the line */}
        <defs>
          <linearGradient id={`gradient-${type}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={getLineColor()} stopOpacity="0.5" />
            <stop offset="100%" stopColor={getLineColor()} stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={`${path} L ${(data.length - 1) * xStep},100 L 0,100 Z`} fill={`url(#gradient-${type})`} />

        {/* Line */}
        <path d={path} fill="none" stroke={getLineColor()} strokeWidth="1.5" />

        {/* Data points */}
        {data.map((value, index) => {
          const x = index * xStep
          const normalizedY = ((value - minValue) / (maxValue - minValue)) * chartHeight
          const y = chartHeight - normalizedY
          return <circle key={index} cx={x} cy={y} r="1.5" fill="white" stroke={getLineColor()} strokeWidth="1" />
        })}
      </svg>

      {/* X-axis labels */}
      <div className="flex justify-between mt-2">
        {labels.map((label, index) => (
          <div key={index} className="text-xs text-gray-500">
            {label}
          </div>
        ))}
      </div>
    </div>
  )
}

