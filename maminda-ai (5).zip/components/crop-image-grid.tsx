import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface CropImage {
  name: string
  imageSrc: string
  season: string
  difficulty: "Easy" | "Medium" | "Hard"
}

interface CropImageGridProps {
  crops: CropImage[]
  title?: string
}

export function CropImageGrid({ crops, title }: CropImageGridProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "bg-green-100 text-green-800 hover:bg-green-200"
      case "Medium":
        return "bg-yellow-100 text-yellow-800 hover:bg-yellow-200"
      case "Hard":
        return "bg-red-100 text-red-800 hover:bg-red-200"
      default:
        return "bg-gray-100 text-gray-800 hover:bg-gray-200"
    }
  }

  const getSeasonColor = (season: string) => {
    switch (season.toLowerCase()) {
      case "spring":
        return "bg-emerald-100 text-emerald-800 hover:bg-emerald-200"
      case "summer":
        return "bg-orange-100 text-orange-800 hover:bg-orange-200"
      case "fall":
      case "autumn":
        return "bg-amber-100 text-amber-800 hover:bg-amber-200"
      case "winter":
        return "bg-blue-100 text-blue-800 hover:bg-blue-200"
      case "year-round":
        return "bg-purple-100 text-purple-800 hover:bg-purple-200"
      default:
        return "bg-gray-100 text-gray-800 hover:bg-gray-200"
    }
  }

  return (
    <div className="space-y-4">
      {title && (
        <h2 className="text-2xl font-bold mb-4 text-gray-900">
          <span className="inline-block pb-2 border-b-2 border-green-500">{title}</span>
        </h2>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {crops.map((crop, index) => (
          <Card key={index} className="overflow-hidden hover:shadow-md transition-all">
            <div className="aspect-square relative">
              <img
                src={crop.imageSrc || "/placeholder.svg?height=200&width=200"}
                alt={crop.name}
                className="object-cover w-full h-full"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-3">
                <h3 className="text-white font-medium">{crop.name}</h3>
              </div>
            </div>
            <CardContent className="p-3 flex flex-wrap gap-2">
              <Badge variant="secondary" className={getSeasonColor(crop.season)}>
                {crop.season}
              </Badge>
              <Badge variant="secondary" className={getDifficultyColor(crop.difficulty)}>
                {crop.difficulty}
              </Badge>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

