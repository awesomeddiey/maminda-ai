"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface NewsItem {
  title: string
  description: string
  url: string
  urlToImage: string
  publishedAt: string
  source: {
    name: string
  }
}

export function NewsSection() {
  const [news, setNews] = useState<NewsItem[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchNews = async () => {
      try {
        // Hard-coded API key for testing purposes
        const API_KEY = "pub_74584b9279b11c5dbe0db533dc3668959cbf6"
        const response = await fetch(
          `https://newsdata.io/api/1/news?apikey=${API_KEY}&country=zw&category=environment,business,health&language=en`,
        )

        if (!response.ok) {
          throw new Error("Failed to fetch news")
        }

        const data = await response.json()

        // Format the news data from the API to match our interface
        if (data.results && data.results.length > 0) {
          const formattedNews = data.results.slice(0, 5).map((item: any) => ({
            title: item.title || "No title available",
            description: item.description || item.content || "No description available",
            url: item.link,
            urlToImage: item.image_url || "/placeholder.svg?height=200&width=400",
            publishedAt: item.pubDate,
            source: {
              name: item.source_id || "News Source",
            },
          }))
          setNews(formattedNews)
        } else {
          // Fallback to mock data if no results
          setNews(getMockNewsData())
        }
      } catch (error) {
        console.error("Error fetching news:", error)
        toast({
          title: "Error fetching news",
          description: "Using cached news data instead",
          variant: "destructive",
        })
        // Fallback to mock data
        setNews(getMockNewsData())
      } finally {
        setLoading(false)
      }
    }

    fetchNews()
  }, [toast])

  const getMockNewsData = (): NewsItem[] => {
    return [
      {
        title: "New Sustainable Farming Techniques Show Promise in Zimbabwe",
        description:
          "Researchers have developed new sustainable farming techniques that reduce water usage by 30% while maintaining crop yields.",
        url: "#",
        urlToImage: "/placeholder.svg?height=200&width=400",
        publishedAt: "2023-06-15T09:30:00Z",
        source: { name: "Farming Today" },
      },
      {
        title: "Government Announces New Subsidies for Organic Farmers",
        description:
          "The government has announced a new subsidy program aimed at supporting organic farmers and promoting sustainable agriculture.",
        url: "#",
        urlToImage: "/placeholder.svg?height=200&width=400",
        publishedAt: "2023-06-14T14:45:00Z",
        source: { name: "Agri News" },
      },
      {
        title: "Climate Change Affecting Crop Patterns in Zimbabwe, Study Finds",
        description:
          "A new study has found that changing climate patterns are affecting traditional crop growing seasons across multiple regions.",
        url: "#",
        urlToImage: "/placeholder.svg?height=200&width=400",
        publishedAt: "2023-06-13T11:20:00Z",
        source: { name: "Climate & Agriculture" },
      },
      {
        title: "New Plant Disease Resistant Varieties Released",
        description:
          "Scientists have developed new crop varieties with enhanced resistance to common plant diseases, potentially reducing the need for pesticides.",
        url: "#",
        urlToImage: "/placeholder.svg?height=200&width=400",
        publishedAt: "2023-06-12T08:15:00Z",
        source: { name: "Crop Science Weekly" },
      },
    ]
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="relative">
      {loading ? (
        <div className="flex gap-4 overflow-x-auto pb-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="min-w-[300px] flex-shrink-0">
              <CardContent className="p-0">
                <Skeleton className="h-[150px] w-full rounded-t-lg" />
                <div className="p-4">
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex gap-4 overflow-x-auto pb-4">
          {news.map((item, index) => (
            <Dialog key={index}>
              <DialogTrigger asChild>
                <Card
                  key={index}
                  className="min-w-[300px] max-w-[300px] flex-shrink-0 cursor-pointer hover:shadow-md transition-all h-full"
                >
                  <CardContent className="p-0 h-full flex flex-col">
                    <div className="h-40 overflow-hidden">
                      <img
                        src={item.urlToImage || "/placeholder.svg?height=200&width=400"}
                        alt={item.title}
                        className="h-full w-full object-cover transition-transform duration-500 hover:scale-110"
                        onError={(e) => {
                          e.currentTarget.src = "/placeholder.svg?height=200&width=400"
                        }}
                      />
                    </div>
                    <div className="p-4 flex-grow flex flex-col justify-between">
                      <h3 className="font-medium line-clamp-2 mb-2">{item.title}</h3>
                      <p className="text-sm text-muted-foreground">{formatDate(item.publishedAt)}</p>
                    </div>
                  </CardContent>
                </Card>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>{item.title}</DialogTitle>
                  <DialogDescription>
                    {item.source.name} • {formatDate(item.publishedAt)}
                  </DialogDescription>
                </DialogHeader>
                <div className="mt-4">
                  <div className="rounded-md overflow-hidden mb-4">
                    <img
                      src={item.urlToImage || "/placeholder.svg?height=200&width=400"}
                      alt={item.title}
                      className="w-full h-[200px] object-cover"
                      onError={(e) => {
                        e.currentTarget.src = "/placeholder.svg?height=200&width=400"
                      }}
                    />
                  </div>
                  <p>{item.description}</p>
                  <Button className="mt-4 w-full" variant="outline" asChild>
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2"
                    >
                      Read Full Article
                      <ExternalLink size={16} />
                    </a>
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          ))}
        </div>
      )}
    </div>
  )
}

