import Image from "next/image"

export function HeroSection() {
  return (
    <div className="relative h-screen min-h-[600px] w-full overflow-hidden">
      <Image
        src="/images/farm-background.jpg"
        alt="Zimbabwe farming landscape"
        fill
        priority
        className="object-cover"
      />
      <div className="absolute inset-0 bg-black/50"></div>
      <div className="container relative mx-auto px-4 py-16 md:py-24 h-full flex items-center">{/* Content */}</div>
    </div>
  )
}

