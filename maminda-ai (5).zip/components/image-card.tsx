"use client"

import type React from "react"

import { UnsplashImage } from "./unsplash-image"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

interface ImageCardProps {
  title: string
  description?: string
  imageQuery: string
  href?: string
  className?: string
  onClick?: () => void
}

export function ImageCard({ title, description, imageQuery, href, className = "", onClick }: ImageCardProps) {
  const CardWrapper = ({ children }: { children: React.ReactNode }) => {
    if (href) {
      return (
        <Link href={href} className="block">
          {children}
        </Link>
      )
    }
    return (
      <div onClick={onClick} className={onClick ? "cursor-pointer" : ""}>
        {children}
      </div>
    )
  }

  return (
    <CardWrapper>
      <Card className={`overflow-hidden transition-all duration-300 hover:shadow-lg ${className}`}>
        <UnsplashImage query={imageQuery} alt={title} className="h-48 w-full" width={400} height={200} />
        <CardContent className="p-4">
          <h3 className="text-lg font-semibold mb-2">{title}</h3>
          {description && <p className="text-sm text-gray-600">{description}</p>}
        </CardContent>
      </Card>
    </CardWrapper>
  )
}

