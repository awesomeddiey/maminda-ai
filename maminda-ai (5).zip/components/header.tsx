"use client"

import { useState } from "react"
import Link from "next/link"
import {
  X,
  Home,
  Camera,
  Leaf,
  Bot,
  Settings,
  FileText,
  LogOut,
  Globe,
  BarChart2,
  HelpCircle,
  FileVideo,
  Cloud,
  ChevronDown,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { useSupabase } from "./supabase-provider"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { useRouter, usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { ContactDialog } from "./contact-dialog"

export default function Header() {
  const { user, supabase } = useSupabase()
  const router = useRouter()
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)
  const [language, setLanguage] = useState("en") // en, sn, nd

  // Update the handleSignOut function to redirect to the landing page
  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push("/")
    setIsOpen(false)
  }

  const getInitials = (name: string) => {
    return (
      name
        ?.split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase() || "U"
    )
  }

  const languages = [
    { code: "en", name: "English" },
    { code: "sn", name: "Shona" },
    { code: "nd", name: "Ndebele" },
  ]

  // Add translation function
  const getTranslation = (key: string) => {
    const translations: Record<string, Record<string, string>> = {
      Home: { en: "Home", sn: "Kumba", nd: "Ekhaya" },
      "Disease Scanner": { en: "Disease Scanner", sn: "Mushonga Muongorori", nd: "Isihloli Sesifo" },
      "Planting Guide": { en: "Planting Guide", sn: "Nzira Yekudyara", nd: "Umkhombandlela Wokuhlanyela" },
      FarmBot: { en: "FarmBot", sn: "FarmBot", nd: "FarmBot" },
      Dashboard: { en: "Dashboard", sn: "Bhodi Rezvibodzwa", nd: "Ibhodi Lokubona" },
      "Help & Support": { en: "Help & Support", sn: "Rubatsiro", nd: "Usizo" },
      "News & Tutorials": { en: "News & Tutorials", sn: "Nhau neDzidziso", nd: "Izindaba Nokufundisa" },
      "Settings & Profile": { en: "Settings & Profile", sn: "Zvimiso neGwaro", nd: "Izilungiselelo Nophawu" },
      Documentation: { en: "Documentation", sn: "Gwaro", nd: "Imibhalo" },
      "Sign In": { en: "Sign In", sn: "Pinda", nd: "Ngena" },
      "Sign Up": { en: "Sign Up", sn: "Nyoresa", nd: "Bhalisela" },
      "Sign Out": { en: "Sign Out", sn: "Buda", nd: "Phuma" },
      "Contact Us": { en: "Contact Us", sn: "Bata Nesu", nd: "Thintana Nathi" },
      About: { en: "About", sn: "Nezvedu", nd: "Ngathi" },
      Language: { en: "Language", sn: "Mutauro", nd: "Ulimi" },
    }

    return translations[key]?.[language] || key
  }

  // Update the navItems array to reflect the new navigation structure
  const navItems = [
    { name: "Home", href: "/home", icon: <Home className="h-5 w-5" /> },
    { name: "Disease Scanner", href: "/plant-disease-analyzer", icon: <Camera className="h-5 w-5" /> },
    { name: "Planting Guide", href: "/planting-guide", icon: <Leaf className="h-5 w-5" /> },
    { name: "Dashboard", href: "/dashboard", icon: <BarChart2 className="h-5 w-5" /> },
    { name: "Help & Support", href: "/help-support", icon: <HelpCircle className="h-5 w-5" /> },
    { name: "News & Tutorials", href: "/news-tutorials", icon: <FileVideo className="h-5 w-5" /> },
    { name: "FarmBot", href: "#farmbot", icon: <Bot className="h-5 w-5" /> },
    { name: "Documentation", href: "/documentation", icon: <FileText className="h-5 w-5" /> },
  ]

  const settingsItems = [
    { name: "Settings & Profile", href: "/profile", icon: <Settings className="h-5 w-5" /> },
    { name: "Documentation", href: "/documentation", icon: <FileText className="h-5 w-5" /> },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center">
          {user ? (
            <button onClick={() => setIsOpen(true)} className="mr-4 p-2 rounded-md hover:bg-muted">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-menu"
              >
                <line x1="4" x2="20" y1="12" y2="12"></line>
                <line x1="4" x2="20" y1="6" y2="6"></line>
                <line x1="4" x2="20" y1="18" y2="18"></line>
              </svg>
            </button>
          ) : null}
          <Link href="/" className="flex items-center space-x-2">
            <div className="flex flex-col items-center justify-center">
              <div className="flex space-x-0">
                <div className="h-1.5 w-6 bg-green-600 rounded-sm"></div>
              </div>
              <div className="flex space-x-0 -mt-0.5">
                <div className="h-1.5 w-8 bg-green-600 rounded-sm"></div>
              </div>
              <div className="flex space-x-0 -mt-0.5">
                <div className="h-1.5 w-10 bg-green-600 rounded-sm"></div>
              </div>
            </div>
            <span className="text-xl font-bold">Maminda AI</span>
          </Link>
        </div>

        {/* New navigation buttons */}
        <div className="hidden md:flex items-center space-x-4">
          <Link href="/" className="text-sm font-medium hover:text-green-600 transition-colors">
            Home
          </Link>
          <ContactDialog
            trigger={
              <button className="text-sm font-medium hover:text-green-600 transition-colors">
                {getTranslation("Contact Us")}
              </button>
            }
          />
          <Link href="/documentation" className="text-sm font-medium hover:text-green-600 transition-colors">
            {getTranslation("About")}
          </Link>
          <Link href="/pricing" className="text-sm font-medium text-green-600 hover:text-green-700 transition-colors">
            Pricing
          </Link>
        </div>

        <div className="flex items-center space-x-2">
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center gap-1"
              onClick={() => document.getElementById("language-dropdown")?.classList.toggle("hidden")}
            >
              <Globe className="h-4 w-4 mr-1" />
              <span>{getTranslation("Language")}</span>
              <ChevronDown className="h-4 w-4" />
            </Button>
            <div
              id="language-dropdown"
              className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden z-50"
            >
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  className={`block px-4 py-2 text-sm w-full text-left ${language === lang.code ? "bg-green-50 text-green-600" : "hover:bg-gray-100"}`}
                  onClick={() => {
                    setLanguage(lang.code)
                    document.getElementById("language-dropdown")?.classList.add("hidden")
                  }}
                >
                  {lang.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetContent side="left" className="w-[300px] p-0">
            <div className="flex flex-col h-full">
              <SheetHeader className="p-6 border-b">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="flex flex-col items-center justify-center">
                      <div className="flex space-x-0">
                        <div className="h-1.5 w-6 bg-green-600 rounded-sm"></div>
                      </div>
                      <div className="flex space-x-0 -mt-0.5">
                        <div className="h-1.5 w-8 bg-green-600 rounded-sm"></div>
                      </div>
                      <div className="flex space-x-0 -mt-0.5">
                        <div className="h-1.5 w-10 bg-green-600 rounded-sm"></div>
                      </div>
                    </div>
                    <SheetTitle className="text-xl font-bold">Maminda AI</SheetTitle>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              </SheetHeader>

              <div className="border-b p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Version 1.0.0</p>
                    <p className="text-sm text-muted-foreground">MIT License</p>
                  </div>
                  <Button variant="ghost" size="sm" className="text-muted-foreground">
                    About
                  </Button>
                </div>
              </div>

              {user ? (
                <div className="border-b p-4">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-12 w-12 bg-muted">
                      <AvatarFallback className="text-lg">
                        {getInitials(user.user_metadata.full_name || user.email || "")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{user.user_metadata.full_name || "Farmer User"}</p>
                      <p className="text-sm text-muted-foreground">{user.email || "farmer@example.com"}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="border-b p-4">
                  <div className="flex flex-col gap-2">
                    <Button
                      onClick={() => {
                        router.push("/signin")
                        setIsOpen(false)
                      }}
                    >
                      {getTranslation("Sign In")}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        router.push("/signup")
                        setIsOpen(false)
                      }}
                    >
                      {getTranslation("Sign Up")}
                    </Button>
                  </div>
                </div>
              )}

              <div className="flex-1 overflow-auto">
                <div className="p-4 border-b">
                  <p className="text-xs font-medium text-muted-foreground mb-3">MAIN MENU</p>
                  <nav className="flex flex-col gap-1">
                    {navItems.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className={cn(
                          "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors",
                          pathname === item.href ? "bg-green-600 text-white" : "text-foreground hover:bg-muted",
                        )}
                        onClick={() => (item.href === "#farmbot" ? setIsOpen(false) : null)}
                      >
                        {item.icon}
                        <span>{getTranslation(item.name)}</span>
                      </Link>
                    ))}
                    <Link
                      href="/weather-dashboard"
                      className={cn(
                        "flex items-center gap-2 px-3 py-2 rounded-md hover:bg-gray-100",
                        pathname === "/weather-dashboard" ? "bg-gray-100 font-medium" : "",
                      )}
                      onClick={() => setIsOpen(false)}
                    >
                      <Cloud className="h-5 w-5 text-green-600" />
                      <span>Weather</span>
                    </Link>
                  </nav>
                </div>

                <div className="p-4">
                  <p className="text-xs font-medium text-muted-foreground mb-3">SETTINGS</p>
                  <nav className="flex flex-col gap-1">
                    {settingsItems.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className={cn(
                          "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors",
                          pathname === item.href ? "bg-green-600 text-white" : "text-foreground hover:bg-muted",
                        )}
                        onClick={() => setIsOpen(false)}
                      >
                        {item.icon}
                        <span>{getTranslation(item.name)}</span>
                        {item.name === "Settings & Profile" && (
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="ml-auto"
                          >
                            <polyline points="6 9 12 15 18 9"></polyline>
                          </svg>
                        )}
                      </Link>
                    ))}
                  </nav>
                </div>
              </div>

              <div className="border-t p-4">
                <p className="text-sm text-green-600 mb-4">Developed by Awesome Intelligence</p>
                {user && (
                  <Button
                    variant="outline"
                    className="w-full flex items-center justify-center gap-2 mb-4"
                    onClick={handleSignOut}
                  >
                    <LogOut className="h-4 w-4" />
                    {getTranslation("Sign Out")}
                  </Button>
                )}
                <p className="text-xs text-muted-foreground text-center">© 2024 Maminda AI Zimbabwe</p>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}

