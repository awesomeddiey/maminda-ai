"use client"

import { UnsplashBackground } from "./unsplash-image"

interface SectionDividerProps {
  imageQuery?: string
  height?: string
  className?: string
}

export function SectionDivider({
  imageQuery = "green fields meadow",
  height = "h-24",
  className = "",
}: SectionDividerProps) {
  return (
    <UnsplashBackground query={imageQuery} className={`w-full ${height} ${className}`}>
      <div className="w-full h-full bg-gradient-to-r from-black/50 via-transparent to-black/50"></div>
    </UnsplashBackground>
  )
}

